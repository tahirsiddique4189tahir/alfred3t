$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host " ==========================================================" -ForegroundColor Cyan
Write-Host "        ALFRED AI ASSISTANT AUTOMATIC APK BUILD ENGINE      " -ForegroundColor Green
Write-Host " ==========================================================" -ForegroundColor Cyan
Write-Host ""

# 1. Determine Project Directory
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectDir = $scriptDir

if (!(Test-Path "$projectDir\app\build.gradle.kts")) {
    $possibleLocations = @(
        "$HOME\Desktop\Alfred",
        "$HOME\Downloads\Alfred",
        "$HOME\.gemini\antigravity\scratch\alfred_extracted\Alfred",
        "$HOME\Desktop\Alfred_Updated",
        "$HOME\Downloads\Alfred_Updated"
    )
    foreach ($loc in $possibleLocations) {
        if (Test-Path "$loc\app\build.gradle.kts") {
            $projectDir = $loc
            break
        }
    }
}

if (!(Test-Path "$projectDir\app\build.gradle.kts")) {
    Write-Host "[!] Could not locate Alfred project root containing app\build.gradle.kts." -ForegroundColor Red
    Write-Host "    Make sure Build_APK.bat is inside the Alfred project folder." -ForegroundColor Yellow
    exit 1
}

Write-Host "[1/5] Project Directory: $projectDir" -ForegroundColor Green

# 2. Check and configure Java (JDK)
Write-Host "[2/5] Checking Java Development Kit (JDK)..." -ForegroundColor Cyan
$javaCmd = Get-Command java -ErrorAction SilentlyContinue
$javacCmd = Get-Command javac -ErrorAction SilentlyContinue

if (!$javacCmd) {
    $knownJdks = @(
        "C:\Program Files\Microsoft\jdk-21.0.12.1-hotspot",
        "C:\Program Files\Microsoft\jdk-21*",
        "C:\Program Files\Eclipse Adoptium\jdk-21*",
        "C:\Program Files\Java\jdk-21*",
        "C:\Program Files\Java\jdk-17*"
    )
    foreach ($pattern in $knownJdks) {
        $found = Get-Item $pattern -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($found) {
            $env:JAVA_HOME = $found.FullName
            $env:PATH = "$($found.FullName)\bin;" + $env:PATH
            break
        }
    }
} else {
    $javaBin = Split-Path -Parent $javacCmd.Source
    $env:JAVA_HOME = Split-Path -Parent $javaBin
}

if (!(Get-Command javac -ErrorAction SilentlyContinue)) {
    Write-Host "[!] Java Development Kit (javac) not found." -ForegroundColor Red
    Write-Host "    Please ensure OpenJDK 21 or Java 17 is installed." -ForegroundColor Yellow
    exit 1
}
Write-Host "      Java JDK OK: $env:JAVA_HOME" -ForegroundColor Green

# 3. Setup Android SDK
Write-Host "[3/5] Checking Android SDK..." -ForegroundColor Cyan
$sdkDir = "$env:LOCALAPPDATA\Android\Sdk"
if ($env:ANDROID_HOME -and (Test-Path $env:ANDROID_HOME)) {
    $sdkDir = $env:ANDROID_HOME
} elseif ($env:ANDROID_SDK_ROOT -and (Test-Path $env:ANDROID_SDK_ROOT)) {
    $sdkDir = $env:ANDROID_SDK_ROOT
}

if (!(Test-Path $sdkDir)) {
    New-Item -ItemType Directory -Path $sdkDir -Force | Out-Null
}

# Write local.properties for Gradle
$escapedSdk = $sdkDir.Replace('\', '\\').Replace(':', '\:')
"sdk.dir=$escapedSdk" | Set-Content "$projectDir\local.properties" -Encoding Ascii

$cmdlineToolsLatest = "$sdkDir\cmdline-tools\latest\bin"
$sdkManager = "$cmdlineToolsLatest\sdkmanager.bat"

if (!(Test-Path $sdkManager)) {
    Write-Host "      Android Command-line Tools not found. Auto-downloading (~145 MB)..." -ForegroundColor Yellow
    $toolsZip = "$env:TEMP\commandlinetools-win.zip"
    $toolsUrl = "https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip"
    
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $toolsUrl -OutFile $toolsZip -UseBasicParsing
    
    Write-Host "      Extracting Command-line Tools..." -ForegroundColor Yellow
    $extractTemp = "$env:TEMP\cmdline-tools-extract"
    if (Test-Path $extractTemp) { Remove-Item -Recurse -Force $extractTemp }
    Expand-Archive -Path $toolsZip -DestinationPath $extractTemp -Force
    
    New-Item -ItemType Directory -Path "$sdkDir\cmdline-tools" -Force | Out-Null
    if (Test-Path "$sdkDir\cmdline-tools\latest") { Remove-Item -Recurse -Force "$sdkDir\cmdline-tools\latest" }
    Move-Item "$extractTemp\cmdline-tools" "$sdkDir\cmdline-tools\latest"
    
    Remove-Item -Force $toolsZip -ErrorAction SilentlyContinue
    Remove-Item -Recurse -Force $extractTemp -ErrorAction SilentlyContinue
}

# Ensure Android 34 platform & build-tools 34.0.0
$platform34 = "$sdkDir\platforms\android-34"
$buildTools34 = "$sdkDir\build-tools\34.0.0"

if (!(Test-Path $platform34) -or !(Test-Path $buildTools34)) {
    Write-Host "      Installing Android 34 platform & build tools..." -ForegroundColor Yellow
    & cmd /c "echo y | `"$sdkManager`" --licenses --sdk_root=`"$sdkDir`"" | Out-Null
    & cmd /c "echo y | `"$sdkManager`" `"platforms;android-34`" `"build-tools;34.0.0`" `"platform-tools`" --sdk_root=`"$sdkDir`""
}
Write-Host "      Android SDK OK: $sdkDir" -ForegroundColor Green

# 4. Setup Gradle
Write-Host "[4/5] Checking Gradle 8.7..." -ForegroundColor Cyan
$toolsBase = "$env:LOCALAPPDATA\AlfredBuildTools"
$gradleBat = "$toolsBase\gradle-8.7\bin\gradle.bat"

if (!(Test-Path $gradleBat)) {
    Write-Host "      Downloading Gradle 8.7 (~130 MB, one-time download)..." -ForegroundColor Yellow
    New-Item -ItemType Directory -Path $toolsBase -Force | Out-Null
    $gradleZip = "$env:TEMP\gradle-8.7-bin.zip"
    $gradleUrl = "https://services.gradle.org/distributions/gradle-8.7-bin.zip"
    
    Invoke-WebRequest -Uri $gradleUrl -OutFile $gradleZip -UseBasicParsing
    Write-Host "      Extracting Gradle..." -ForegroundColor Yellow
    Expand-Archive -Path $gradleZip -DestinationPath $toolsBase -Force
    Remove-Item -Force $gradleZip -ErrorAction SilentlyContinue
}
Write-Host "      Gradle OK: $gradleBat" -ForegroundColor Green

# 5. Build APK
Write-Host ""
Write-Host " [5/5] Compiling APK with Gradle (assembleDebug)..." -ForegroundColor Green
Write-Host "       Please wait a moment while Gradle builds your Alfred APK..." -ForegroundColor Cyan
Write-Host ""

Push-Location $projectDir
try {
    $env:ANDROID_HOME = $sdkDir
    $env:ANDROID_SDK_ROOT = $sdkDir
    
    & "$gradleBat" assembleDebug --no-daemon
    
    if ($LASTEXITCODE -ne 0) {
        throw "Build failed with exit code $LASTEXITCODE"
    }
} finally {
    Pop-Location
}

# 6. Locate Output APK
$builtApk = "$projectDir\app\build\outputs\apk\debug\app-debug.apk"
if (Test-Path $builtApk) {
    $desktopApk = "$HOME\Desktop\Alfred.apk"
    $downloadsApk = "$HOME\Downloads\Alfred.apk"
    Copy-Item $builtApk $desktopApk -Force
    Copy-Item $builtApk $downloadsApk -Force
    
    Write-Host ""
    Write-Host " ==========================================================" -ForegroundColor Green
    Write-Host "      SUCCESS! ALFRED AI ASSISTANT APK IS READY!           " -ForegroundColor Green
    Write-Host " ==========================================================" -ForegroundColor Green
    Write-Host ""
    Write-Host " [OK] APK copied to Desktop:   $desktopApk" -ForegroundColor Yellow
    Write-Host " [OK] APK copied to Downloads: $downloadsApk" -ForegroundColor Yellow
    Write-Host ""
    Write-Host " You can now transfer 'Alfred.apk' to your phone!" -ForegroundColor White
    Write-Host ""
    
    try {
        explorer.exe /select,"$desktopApk"
    } catch {}
} else {
    Write-Host "[!] Could not locate compiled APK at: $builtApk" -ForegroundColor Red
    exit 1
}
