# Alfred - voice assistant for Android (Kotlin)

Package: com.alfred.tahir | minSdk 26 | targetSdk 34

## Features
- Wake words (offline Vosk): "Alfred", "Hi Alfred", "Hey Alfred", "Wake up Alfred"
- Understands Bangla / English / Hindi (Gemini hears your voice), answers in your language
- Controls the screen (tap, scroll, type, open apps) via Accessibility; "look" = real screenshot to Gemini
- Direct phone controls: call, SMS draft, alarm, timer, flashlight, volume, brightness
- Voice commands to change language / voice / Gemini model
- Memory + routines ("when I say good morning, ..."), conversation history screen
- Read notifications aloud and reply (Notification access)
- Floating animated orb: tap = talk, tap while busy = stop, long-press = open app, drag = move
- Text bubble next to the orb, Quick Settings tile (ON/OFF)

## v2.1 - Alfred HUD update
- Dark HUD look (cyan on deep navy, grid background, monospace status text).
- New default orb "Alfred HUD": tick ring, rotating arcs, arc-reactor core and a circular voice waveform
  that grows while Alfred listens and speaks. The old glass orb code is still in OrbView (classicLook).
- Faster: end-of-speech detection 0.8 s (was 1.4 s), Gemini "thinking" turned off (auto fallback if a model rejects it),
  speech and phone actions now run at the same time, replies are voiced sentence by sentence (first sentence starts quickly),
  shorter waits after actions.
- Voice: natural male Gemini voice (Charon default), brisk pace, new setting Voice & Language > Speaking speed (Normal/Fast/Faster/Turbo).

## Older UI notes (pastel glass design, now restyled)
Welcome -> Home (orb, Talk/Search/Control/More) -> Chat (typed + voice history) -> Quick Controls,
Settings list (AI & Gemini, Voice & Language, Floating Orb, Accessibility, Memory, Notifications, General)
and the Floating Orb editor (Style / Color / Size / Opacity + Apply).

## Build (Termux)
gradle assembleDebug --no-daemon

## After updating from an older version
Turn the Alfred Accessibility service OFF and ON again (new screenshot capability),
then grant: Notification access (Settings > Notifications), contacts/phone permission (setup button),
"Modify system settings" (asked automatically the first time you change brightness).

## Unknown calls (experimental)
Settings > Unknown calls: make Alfred the call screening app (only one app can hold this role; turn off Truecaller's
call screening if it has it), allow phone/contacts permissions, optionally let Alfred answer unknown numbers.
Alfred must be ON (mic service). It talks through the loudspeaker and listens with the microphone;
it only works if your phone's microphone can hear the caller. Text appears on a card over the phone app.
Tell callers you use an assistant - recording/translating calls needs consent in many countries (the greeting says it is automated).
