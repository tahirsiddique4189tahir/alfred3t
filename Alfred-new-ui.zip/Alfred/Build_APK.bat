@echo off
setlocal EnableDelayedExpansion
title Alfred J.A.R.V.I.S. - 1-Click APK Builder
color 0B

echo.
echo  ======================================================================
echo            ALFRED J.A.R.V.I.S. - 1-CLICK AUTOMATIC APK BUILDER
echo  ======================================================================
echo.
echo  [+] Checking build environment and starting automated APK builder...
echo  [+] No Android Studio required!
echo.

set "SCRIPT_DIR=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%build_apk.ps1"

if %ERRORLEVEL% EQU 0 (
    echo.
    echo  ======================================================================
    echo   [SUCCESS] APK build completed! You can now install it on your phone.
    echo  ======================================================================
) else (
    echo.
    echo  ======================================================================
    echo   [NOTICE] If any setup step failed, please check the log above.
    echo  ======================================================================
)
echo.
echo Press any key to exit...
pause >nul
