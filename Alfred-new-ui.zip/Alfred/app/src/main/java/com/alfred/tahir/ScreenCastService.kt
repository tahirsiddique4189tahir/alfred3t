package com.alfred.tahir

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.ByteArrayOutputStream

class ScreenCastService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var bgThread: HandlerThread? = null
    private var bgHandler: Handler? = null
    private var lastFrameTime = 0L

    companion object {
        private const val CHANNEL_ID = "ScreenCastChannel"
        private const val ACTION_STOP = "com.alfred.tahir.STOP_CAST"

        var intentData: Intent? = null
        var resultCode: Int = 0

        @Volatile
        var isRunning: Boolean = false
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        createNotificationChannel()
        val notification = buildNotification()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ServiceCompat.startForeground(
                    this,
                    2,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(2, notification)
            }
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }

        val data = intentData
        if (data != null && resultCode != 0) {
            startCasting(resultCode, data)
        } else {
            stopSelf()
        }

        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Alfred Live Eye",
                NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, ScreenCastService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Alfred Live Eye")
            .setContentText("Alfred is looking at your screen...")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(openIntent)
            .addAction(0, "Stop", stopIntent)
            .setOngoing(true)
            .build()
    }

    private fun startCasting(code: Int, data: Intent) {
        // আগে চলতে থাকলে পরিষ্কার করে নেওয়া
        cleanupCasting()

        val metrics = resources.displayMetrics
        val width = 720 // রেজোলিউশন ছোট রাখা হয়েছে যাতে ফোন জ্যাম না হয়
        val height = (metrics.heightPixels * (720f / metrics.widthPixels)).toInt()
        val density = metrics.densityDpi

        bgThread = HandlerThread("ScreenCastWorker").apply { start() }
        bgHandler = Handler(bgThread!!.looper)

        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(code, data)

        // Android 14+ এর জন্য এই কলব্যাকটি বাধ্যতামূলক
        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, bgHandler)

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "ScreenCast", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, bgHandler
        )

        isRunning = true

        imageReader?.setOnImageAvailableListener({ reader ->
            val image = try {
                reader.acquireLatestImage()
            } catch (_: Exception) {
                null
            } ?: return@setOnImageAvailableListener

            val now = System.currentTimeMillis()
            // প্রতি ১ সেকেন্ডে (1000ms) মাত্র ১টি ফ্রেম পাঠাবে, এতে ফোন একদম স্মুথ থাকবে
            if (now - lastFrameTime < 1000) {
                image.close()
                return@setOnImageAvailableListener
            }
            lastFrameTime = now

            try {
                val planes = image.planes
                val buffer = planes[0].buffer
                val pixelStride = planes[0].pixelStride
                val rowStride = planes[0].rowStride
                val rowPadding = rowStride - pixelStride * width

                val fullBitmap = Bitmap.createBitmap(
                    width + rowPadding / pixelStride,
                    height,
                    Bitmap.Config.ARGB_8888
                )
                fullBitmap.copyPixelsFromBuffer(buffer)
                image.close()

                // যদি পাশে বাড়তি প্যাডিং থাকে, তা কেটে সঠিক সাইজে আনা
                val cleanBitmap = if (rowPadding > 0) {
                    Bitmap.createBitmap(fullBitmap, 0, 0, width, height).also {
                        if (it != fullBitmap) fullBitmap.recycle()
                    }
                } else {
                    fullBitmap
                }

                // ছবিটিকে JPEG-তে কনভার্ট করে Gemini-তে পাঠানো
                val out = ByteArrayOutputStream()
                cleanBitmap.compress(Bitmap.CompressFormat.JPEG, 60, out)
                cleanBitmap.recycle()

                val jpegBytes = out.toByteArray()
                Gemini.sendVideoFrame(jpegBytes)
            } catch (_: Exception) {
                try { image.close() } catch (_: Exception) {}
            }
        }, bgHandler)
    }

    private fun cleanupCasting() {
        isRunning = false
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null

        try { imageReader?.close() } catch (_: Exception) {}
        imageReader = null

        try { mediaProjection?.stop() } catch (_: Exception) {}
        mediaProjection = null

        try { bgThread?.quitSafely() } catch (_: Exception) {}
        bgThread = null
        bgHandler = null
    }

    override fun onDestroy() {
        cleanupCasting()
        intentData = null
        resultCode = 0
        super.onDestroy()
    }
}
