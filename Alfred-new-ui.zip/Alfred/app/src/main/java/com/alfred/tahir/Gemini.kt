package com.alfred.tahir

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

class GeminiException(msg: String) : Exception(msg)

/** Callback interface for Gemini Live real-time events */
interface GeminiLiveListener {
    fun onSetupComplete() {}
    fun onAudioReady(pcmData: ByteArray)
    fun onTextReady(text: String)
    fun onToolCall(toolCallId: String, actionJson: JSONObject)
    fun onTurnComplete()
    fun onError(error: String)
    fun onClosed()
}

/** Minimal Gemini client supporting both REST and Live WebSocket API. */
object Gemini {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models"

    private var webSocket: WebSocket? = null

    val isLiveConnected: Boolean
        get() = webSocket != null

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS) // No timeout for continuous WebSocket stream
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    // =========================================================================
    // LIVE WEBSOCKET API (Real-time Bidirectional Streaming)
    // =========================================================================

    /** Starts a live session connecting directly to Gemini's WebSocket API */
    fun startLiveSession(model: String, systemPrompt: String, listener: GeminiLiveListener) {
        val key = Prefs.apiKey
        if (key.isBlank()) {
            listener.onError("No Gemini API key set")
            return
        }

        stopLiveSession()

        // BidiGenerateContent WebSocket strictly requires Gemini 2.0 (e.g. gemini-2.0-flash)
        val liveModel = if (model.contains("2.0-flash")) {
            if (model.startsWith("models/")) model else "models/$model"
        } else {
            "models/gemini-2.0-flash"
        }
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent?key=$key"
        val request = Request.Builder().url(url).build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                // Tool declaration so Gemini Live can execute phone & accessibility actions
                val toolDecl = JSONObject()
                    .put("name", "execute_action")
                    .put("description", "Execute an accessibility or phone action on the user's Android device.")
                    .put(
                        "parameters", JSONObject()
                            .put("type", "OBJECT")
                            .put(
                                "properties", JSONObject()
                                    .put(
                                        "action_json", JSONObject()
                                            .put("type", "STRING")
                                            .put("description", "JSON object string specifying the action, e.g. {\"type\":\"open_app\",\"app\":\"YouTube\"}")
                                    )
                            )
                            .put("required", JSONArray().put("action_json"))
                    )

                val setupObj = JSONObject()
                    .put("model", liveModel)
                    .put(
                        "generationConfig", JSONObject()
                            .put("responseModalities", JSONArray().put("AUDIO"))
                    )
                    .put(
                        "systemInstruction", JSONObject()
                            .put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
                    )
                    .put(
                        "tools", JSONArray().put(
                            JSONObject().put("functionDeclarations", JSONArray().put(toolDecl))
                        )
                    )

                val setupMsg = JSONObject().put("setup", setupObj)
                webSocket.send(setupMsg.toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleSocketMessage(text, listener)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                handleSocketMessage(bytes.utf8(), listener)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                this@Gemini.webSocket = null
                listener.onError(t.message ?: "Unknown WebSocket error")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                this@Gemini.webSocket = null
                listener.onClosed()
            }
        })
    }

    private fun handleSocketMessage(text: String, listener: GeminiLiveListener) {
        try {
            val json = JSONObject(text)

            if (json.has("setupComplete")) {
                listener.onSetupComplete()
                return
            }

            // Handle incoming audio and text responses
            val serverContent = json.optJSONObject("serverContent")
            if (serverContent != null) {
                val turnComplete = serverContent.optBoolean("turnComplete", false)
                val parts = serverContent.optJSONObject("modelTurn")?.optJSONArray("parts")

                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        val part = parts.getJSONObject(i)

                        // Extract Audio Chunk
                        val inlineData = part.optJSONObject("inlineData")
                        if (inlineData != null && inlineData.optString("mimeType").startsWith("audio/")) {
                            val base64Audio = inlineData.optString("data")
                            if (base64Audio.isNotEmpty()) {
                                val pcm = Base64.decode(base64Audio, Base64.DEFAULT)
                                listener.onAudioReady(pcm)
                            }
                        }

                        // Extract Text (if any)
                        val textPart = part.optString("text")
                        if (textPart.isNotEmpty()) {
                            listener.onTextReady(textPart)
                        }
                    }
                }
                if (turnComplete) listener.onTurnComplete()
            }

            // Handle Tool Calls (Actions)
            val toolCall = json.optJSONObject("toolCall")
            if (toolCall != null) {
                val functionCalls = toolCall.optJSONArray("functionCalls")
                if (functionCalls != null && functionCalls.length() > 0) {
                    for (i in 0 until functionCalls.length()) {
                        val call = functionCalls.getJSONObject(i)
                        val id = call.optString("id")
                        val name = call.optString("name")
                        val args = call.optJSONObject("args") ?: JSONObject()

                        val actionObj = if (name == "execute_action" && args.has("action_json")) {
                            try {
                                JSONObject(args.optString("action_json"))
                            } catch (_: Exception) {
                                args
                            }
                        } else {
                            if (!args.has("type")) args.put("type", name)
                            args
                        }
                        listener.onToolCall(id, actionObj)
                    }
                }
            }
        } catch (e: Exception) {
            listener.onError(e.message ?: "JSON parsing error")
        }
    }

    /** Streams raw mic audio to the Live session */
    fun sendAudio(pcmData: ByteArray) {
        val ws = webSocket ?: return
        val base64Data = Base64.encodeToString(pcmData, Base64.NO_WRAP)
        val msg = JSONObject().put(
            "realtimeInput", JSONObject().put(
                "mediaChunks", JSONArray().put(
                    JSONObject()
                        .put("mimeType", "audio/pcm;rate=16000")
                        .put("data", base64Data)
                )
            )
        )
        ws.send(msg.toString())
    }

    /** Streams screen frames (images) to the Live session */
    fun sendVideoFrame(jpegData: ByteArray) {
        val ws = webSocket ?: return
        val base64Data = Base64.encodeToString(jpegData, Base64.NO_WRAP)
        val msg = JSONObject().put(
            "realtimeInput", JSONObject().put(
                "mediaChunks", JSONArray().put(
                    JSONObject()
                        .put("mimeType", "image/jpeg")
                        .put("data", base64Data)
                )
            )
        )
        ws.send(msg.toString())
    }

    /** Sends screen context, typed messages, or the result of a tool/action */
    fun sendContextOrToolResponse(parts: JSONArray, toolCallId: String? = null) {
        val ws = webSocket ?: return
        val msg = JSONObject()
        if (toolCallId != null) {
            msg.put(
                "toolResponse", JSONObject().put(
                    "functionResponses", JSONArray().put(
                        JSONObject()
                            .put("id", toolCallId)
                            .put("name", "execute_action")
                            .put("response", JSONObject().put("output", parts.toString()))
                    )
                )
            )
        } else {
            msg.put(
                "clientContent", JSONObject().put(
                    "turns", JSONArray().put(
                        JSONObject().put("role", "user").put("parts", parts)
                    )
                ).put("turnComplete", true)
            )
        }
        ws.send(msg.toString())
    }

    /** Disconnects from the Live API */
    fun stopLiveSession() {
        try {
            webSocket?.close(1000, "Session ended by user")
        } catch (_: Exception) {}
        webSocket = null
    }

    // =========================================================================
    // ORIGINAL REST API (Turn-by-turn fallback & Chat Screen)
    // =========================================================================

    /** models that rejected "thinking off" (so we do not try again) */
    private val noThinkRejected = HashSet<String>()

    /** contents = JSON array of {role, parts[]} ; returns the model's text (JSON string). */
    suspend fun generate(model: String, system: String, contents: JSONArray): String = withContext(Dispatchers.IO) {
        fun build(noThink: Boolean): JSONObject {
            val gc = JSONObject().put("responseMimeType", "application/json").put("temperature", 0.4)
            // thinking off = much faster answers (voice commands do not need long reasoning)
            if (noThink) gc.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
            return JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", contents)
                .put("generationConfig", gc)
        }
        val targetModel = model.trim().removePrefix("models/").ifBlank { "gemini-2.0-flash" }
        val url = "$BASE/$targetModel:generateContent"
        val resp = try {
            if (targetModel in noThinkRejected) {
                post(url, build(false))
            } else {
                try {
                    post(url, build(true))
                } catch (e: GeminiException) {
                    if (e.message?.startsWith("HTTP 400") == true) {
                        noThinkRejected.add(targetModel)
                        post(url, build(false))
                    } else throw e
                }
            }
        } catch (e: GeminiException) {
            if (targetModel != "gemini-1.5-flash" && (e.message?.contains("404") == true || e.message?.contains("400") == true)) {
                post("$BASE/gemini-1.5-flash:generateContent", build(false))
            } else throw e
        }
        val cand = resp.optJSONArray("candidates")?.optJSONObject(0)
            ?: throw GeminiException("Empty answer (blocked or no candidates)")
        val parts = cand.optJSONObject("content")?.optJSONArray("parts") ?: throw GeminiException("Empty answer")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        sb.toString()
    }

    /** Fast direct chat generation without touching microphone service or opening mic */
    suspend fun chatText(model: String, message: String): String = withContext(Dispatchers.IO) {
        val systemPrompt = "You are Alfred, a calm, polite, loyal MALE personal AI assistant running on the user's phone. Act with high precision, intelligence, and composure. Keep answers concise, helpful, and polite. Always reply in the same language as the user."
        val contents = JSONArray().put(
            JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", message)))
        )
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.4).put("maxOutputTokens", 800))

        val targetModel = model.trim().removePrefix("models/").ifBlank { "gemini-2.0-flash" }
        val resp = try {
            post("$BASE/$targetModel:generateContent", body)
        } catch (e: GeminiException) {
            if (targetModel != "gemini-1.5-flash" && (e.message?.contains("404") == true || e.message?.contains("400") == true)) {
                post("$BASE/gemini-1.5-flash:generateContent", body)
            } else throw e
        }
        val cand = resp.optJSONArray("candidates")?.optJSONObject(0)
            ?: throw GeminiException("No response from model")
        val parts = cand.optJSONObject("content")?.optJSONArray("parts") ?: throw GeminiException("Empty answer")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        sb.toString().trim()
    }

    /** Returns raw 16-bit mono PCM @ 24 kHz, or null. */
    suspend fun tts(text: String, voice: String): ByteArray? = withContext(Dispatchers.IO) {
        // style hint: natural adult male voice, brisk and clear (TTS models obey "Say ...: text")
        val styled = "Say in a natural, calm, clear adult male voice at a brisk pace: $text"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", styled)))))
            .put(
                "generationConfig", JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig", JSONObject().put(
                            "voiceConfig", JSONObject().put(
                                "prebuiltVoiceConfig", JSONObject().put("voiceName", voice)
                            )
                        )
                    )
            )
        val resp = post("$BASE/${Prefs.TTS_MODEL}:generateContent", body)
        val parts = resp.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts") ?: return@withContext null
        for (i in 0 until parts.length()) {
            val d = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data", "")
            if (!d.isNullOrEmpty()) return@withContext Base64.decode(d, Base64.DEFAULT)
        }
        null
    }

    private fun post(url: String, body: JSONObject): JSONObject {
        val key = Prefs.apiKey
        if (key.isBlank()) throw GeminiException("No Gemini API key set")
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 90000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = try {
                    JSONObject(text).getJSONObject("error").optString("message")
                } catch (e: Exception) {
                    text.take(200)
                }
                throw GeminiException("HTTP $code: $msg")
            }
            return JSONObject(text)
        } finally {
            c.disconnect()
        }
    }
}
