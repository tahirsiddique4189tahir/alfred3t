package com.alfred.tahir

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.PlaybackParams
import kotlinx.coroutines.delay
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

object AudioUtil {
    fun rms(b: ShortArray, n: Int): Double {
        if (n <= 0) return 0.0
        var s = 0.0
        for (i in 0 until n) {
            val v = b[i].toDouble()
            s += v * v
        }
        return sqrt(s / n)
    }

    fun shortsToBytes(b: ShortArray, n: Int): ByteArray {
        val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until n) bb.putShort(b[i])
        return bb.array()
    }

    fun pcmToWav(pcm: ByteArray, rate: Int = 16000): ByteArray {
        val bb = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray())
        bb.putInt(pcm.size + 36)
        bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray())
        bb.putInt(16)
        bb.putShort(1)
        bb.putShort(1)
        bb.putInt(rate)
        bb.putInt(rate * 2)
        bb.putShort(2)
        bb.putShort(16)
        bb.put("data".toByteArray())
        bb.putInt(pcm.size)
        bb.put(pcm)
        return bb.array()
    }

    /** Plays 16-bit mono PCM and suspends until it has finished. */
    suspend fun playPcm(pcm: ByteArray, sampleRate: Int, speed: Float = 1f) {
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        try {
            track.write(pcm, 0, pcm.size)
            if (speed > 1.01f || speed < 0.99f) {
                // faster speech without changing the pitch (voice stays natural and male)
                try {
                    track.playbackParams = PlaybackParams().setSpeed(speed).setPitch(1f)
                } catch (_: Exception) {
                }
            }
            track.play()
            val frames = pcm.size / 2
            val limit = (frames * 1000.0 / sampleRate / speed.coerceAtMost(1f)).toLong() + 2000
            val start = System.currentTimeMillis()
            while (track.playbackHeadPosition < frames && System.currentTimeMillis() - start < limit) {
                delay(50)
            }
        } finally {
            try { track.stop() } catch (_: Exception) {}
            track.release()
        }
    }
}
