package com.alfred.tahir

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

/** Alfred's voice: Gemini male voice first (fast, sentence by sentence), phone TTS as fallback. */
class Speaker(ctx: Context) {
    private var tts: TextToSpeech? = null
    private var ready = false

    init {
        tts = TextToSpeech(ctx.applicationContext) { ready = it == TextToSpeech.SUCCESS }
    }

    suspend fun say(text: String, langTag: String, forcePhone: Boolean = false) {
        if (text.isBlank()) return
        AlfredState.orb.value = Orb.SPEAKING
        AlfredState.lastSaid.value = text
        AlfredState.bubble.value = text
        if (!forcePhone && Prefs.voiceMode == "gemini" && Prefs.apiKey.isNotBlank()) {
            val ok = try {
                speakGemini(text, langTag)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                false
            }
            if (ok) return
        }
        phone(text, langTag)
    }

    /**
     * All sentences are requested at the same time. The first one is short, so it comes back
     * quickly and starts playing while the rest are still being made.
     * Returns false if nothing could be played (caller then uses the phone voice).
     */
    private suspend fun speakGemini(text: String, langTag: String): Boolean = coroutineScope {
        val parts = splitSpeech(text)
        val voice = Prefs.voiceName
        val jobs = parts.map { part ->
            async {
                var pcm: ByteArray? = null
                var tries = 0
                while (pcm == null && tries < 2) {
                    tries++
                    pcm = try {
                        Gemini.tts(part, voice)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        null
                    }
                    if (pcm != null && pcm.isEmpty()) pcm = null
                }
                pcm
            }
        }
        var played = false
        for (i in jobs.indices) {
            val pcm = jobs[i].await()
            if (pcm == null) {
                if (!played) {
                    jobs.forEach { it.cancel() }
                    return@coroutineScope false
                }
                phone(parts[i], langTag) // one sentence failed: say it with the phone voice
                continue
            }
            AudioUtil.playPcm(pcm, 24000, Prefs.voiceSpeed)
            played = true
        }
        played
    }

    /** Splits a reply into at most 4 chunks; the first chunk is short so speech starts fast. */
    private fun splitSpeech(text: String): List<String> {
        val raw = text.trim().split(Regex("(?<=[.!?\u0964\u0965\\n])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        if (raw.size <= 1) return listOf(text.trim())
        val out = ArrayList<String>()
        var cur = StringBuilder()
        for (piece in raw) {
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(piece)
            val limit = if (out.isEmpty()) 40 else 140
            if (cur.length >= limit) {
                out.add(cur.toString())
                cur = StringBuilder()
            }
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        while (out.size > 4) {
            val last = out.removeAt(out.size - 1)
            out[out.size - 1] = out[out.size - 1] + " " + last
        }
        return out
    }

    private suspend fun phone(text: String, tag: String) = suspendCancellableCoroutine<Unit> { cont ->
        val t = tts
        if (t == null || !ready) {
            if (cont.isActive) cont.resume(Unit)
            return@suspendCancellableCoroutine
        }
        val loc = Locale.forLanguageTag(tag)
        if (t.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE) t.language = loc

        // Pick male voice if available in system TTS engine
        try {
            val maleVoice = t.voices?.firstOrNull { v ->
                (v.locale.language == loc.language || v.locale == loc) &&
                (v.name.contains("male", ignoreCase = true) || v.name.contains("man", ignoreCase = true) || v.name.contains("#male", ignoreCase = true) || v.name.contains("en-gb-x-rjs", ignoreCase = true)) &&
                !v.isNetworkConnectionRequired
            } ?: t.voices?.firstOrNull { v ->
                (v.locale.language == loc.language || v.locale == loc) &&
                (v.name.contains("male", ignoreCase = true) || v.name.contains("#male", ignoreCase = true))
            }
            if (maleVoice != null) {
                t.voice = maleVoice
            }
        } catch (_: Exception) {}

        t.setPitch(0.82f)       // deep, rich, authoritative Jarvis male tone
        t.setSpeechRate((Prefs.voiceSpeed + 0.05f).coerceIn(0.9f, 1.6f))
        val id = UUID.randomUUID().toString()
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { if (cont.isActive) cont.resume(Unit) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { if (cont.isActive) cont.resume(Unit) }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
        cont.invokeOnCancellation { t.stop() }
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
