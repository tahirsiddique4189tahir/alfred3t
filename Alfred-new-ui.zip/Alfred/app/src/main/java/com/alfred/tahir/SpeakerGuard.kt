package com.alfred.tahir

import android.content.Context
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.SpeakerModel
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Owner voice guard. Makes a voice fingerprint (x-vector) with the offline Vosk speaker model.
 * Nothing leaves the phone: the fingerprint is a list of numbers kept in SharedPreferences.
 */
object SpeakerGuard {
    private var spk: SpeakerModel? = null

    private fun speakerModel(ctx: Context): SpeakerModel? {
        if (spk == null && ModelManager.spkReady(ctx)) {
            spk = try { SpeakerModel(ModelManager.spkDir(ctx).absolutePath) } catch (_: Exception) { null }
        }
        return spk
    }

    fun close() {
        try { spk?.close() } catch (_: Exception) {}
        spk = null
    }

    /** Voice fingerprint of 16 kHz 16-bit mono PCM, or null if no speech / model missing. */
    fun embed(ctx: Context, model: Model, pcm: ByteArray): FloatArray? {
        val sm = speakerModel(ctx) ?: return null
        val rec = Recognizer(model, 16000f, sm)
        try {
            val parts = ArrayList<Pair<FloatArray, Int>>()
            fun grab(json: String) {
                val j = JSONObject(json)
                val a = j.optJSONArray("spk") ?: return
                val v = FloatArray(a.length()) { a.getDouble(it).toFloat() }
                parts.add(v to maxOf(1, j.optInt("spk_frames", 1)))
            }
            var off = 0
            while (off < pcm.size) {
                val n = min(8000, pcm.size - off)
                if (rec.acceptWaveForm(pcm.copyOfRange(off, off + n), n)) grab(rec.result)
                off += n
            }
            grab(rec.finalResult)
            if (parts.isEmpty()) return null
            val dim = parts[0].first.size
            val sum = FloatArray(dim)
            var w = 0f
            for ((v, f) in parts) {
                if (v.size != dim) continue
                for (i in 0 until dim) sum[i] += v[i] * f
                w += f
            }
            if (w <= 0f) return null
            for (i in 0 until dim) sum[i] /= w
            return sum
        } finally {
            rec.close()
        }
    }

    fun average(vs: List<FloatArray>): FloatArray {
        val out = FloatArray(vs[0].size)
        for (v in vs) for (i in out.indices) out[i] += v[i] / vs.size
        return out
    }

    /** 0 = identical voice, about 1 = different. */
    fun distance(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size || a.isEmpty()) return 2f
        var dot = 0f; var na = 0f; var nb = 0f
        for (i in a.indices) { dot += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i] }
        if (na == 0f || nb == 0f) return 2f
        return 1f - dot / (sqrt(na) * sqrt(nb))
    }
}
