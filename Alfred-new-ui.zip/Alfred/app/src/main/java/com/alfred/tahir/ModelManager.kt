package com.alfred.tahir

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Downloads the Vosk models: the small English one (wake word) and the speaker model (owner voice guard). */
object ModelManager {
    const val NAME = "vosk-model-small-en-us-0.15"
    const val SPK_NAME = "vosk-model-spk-0.4"

    fun dir(ctx: Context) = File(ctx.filesDir, "vosk/$NAME")
    fun spkDir(ctx: Context) = File(ctx.filesDir, "vosk/$SPK_NAME")

    fun isReady(ctx: Context) = File(dir(ctx), "conf/model.conf").exists()
    fun spkReady(ctx: Context) = File(spkDir(ctx), "mfcc.conf").exists()

    suspend fun download(ctx: Context): Boolean = fetch(ctx, NAME) && isReady(ctx)

    suspend fun downloadSpk(ctx: Context): Boolean = fetch(ctx, SPK_NAME) && spkReady(ctx)

    private suspend fun fetch(ctx: Context, name: String): Boolean = withContext(Dispatchers.IO) {
        try {
            AlfredState.modelProgress.value = 0
            val base = File(ctx.filesDir, "vosk")
            base.mkdirs()
            val zip = File(base, "$name.zip")
            val c = URL("https://alphacephei.com/vosk/models/$name.zip").openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 30000
            val total = c.contentLengthLong
            c.inputStream.use { input ->
                zip.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    var read = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        read += n
                        if (total > 0) AlfredState.modelProgress.value = (read * 90 / total).toInt()
                    }
                }
            }
            ZipInputStream(zip.inputStream().buffered()).use { zis ->
                var e = zis.nextEntry
                while (e != null) {
                    val out = File(base, e.name)
                    if (!out.canonicalPath.startsWith(base.canonicalPath)) throw SecurityException("bad zip entry")
                    if (e.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { zis.copyTo(it) }
                    }
                    zis.closeEntry()
                    e = zis.nextEntry
                }
            }
            zip.delete()
            AlfredState.modelProgress.value = 100
            true
        } catch (e: Exception) {
            AlfredState.modelProgress.value = -1
            AlfredState.error.value = "Model download failed: ${e.message}"
            false
        }
    }
}
