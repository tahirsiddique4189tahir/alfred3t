@file:OptIn(ExperimentalMaterial3Api::class)

package com.alfred.tahir

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ------------------------------------------------------------------ 1. welcome

@Composable
fun WelcomeScreen(onStart: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.weight(1f))
        OrbPreview(Orb.IDLE, 0, 250.dp, 0, -1f)
        Spacer(Modifier.height(10.dp))
        Text("Alfred", fontSize = 48.sp, fontWeight = FontWeight.Medium, color = UI.Navy)
        Spacer(Modifier.height(6.dp))
        Text(L.s("welcome_sub"), fontSize = 17.sp, color = UI.Ink)
        Spacer(Modifier.height(26.dp))
        Text(L.s("welcome_tag"), fontSize = 15.sp, color = UI.Ink.copy(alpha = 0.85f))
        Spacer(Modifier.weight(1f))
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(36.dp)).background(UI.Panel.copy(alpha = 0.55f)).padding(8.dp)
        ) {
            GradientButton(
                L.s("get_started"), onStart, Modifier.fillMaxWidth(), height = 54.dp,
                trailing = { Glyph(G.ARROW, Color.White, 20.dp) }
            )
        }
        Spacer(Modifier.height(36.dp))
    }
}

// ------------------------------------------------------------------ gate (accessibility must be on)

@Composable
fun GateScreen() {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        ChipRow(
            listOf("auto" to L.s("auto"), "en" to "English", "bn" to "বাংলা", "hi" to "हिन्दी"),
            L.ui
        ) { L.set(it) }
        Spacer(Modifier.height(20.dp))
        OrbPreview(Orb.IDLE, Prefs.orbColor, 190.dp, 0, Prefs.orbHue)
        Spacer(Modifier.height(8.dp))
        Text("Alfred", fontSize = 36.sp, fontWeight = FontWeight.Medium, color = UI.Navy)
        Spacer(Modifier.height(16.dp))
        GlassCard(L.s("gate_title")) {
            Text(L.s("gate_body"), color = UI.Ink, fontSize = 15.sp)
            Spacer(Modifier.height(10.dp))
            Text(L.s("gate_hint"), color = UI.Sub, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
            GradientButton(
                L.s("open_acc"),
                { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                Modifier.fillMaxWidth()
            )
        }
    }
}

// ------------------------------------------------------------------ 2. home

@Composable
fun statusLabel(o: Orb): String = when (o) {
    Orb.OFF -> L.s("st_off")
    Orb.IDLE -> L.s("st_idle")
    Orb.LISTENING -> L.s("st_listen")
    Orb.THINKING -> L.s("st_think")
    Orb.SPEAKING -> L.s("st_speak")
}

@Composable
fun StepRow(done: Boolean, label: String, action: String? = null, onClick: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            if (done) "✓" else "•",
            color = if (done) UI.Good else UI.Blue,
            fontSize = 20.sp,
            modifier = Modifier.width(28.dp)
        )
        Text(label, Modifier.weight(1f), color = UI.Ink, fontSize = 15.sp)
        if (!done && action != null) TextButton(onClick = onClick) { Text(action, color = UI.Blue) }
    }
}

@Composable
fun JarvisTelemetryCard(onRefresh: () -> Unit) {
    val batPct by AlfredState.batteryPct.collectAsState()
    val isCharging by AlfredState.batteryCharging.collectAsState()
    val batTemp by AlfredState.batteryTemp.collectAsState()

    val wTemp by AlfredState.weatherTemp.collectAsState()
    val wDesc by AlfredState.weatherDesc.collectAsState()
    val wIcon by AlfredState.weatherIcon.collectAsState()
    val wCity by AlfredState.weatherCity.collectAsState()
    val wHum by AlfredState.weatherHumidity.collectAsState()

    Column(
        Modifier
            .fillMaxWidth()
            .glass(22.dp, 0.76f)
            .clickable(onClick = onRefresh)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(UI.Good))
            Spacer(Modifier.width(8.dp))
            Text(
                "JARVIS TELEMETRY",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = UI.Navy,
                letterSpacing = 2.sp,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                modifier = Modifier.weight(1f)
            )
            Text(
                wCity.ifBlank { "ONLINE" }.uppercase(),
                fontSize = 11.sp,
                color = UI.Sub,
                letterSpacing = 1.sp,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            // Weather
            Row(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(UI.Tile)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(wIcon, fontSize = 24.sp)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(wTemp, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = UI.Ink)
                    Text("$wDesc • $wHum", fontSize = 11.sp, color = UI.Sub, maxLines = 1)
                }
            }
            // Battery
            Row(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(UI.Tile)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(if (isCharging) "⚡" else "🔋", fontSize = 22.sp)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("$batPct%", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = if (batPct > 20) UI.Ink else UI.Bad)
                    Text(
                        if (isCharging) "Charging • ${String.format(java.util.Locale.US, "%.0f", batTemp)}°C" 
                        else "Normal • ${String.format(java.util.Locale.US, "%.0f", batTemp)}°C", 
                        fontSize = 11.sp, color = UI.Sub, maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
fun ThemePickerModal(onDismiss: () -> Unit, onSelect: (Int) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose UI Theme Color", color = UI.Ink, fontWeight = FontWeight.SemiBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                UiThemeManager.themes.forEach { t ->
                    val sel = Prefs.uiTheme == t.id
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (sel) t.tile else UI.Panel)
                            .border(if (sel) 2.dp else 1.dp, t.primary, RoundedCornerShape(14.dp))
                            .clickable { onSelect(t.id); onDismiss() }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(24.dp).clip(CircleShape).background(t.primary))
                        Spacer(Modifier.width(14.dp))
                        Text(t.name, fontSize = 15.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium, color = UI.Ink, modifier = Modifier.weight(1f))
                        if (sel) Text("✓", color = t.primary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close", color = UI.Blue) } },
        containerColor = UI.Panel
    )
}

@Composable
private fun ActionItem(bg: Color, label: String, onClick: () -> Unit, glyph: @Composable () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        IconTile(bg, 52.dp) { glyph() }
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 12.sp, color = UI.Ink)
    }
}

@Composable
fun HomeScreen(
    nav: (String) -> Unit,
    micOk: Boolean,
    requestPerms: () -> Unit,
    onStartLiveVision: () -> Unit = {}
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val orb by AlfredState.orb.collectAsState()
    val running by AlfredState.running.collectAsState()
    val progress by AlfredState.modelProgress.collectAsState()
    val said by AlfredState.lastSaid.collectAsState()
    val err by AlfredState.error.collectAsState()

    var keySet by remember { mutableStateOf(Prefs.apiKey.isNotBlank()) }
    var keyInput by remember { mutableStateOf("") }
    var modelReady by remember { mutableStateOf(ModelManager.isReady(ctx)) }
    LaunchedEffect(progress) { modelReady = ModelManager.isReady(ctx) }
    val ready = micOk && keySet && modelReady

    val toggle: () -> Unit = {
        if (running) {
            AssistantService.stop(ctx)
        } else if (ready) {
            AssistantService.start(ctx)
        }
    }
    val onMic: () -> Unit = {
        if (ready) {
            val svc = AssistantService.instance
            if (!running || svc == null) {
                AssistantService.start(ctx)
            } else if (svc.isBusy()) {
                svc.interrupt()
            } else {
                svc.manualTrigger()
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        var showThemePicker by remember { mutableStateOf(false) }
        if (showThemePicker) {
            ThemePickerModal(
                onDismiss = { showThemePicker = false },
                onSelect = { Prefs.uiTheme = it }
            )
        }

        // top bar
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            MiniOrb(40.dp)
            Spacer(Modifier.width(10.dp))
            Text("ALFRED", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = UI.Navy, letterSpacing = 5.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, modifier = Modifier.weight(1f))
            Box(
                Modifier.size(42.dp).glass(21.dp, 0.75f).clickable { showThemePicker = true },
                contentAlignment = Alignment.Center
            ) { Glyph(G.SPARK, UI.Blue, 20.dp) }
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.size(42.dp).glass(21.dp, 0.75f).clickable { toggle() },
                contentAlignment = Alignment.Center
            ) { Glyph(G.POWER, if (running) UI.Good else UI.Sub, 20.dp) }
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.size(42.dp).glass(21.dp, 0.75f).clickable { nav("settings") },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.Settings, contentDescription = L.s("settings"), tint = UI.Blue, modifier = Modifier.size(22.dp)) }
        }
        Spacer(Modifier.height(14.dp))

        // Jarvis Live Telemetry HUD (Weather, Temp, Battery)
        JarvisTelemetryCard { scope.launch { TelemetryManager.refresh() } }
        Spacer(Modifier.height(14.dp))

        // speech bubble
        Box(Modifier.fillMaxWidth()) {
            Row(
                Modifier.fillMaxWidth().glass(28.dp, 0.80f).padding(horizontal = 22.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    if (said.isBlank()) {
                        Text(L.s("hello_im"), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = UI.Navy)
                        Text(L.s("how_help"), fontSize = 13.sp, color = UI.Ink)
                    } else {
                        Text(said, fontSize = 15.sp, color = UI.Ink, maxLines = 5)
                    }
                }
                Spacer(Modifier.width(10.dp))
                Glyph(G.WAVE, UI.Blue, 28.dp)
            }
            Canvas(Modifier.align(Alignment.BottomEnd).padding(end = 60.dp).offset(y = 15.dp).size(26.dp, 18.dp)) {
                val p = Path()
                p.moveTo(0f, 0f)
                p.lineTo(size.width, 0f)
                p.lineTo(size.width * 0.35f, size.height)
                p.close()
                drawPath(p, UI.Panel.copy(alpha = 0.80f))
            }
        }
        Spacer(Modifier.height(10.dp))

        // big orb with soft ground shadow
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(
                Modifier.align(Alignment.BottomCenter).offset(y = 4.dp).width(170.dp).height(26.dp)
                    .background(Brush.radialGradient(listOf(Color(0x6622D3EE), Color.Transparent)))
            )
            OrbPreview(orb, Prefs.orbColor, 250.dp)
        }
        if (err.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(err, color = UI.Bad, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(12.dp))

        if (!ready) {
            GlassCard(L.s("setup")) {
                StepRow(micOk, L.s("step_mic"), L.s("grant"), requestPerms)
                StepRow(keySet, L.s("step_key"))
                if (!keySet) {
                    OutlinedTextField(
                        value = keyInput,
                        onValueChange = { keyInput = it },
                        label = { Text(L.s("api_key")) },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
                        }) { Text(L.s("get_key"), color = UI.Blue) }
                        TextButton(onClick = {
                            Prefs.apiKey = keyInput
                            keySet = Prefs.apiKey.isNotBlank()
                        }) { Text(L.s("save"), color = UI.Blue, fontWeight = FontWeight.SemiBold) }
                    }
                }
                StepRow(modelReady, L.s("step_model"), L.s("download")) {
                    scope.launch { ModelManager.download(ctx.applicationContext) }
                }
                if (progress in 0..99) {
                    LinearProgressIndicator(progress = progress / 100f, modifier = Modifier.fillMaxWidth())
                }
            }
            Spacer(Modifier.height(14.dp))
        }

        // Talk / Search / Control / More
        Row(
            Modifier.fillMaxWidth().glass(26.dp, 0.72f).padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            ActionItem(UI.Tile, L.s("talk"), { onMic() }) { Glyph(G.MIC, UI.Blue, 24.dp) }
            ActionItem(UI.Tile, L.s("search"), { nav("chat") }) {
                Icon(Icons.Rounded.Search, contentDescription = null, tint = UI.Blue, modifier = Modifier.size(24.dp))
            }
            ActionItem(UI.Tile, L.s("control"), { nav("quick") }) { Glyph(G.FLOWER, UI.Good, 24.dp) }
            ActionItem(UI.Tile, L.s("more"), { nav("settings") }) { Glyph(G.GRID, UI.Blue, 24.dp) }
        }
        Spacer(Modifier.height(14.dp))
        SoftButton(
            text = "Live Eye (Screen Share)",
            onClick = onStartLiveVision,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(14.dp))

        // status strip
        Row(
            Modifier.fillMaxWidth().glass(24.dp, 0.55f).padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Glyph(G.WAVE, UI.Blue, 16.dp)
            Spacer(Modifier.width(8.dp))
            Text(statusLabel(orb).uppercase(), fontSize = 12.sp, fontWeight = FontWeight.Medium, color = UI.Navy, letterSpacing = 2.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
        }
        Spacer(Modifier.height(16.dp))

        // big mic + keyboard
        Box(Modifier.fillMaxWidth().height(76.dp)) {
            Box(
                Modifier.align(Alignment.Center).size(70.dp)
                    .shadow(14.dp, CircleShape, ambientColor = UI.Violet, spotColor = UI.Blue)
                    .clip(CircleShape).background(UI.MicBrush).clickable { onMic() },
                contentAlignment = Alignment.Center
            ) { Glyph(G.MIC, Color.White, 30.dp) }
            Box(
                Modifier.align(Alignment.CenterEnd).size(48.dp).clip(CircleShape).clickable { nav("chat") },
                contentAlignment = Alignment.Center
            ) { Glyph(G.KEYBOARD, UI.Sub, 26.dp) }
        }
        Spacer(Modifier.height(8.dp))
    }
}

// ------------------------------------------------------------------ 3. chat

suspend fun sendChat(ctx: Context, text: String) {
    val key = Prefs.apiKey
    if (key.isBlank()) {
        AlfredState.addChat(true, text)
        AlfredState.addChat(false, L.s("chat_need_setup"))
        return
    }
    AlfredState.addChat(true, text)
    AlfredState.chatBusy.value = true
    try {
        val reply = Gemini.chatText(Prefs.effectiveModel(), text)
        AlfredState.addChat(false, reply)
        Store.addHistory(text, reply, "")
    } catch (e: Exception) {
        AlfredState.addChat(false, "⚠ " + (e.message ?: "Failed to get response"))
    } finally {
        AlfredState.chatBusy.value = false
    }
}

@Composable
private fun UserBubble(text: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Box(
            Modifier.widthIn(max = 290.dp)
                .clip(RoundedCornerShape(22.dp, 22.dp, 6.dp, 22.dp))
                .background(UI.Tile)
                .padding(horizontal = 18.dp, vertical = 12.dp)
        ) { Text(text, color = UI.Ink, fontSize = 15.sp) }
    }
}

@Composable
private fun AlfredBubble(text: String, onSpeak: (() -> Unit)?) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        MiniOrb(38.dp)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.widthIn(max = 280.dp).glass(22.dp, 0.88f).padding(start = 16.dp, top = 12.dp, end = 12.dp, bottom = 10.dp)) {
            Column {
                Text(text, color = UI.Ink, fontSize = 15.sp)
                if (onSpeak != null) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Box(Modifier.size(28.dp).clip(CircleShape).clickable { onSpeak() }, contentAlignment = Alignment.Center) {
                            Glyph(G.SPEAKER, UI.Sub, 18.dp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatScreen(onBack: () -> Unit, onHistory: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val msgs by AlfredState.chat.collectAsState()
    val busy by AlfredState.chatBusy.collectAsState()
    var input by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    val scroll = rememberScrollState()
    LaunchedEffect(msgs.size, busy) { scroll.animateScrollTo(scroll.maxValue) }

    // Mute microphone while chatting so typing never triggers voice recording
    DisposableEffect(Unit) {
        AssistantService.instance?.micMutedForChat = true
        onDispose {
            AssistantService.instance?.micMutedForChat = false
        }
    }

    val send: () -> Unit = {
        val t = input.trim()
        if (t.isNotEmpty()) {
            input = ""
            scope.launch { sendChat(ctx, t) }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = L.s("back"), tint = UI.Ink)
            }
            MiniOrb(40.dp)
            Spacer(Modifier.width(10.dp))
            Text("Alfred", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = UI.Navy, modifier = Modifier.weight(1f))
            Box {
                IconButton(onClick = { menu = true }) {
                    Icon(Icons.Rounded.MoreVert, contentDescription = null, tint = UI.Ink)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text(L.s("clear_chat")) },
                        onClick = { menu = false; AlfredState.chat.value = emptyList() }
                    )
                    DropdownMenuItem(
                        text = { Text(L.s("open_history")) },
                        onClick = { menu = false; onHistory() }
                    )
                }
            }
        }
        Column(
            Modifier.weight(1f).verticalScroll(scroll).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (msgs.isEmpty()) AlfredBubble(L.s("chat_hello"), null)
            msgs.forEach { m ->
                if (m.fromUser) UserBubble(m.text)
                else AlfredBubble(m.text) { 
                    scope.launch {
                        val svc = AssistantService.instance
                        if (svc != null) svc.announce(m.text) else Speaker(ctx).say(m.text, "en-US")
                    }
                }
            }
            if (busy) AlfredBubble("…", null)
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                Modifier.weight(1f).glass(30.dp, 0.85f).padding(horizontal = 20.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    textStyle = TextStyle(color = UI.Ink, fontSize = 15.sp),
                    cursorBrush = SolidColor(UI.Blue),
                    maxLines = 4,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { send() }),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (input.isEmpty()) Text(L.s("type_msg"), color = UI.Sub, fontSize = 15.sp)
                            inner()
                        }
                    }
                )
            }
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier.size(52.dp).clip(CircleShape).background(UI.SendBrush).clickable { send() },
                contentAlignment = Alignment.Center
            ) { Glyph(G.PLANE, Color.White, 22.dp) }
        }
    }
}

// ------------------------------------------------------------------ 6. quick controls

private fun accOrToast(ctx: Context): AlfredAccessibilityService? {
    val a = AlfredAccessibilityService.instance
    if (a == null) Toast.makeText(ctx, L.s("acc_off"), Toast.LENGTH_SHORT).show()
    return a
}

private fun goBackground(ctx: Context) {
    (ctx as? Activity)?.moveTaskToBack(true)
}

private fun launchIntent(ctx: Context, i: Intent) {
    try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(ctx, e.message ?: "error", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun QuickCard(modifier: Modifier, bg: Color, title: String, sub: String, onClick: () -> Unit, glyph: @Composable () -> Unit) {
    Column(
        modifier.glass(22.dp, 0.74f).clickable(onClick = onClick).padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        IconTile(bg, 44.dp) { glyph() }
        Spacer(Modifier.height(14.dp))
        Column {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = UI.Ink)
            Spacer(Modifier.height(2.dp))
            Text(sub, fontSize = 12.sp, color = UI.Sub)
        }
    }
}

@Composable
fun QuickScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var dialog by remember { mutableStateOf("") }
    var typeText by remember { mutableStateOf("") }
    val orb by AlfredState.orb.collectAsState()

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, contentDescription = L.s("back"), tint = UI.Ink) }
            Text(L.s("quick_controls"), fontSize = 21.sp, fontWeight = FontWeight.SemiBold, color = UI.Ink)
        }
        Text(
            L.s("quick_sub"), fontSize = 13.sp, color = UI.Sub,
            modifier = Modifier.padding(start = 24.dp, bottom = 12.dp)
        )
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickCard(Modifier.weight(1f).height(124.dp), UI.Tile, L.s("qc_open"), L.s("qc_open_s"), { dialog = "apps" }) {
                    Glyph(G.OPENAPP, UI.Blue, 22.dp)
                }
                QuickCard(Modifier.weight(1f).height(124.dp), UI.Tile, L.s("qc_shot"), L.s("qc_shot_s"), {
                    val acc = accOrToast(ctx)
                    if (acc != null) {
                        goBackground(ctx)
                        scope.launch { delay(700); acc.global("screenshot") }
                    }
                }) { Glyph(G.SHOT, UI.Blue, 22.dp) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickCard(Modifier.weight(1f).height(124.dp), UI.Tile, L.s("qc_scroll"), L.s("qc_scroll_s"), { dialog = "scroll" }) {
                    Glyph(G.UPDOWN, UI.Good, 22.dp)
                }
                QuickCard(Modifier.weight(1f).height(124.dp), UI.Tile, L.s("qc_text"), L.s("qc_text_s"), { dialog = "text" }) {
                    Glyph(G.TEXTA, UI.Blue, 22.dp)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickCard(Modifier.weight(1f).height(124.dp), UI.Tile, L.s("qc_phone"), L.s("qc_phone_s"), { dialog = "phone" }) {
                    Icon(Icons.Rounded.Call, contentDescription = null, tint = UI.Good, modifier = Modifier.size(22.dp))
                }
                QuickCard(Modifier.weight(1f).height(124.dp), UI.Tile, L.s("qc_sys"), L.s("qc_sys_s"), { dialog = "sys" }) {
                    Icon(Icons.Rounded.Settings, contentDescription = null, tint = UI.Warn, modifier = Modifier.size(22.dp))
                }
            }
            Spacer(Modifier.height(10.dp))
        }
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 36.dp, topEnd = 36.dp, bottomEnd = 0.dp, bottomStart = 0.dp))
                .background(Brush.verticalGradient(listOf(Color(0x00020A14), Color(0xCC020A14))))
                .padding(top = 6.dp, bottom = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OrbPreview(orb, Prefs.orbColor, 84.dp)
            Spacer(Modifier.height(4.dp))
            Row(
                Modifier.glass(26.dp, 0.80f).padding(horizontal = 22.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Glyph(G.WAVE, UI.Blue, 18.dp)
                Spacer(Modifier.width(10.dp))
                Text(L.s("say_hi"), fontSize = 14.sp, color = UI.Ink)
            }
        }
    }

    when (dialog) {
        "apps" -> {
            val apps = remember { AppLauncher.list(ctx) }
            AlertDialog(
                onDismissRequest = { dialog = "" },
                title = { Text(L.s("pick_app"), color = UI.Ink) },
                text = {
                    LazyColumn(Modifier.height(380.dp)) {
                        items(apps) { app ->
                            Text(
                                app.label,
                                Modifier.fillMaxWidth().clickable {
                                    dialog = ""
                                    ctx.packageManager.getLaunchIntentForPackage(app.pkg)?.let { launchIntent(ctx, it) }
                                }.padding(vertical = 12.dp),
                                color = UI.Ink, fontSize = 15.sp
                            )
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { dialog = "" }) { Text(L.s("close")) } },
                containerColor = UI.Panel
            )
        }
        "scroll" -> OptionDialog(
            L.s("qc_scroll"),
            listOf(
                L.s("scroll_up") to {
                    accOrToast(ctx)?.let { acc -> goBackground(ctx); scope.launch { delay(700); acc.scroll("up") } }
                    Unit
                },
                L.s("scroll_down") to {
                    accOrToast(ctx)?.let { acc -> goBackground(ctx); scope.launch { delay(700); acc.scroll("down") } }
                    Unit
                }
            )
        ) { dialog = "" }
        "text" -> AlertDialog(
            onDismissRequest = { dialog = "" },
            title = { Text(L.s("qc_text"), color = UI.Ink) },
            text = {
                Column {
                    OutlinedTextField(
                        value = typeText, onValueChange = { typeText = it },
                        label = { Text(L.s("text_to_type")) }, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(L.s("type_hint"), fontSize = 12.sp, color = UI.Sub)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val t = typeText
                    dialog = ""
                    val acc = accOrToast(ctx)
                    if (acc != null && t.isNotBlank()) {
                        goBackground(ctx)
                        scope.launch { delay(800); acc.typeText(t, false) }
                    }
                }) { Text(L.s("type_now"), color = UI.Blue) }
            },
            dismissButton = { TextButton(onClick = { dialog = "" }) { Text(L.s("close")) } },
            containerColor = UI.Panel
        )
        "phone" -> OptionDialog(
            L.s("qc_phone"),
            listOf(
                L.s("open_dialer") to { launchIntent(ctx, Intent(Intent.ACTION_DIAL)) },
                L.s("open_messages") to { launchIntent(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"))) }
            )
        ) { dialog = "" }
        "sys" -> OptionDialog(
            L.s("sys_pick"),
            listOf(
                "Wi‑Fi" to { launchIntent(ctx, Intent(Settings.ACTION_WIFI_SETTINGS)) },
                "Bluetooth" to { launchIntent(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) },
                "Display" to { launchIntent(ctx, Intent(Settings.ACTION_DISPLAY_SETTINGS)) },
                "Sound" to { launchIntent(ctx, Intent(Settings.ACTION_SOUND_SETTINGS)) },
                L.s("all_settings") to { launchIntent(ctx, Intent(Settings.ACTION_SETTINGS)) }
            )
        ) { dialog = "" }
    }
}

// ------------------------------------------------------------------ 4. settings list + bottom bar

@Composable
private fun NavItem(label: String, selected: Boolean, onClick: () -> Unit, glyph: @Composable (Color) -> Unit) {
    val tint = if (selected) UI.Blue else UI.Sub
    Column(
        Modifier.clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(horizontal = 22.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        glyph(tint)
        Spacer(Modifier.height(3.dp))
        Text(label, fontSize = 11.sp, color = tint, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
fun BottomBar(selected: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp, bottomEnd = 0.dp, bottomStart = 0.dp))
            .background(UI.Panel.copy(alpha = 0.92f))
            .padding(top = 8.dp, bottom = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        NavItem(L.s("nav_home"), selected == "home", { onSelect("home") }) {
            Icon(Icons.Rounded.Home, contentDescription = null, tint = it, modifier = Modifier.size(24.dp))
        }
        NavItem(L.s("nav_chat"), selected == "chat", { onSelect("chat") }) { Glyph(G.CHAT, it, 24.dp) }
        NavItem(L.s("nav_settings"), selected == "settings", { onSelect("settings") }) {
            Icon(Icons.Rounded.Settings, contentDescription = null, tint = it, modifier = Modifier.size(24.dp))
        }
    }
}

@Composable
private fun SettingRow(bg: Color, title: String, sub: String, onClick: () -> Unit, glyph: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().glass(18.dp, 0.74f).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconTile(bg, 44.dp) { glyph() }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = UI.Ink)
            Text(sub, fontSize = 12.sp, color = UI.Sub)
        }
        Glyph(G.CHEVRON, UI.Sub, 20.dp)
    }
}

@Composable
fun SettingsListScreen(nav: (String) -> Unit, onTab: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(Modifier.padding(bottom = 10.dp, start = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                MiniOrb(54.dp)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Alfred", fontSize = 26.sp, fontWeight = FontWeight.SemiBold, color = UI.Navy)
                    Text(L.s("set_sub"), fontSize = 13.sp, color = UI.Sub)
                }
            }
            SettingRow(UI.Tile, L.s("row_ai"), L.s("row_ai_s"), { nav("s_ai") }) { Glyph(G.SPARK, UI.Warn, 22.dp) }
            SettingRow(UI.Tile, L.s("row_voice"), L.s("row_voice_s"), { nav("s_voice") }) { Glyph(G.HEAD, UI.Good, 22.dp) }
            SettingRow(UI.Tile, "ভয়েস লক ও আনলক (Security)", "Face, PIN, Password ও 3x3 প্যাটার্ন", { nav("s_lock") }) { Glyph(G.ACCESS, UI.Good, 22.dp) }
            SettingRow(UI.Tile, L.s("row_orb"), L.s("row_orb_s"), { nav("orb") }) { Glyph(G.ORB, UI.Violet, 22.dp) }
            SettingRow(UI.Tile, L.s("row_acc"), L.s("row_acc_s"), { nav("s_acc") }) { Glyph(G.ACCESS, UI.Blue, 22.dp) }
            SettingRow(UI.Tile, L.s("row_mem"), L.s("row_mem_s"), { nav("s_memory") }) { Glyph(G.CLIP, UI.Good, 22.dp) }
            SettingRow(UI.Tile, L.s("row_notif"), L.s("row_notif_s"), { nav("s_notif") }) {
                Icon(Icons.Rounded.Notifications, contentDescription = null, tint = UI.Warn, modifier = Modifier.size(22.dp))
            }
            SettingRow(UI.Tile, L.s("row_gen"), L.s("row_gen_s"), { nav("s_general") }) {
                Icon(Icons.Rounded.Settings, contentDescription = null, tint = UI.Blue, modifier = Modifier.size(22.dp))
            }
        }
        BottomBar("settings", onTab)
    }
}

// ------------------------------------------------------------------ 5. floating orb editor

@Composable
fun OrbScreen(onBack: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    var style by remember { mutableStateOf(Prefs.orbStyle) }
    var color by remember { mutableStateOf(Prefs.orbColor) }
    var hue by remember { mutableStateOf(Prefs.orbHue) }
    var size by remember { mutableStateOf(Prefs.orbSize.toFloat()) }
    var opacity by remember { mutableStateOf(Prefs.orbOpacity) }
    val tabs = listOf(L.s("tab_style"), L.s("tab_color"), "Theme", "App Icon", L.s("tab_size"), L.s("tab_opacity"))

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, contentDescription = L.s("back"), tint = UI.Ink) }
            Text(L.s("row_orb"), fontSize = 21.sp, fontWeight = FontWeight.SemiBold, color = UI.Ink)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OrbPreview(Orb.IDLE, color, 200.dp, style, hue, Modifier.alpha(opacity))
            Spacer(Modifier.height(10.dp))
            Column(Modifier.fillMaxWidth().glass(26.dp, 0.72f).padding(16.dp)) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    tabs.forEachIndexed { i, t -> Chip(t, tab == i) { tab = i } }
                }
                Spacer(Modifier.height(16.dp))

                if (tab == 0) {
                    OrbStyles.allSections.forEach { (title, ids) ->
                        Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = UI.Ink,
                            modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
                        ids.chunked(4).forEach { rowItems ->
                            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                rowItems.forEach { i ->
                                    val sel = style == i
                                    val shape = RoundedCornerShape(16.dp)
                                    Box(
                                        Modifier.weight(1f).aspectRatio(1f).clip(shape)
                                            .background(if (sel) UI.Tile else UI.Panel.copy(alpha = 0.75f))
                                            .border(if (sel) 2.dp else 1.dp, if (sel) UI.Blue else Color(0x4422D3EE), shape)
                                            .clickable { style = i },
                                        contentAlignment = Alignment.Center
                                    ) { OrbPreview(Orb.IDLE, color, 52.dp, i, hue) }
                                }
                                repeat(4 - rowItems.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                }
                if (tab == 1) {
                    Spacer(Modifier.height(6.dp))
                    OrbPalette.pairs.chunked(6).forEachIndexed { r, row ->
                        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            row.forEachIndexed { c, p ->
                                val i = r * 6 + c
                                val sel = color == i && hue < 0f
                                Box(
                                    Modifier.size(34.dp).clip(CircleShape)
                                        .background(Brush.linearGradient(listOf(Color(p.first), Color(p.second))))
                                        .border(if (sel) 3.dp else 0.dp, if (sel) UI.Ink else Color.Transparent, CircleShape)
                                        .clickable { color = i; hue = -1f }
                                )
                            }
                            repeat(6 - row.size) { Spacer(Modifier.size(34.dp)) }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Label(L.s("orb_hue"))
                    Slider(
                        value = if (hue < 0f) 0f else hue,
                        onValueChange = { hue = it },
                        valueRange = 0f..360f,
                        colors = sliderColors()
                    )
                }
                if (tab == 2) {
                    Label("Select UI Color Theme")
                    Spacer(Modifier.height(10.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        UiThemeManager.themes.forEach { t ->
                            val sel = Prefs.uiTheme == t.id
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (sel) t.tile else UI.Panel.copy(alpha = 0.8f))
                                    .border(if (sel) 2.dp else 1.dp, t.primary, RoundedCornerShape(14.dp))
                                    .clickable { Prefs.uiTheme = t.id }
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(24.dp).clip(CircleShape).background(t.primary))
                                Spacer(Modifier.width(14.dp))
                                Text(t.name, fontSize = 15.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium, color = UI.Ink, modifier = Modifier.weight(1f))
                                if (sel) Text("✓", color = t.primary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            }
                        }
                    }
                }
                if (tab == 3) {
                    val ctx = LocalContext.current
                    var currentIcon by remember { mutableStateOf(IconHelper.getCurrentIconAlias(ctx)) }
                    Label("Choose any app icon for your home screen:")
                    Spacer(Modifier.height(10.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        IconHelper.availableIcons.chunked(2).forEach { rowIcons ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                rowIcons.forEach { iconItem ->
                                    val isCurrent = currentIcon == iconItem.alias
                                    Column(
                                        Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(16.dp))
                                            .background(if (isCurrent) UI.Tile else UI.Panel.copy(alpha = 0.75f))
                                            .border(if (isCurrent) 2.dp else 1.dp, if (isCurrent) UI.Blue else UI.Blue.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                                            .clickable {
                                                IconHelper.changeAppIcon(ctx, iconItem.alias)
                                                OrbPrefs.saveAppIcon(ctx, iconItem.alias)
                                                currentIcon = iconItem.alias
                                                Toast.makeText(ctx, "App icon updated to ${iconItem.name}", Toast.LENGTH_SHORT).show()
                                            }
                                            .padding(12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        OrbPreview(Orb.IDLE, color, 48.dp, iconItem.style, hue)
                                        Spacer(Modifier.height(6.dp))
                                        Text(iconItem.name, fontSize = 12.sp, fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal, color = UI.Ink, textAlign = TextAlign.Center)
                                        if (isCurrent) {
                                            Spacer(Modifier.height(4.dp))
                                            Text("ACTIVE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = UI.Good)
                                        }
                                    }
                                }
                                if (rowIcons.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        SoftButton("Reset to Default Icon", {
                            IconHelper.changeAppIcon(ctx, "MainActivityAliasDefault")
                            OrbPrefs.saveAppIcon(ctx, "MainActivityAliasDefault")
                            currentIcon = "MainActivityAliasDefault"
                            Toast.makeText(ctx, "Default icon restored", Toast.LENGTH_SHORT).show()
                        }, modifier = Modifier.fillMaxWidth())
                    }
                }
                if (tab == 4) {
                    Label(L.s("orb_size") + ": " + size.toInt() + " dp")
                    Slider(value = size, onValueChange = { size = it }, valueRange = 40f..110f, colors = sliderColors())
                }
                if (tab == 5) {
                    Label(L.s("orb_opacity") + ": " + (opacity * 100).toInt() + "%")
                    Slider(value = opacity, onValueChange = { opacity = it }, valueRange = 0.35f..1f, colors = sliderColors())
                }
            }
            Spacer(Modifier.height(16.dp))
        }
        GradientButton(
            L.s("apply"),
            {
                Prefs.orbStyle = style
                Prefs.orbColor = color
                Prefs.orbHue = hue
                Prefs.orbSize = size.toInt()
                Prefs.orbOpacity = opacity
                onBack()
            },
            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
            height = 56.dp
        )
    }
}
