package com.alfred.tahir

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import androidx.core.graphics.ColorUtils
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Style ids:
 *   0        = classic orb (OrbView er nijer drawing)
 *   1..N     = ager AvatarPainter er character gulo (agar moto thakbe)
 *   100..109 = Creative orb
 *   200..210 = Character style
 *   300..309 = Premium style
 */
object OrbStyles {
    /** AvatarPainter e ager joto ta character ache, shei number ta ekhane boshan (picker e "Old Characters" hishebe dekhabe). 0 dile hide hobe. */
    const val LEGACY_CHAR_COUNT = 7

    class Item(val id: Int, val name: String)

    val classic = listOf(Item(0, "Jarvis HUD"))

    val creative = listOf(
        Item(100, "Galaxy Orb"), Item(101, "Crystal Orb"), Item(102, "Liquid Orb"),
        Item(103, "Neon Ring Orb"), Item(104, "Aurora Flow"), Item(105, "Fire Orb"),
        Item(106, "Ice Orb"), Item(107, "Leaf Orb"), Item(108, "Ocean Orb"), Item(109, "Circuit Orb")
    )

    val characters = listOf(
        Item(200, "Robot"), Item(201, "Cat"), Item(202, "Bunny"), Item(203, "Alien"),
        Item(204, "Fox"), Item(205, "Panda"), Item(206, "Knight"), Item(207, "Space"),
        Item(208, "Penguin"), Item(209, "Angel"), Item(210, "Dragon")
    )

    val premium = listOf(
        Item(300, "Glass Orb"), Item(301, "Metallic Orb"), Item(302, "Hologram Orb"),
        Item(303, "Diamond Orb"), Item(304, "Flame Orb"), Item(305, "Nebula Orb"),
        Item(306, "Crown Orb"), Item(307, "Heart Orb"), Item(308, "Dual Ring Orb"), Item(309, "Pulse Orb")
    )

    /** OrbScreen e dekhanor jonno shob style er id, section onujayi */
    val allSections: List<Pair<String, List<Int>>> get() = listOf(
        "Classic" to classic.map { it.id },
        "Old Characters" to (1..LEGACY_CHAR_COUNT).toList(),
        "Creative" to creative.map { it.id },
        "Characters" to characters.map { it.id },
        "Premium" to premium.map { it.id }
    )

    val paletteNames = listOf(
        "Arc Cyan", "Violet", "Periwinkle", "Blue", "Sky", "Mint",
        "Orange", "Pink", "Teal", "Yellow", "Red"
    )
}

class StylePainter {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val offPaint = Paint().apply {
        colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0.08f) })
        alpha = 190
    }
    private val stars = Random(7).let { rnd ->
        List(18) {
            floatArrayOf(rnd.nextFloat() * 360f, sqrt(rnd.nextFloat()) * 0.88f, 0.014f + rnd.nextFloat() * 0.022f, rnd.nextFloat())
        }
    }

    // per-frame state
    private var cx = 0f
    private var cy = 0f
    private var r = 0f
    private var R = 0f
    private var pulse = 0f
    private var phase = 0f
    private var status = Orb.IDLE
    private var off = false
    private var g1 = 0
    private var g2 = 0

    private val WHITE = Color.WHITE
    private val BLACK = Color.BLACK
    private val INK = 0xFF2A2340.toInt()
    private val CYAN = 0xFF39E0FF.toInt()

    fun draw(c: Canvas, style: Int, w: Float, h: Float, st: Orb, ph: Float, c1: Int, c2: Int) {
        status = st
        phase = ph
        off = st == Orb.OFF
        cx = w / 2f
        cy = h / 2f
        r = min(w, h) / 2f

        val mult = when (st) {
            Orb.OFF, Orb.IDLE -> 1
            Orb.LISTENING -> 2
            Orb.THINKING, Orb.SPEAKING -> 3
        }
        val amp = when (st) {
            Orb.OFF -> 0.015f
            Orb.IDLE -> 0.05f
            Orb.LISTENING -> 0.10f
            Orb.THINKING -> 0.04f
            Orb.SPEAKING -> 0.12f
        }
        pulse = 0.5f + 0.5f * sin(2.0 * PI * mult * ph).toFloat()
        R = r * ((if (style in 200..299) 0.40f else 0.46f) + amp * pulse)

        val t = themed(style, c1, c2)
        g1 = t.first
        g2 = t.second

        if (off) c.saveLayer(0f, 0f, w, h, offPaint)

        glow(c, r * (0.80f + 0.20f * pulse), g2)

        if (st == Orb.LISTENING || st == Orb.SPEAKING) {
            stroke(a(g1, ((1f - ph) * 170).toInt()), r * 0.035f)
            c.drawCircle(cx, cy, r * (0.50f + 0.45f * ph), p)
        }

        when (style) {
            100 -> galaxy(c)
            101 -> crystal(c)
            102 -> liquid(c)
            103 -> neon(c)
            104 -> auroraFlow(c)
            105 -> fire(c)
            106 -> ice(c)
            107 -> leaf(c)
            108 -> ocean(c)
            109 -> circuit(c)
            200 -> robot(c)
            201 -> cat(c)
            202 -> bunny(c)
            203 -> alien(c)
            204 -> fox(c)
            205 -> panda(c)
            206 -> knight(c)
            207 -> space(c)
            208 -> penguin(c)
            209 -> angel(c)
            210 -> dragon(c)
            300 -> glass(c)
            301 -> metallic(c)
            302 -> hologram(c)
            303 -> diamond(c)
            304 -> flame(c)
            305 -> nebula(c)
            306 -> crown(c)
            307 -> heartOrb(c)
            308 -> dualRing(c)
            309 -> pulseOrb(c)
            else -> { sphere(c, g1, g2); shine(c) }
        }

        if (st == Orb.THINKING) {
            stroke(a(WHITE, 220), r * 0.06f)
            val s = r * 0.64f
            rect.set(cx - s, cy - s, cx + s, cy + s)
            c.drawArc(rect, ph * 360f, 110f, false, p)
        }

        if (off) c.restore()
        p.shader = null
        p.pathEffect = null
        p.style = Paint.Style.FILL
    }

    /** fixed theme colours for the styles that have their own look; others follow the chosen palette */
    private fun themed(style: Int, c1: Int, c2: Int): Pair<Int, Int> {
        fun pr(x: Long, y: Long) = x.toInt() to y.toInt()
        if (c1 == 0xFFC9CCD6.toInt()) return c1 to c2 // OFF grey
        return when (style) {
            105 -> pr(0xFFFFE066, 0xFFFF4A1C)
            106 -> pr(0xFFD6F6FF, 0xFF5CC8FF)
            107 -> pr(0xFFB6F7A0, 0xFF2FA84F)
            108 -> pr(0xFF7FD3FF, 0xFF1F6FD1)
            109 -> pr(0xFF5AA8FF, 0xFF1A2F8A)
            200 -> pr(0xFFF4F7FF, 0xFFB9C6E8)
            202 -> pr(0xFFFFE3F1, 0xFFFFB5D6)
            203 -> pr(0xFF9CFFD9, 0xFF2BC8A0)
            204 -> pr(0xFFFFB066, 0xFFFF6A1F)
            205 -> pr(0xFFFFFFFF, 0xFFD8D8E0)
            206 -> pr(0xFF9FB6D6, 0xFF4A6080)
            207 -> pr(0xFFFFFFFF, 0xFFC9D3F0)
            208 -> pr(0xFF3C4A7A, 0xFF1B2347)
            209 -> pr(0xFFFFFFFF, 0xFFCFE0FF)
            210 -> pr(0xFFC58BFF, 0xFF7A3FD0)
            301 -> pr(0xFFF2F4F8, 0xFF7D8594)
            303 -> pr(0xFFFFFFFF, 0xFF9FE8FF)
            304 -> pr(0xFFFF5FD8, 0xFF7B4FF0)
            306 -> pr(0xFFFFD36B, 0xFF8A5A12)
            307 -> pr(0xFFFFB0D8, 0xFFFF2E93)
            else -> c1 to c2
        }
    }

    // ---------- helpers ----------
    private fun a(color: Int, alpha: Int) = ColorUtils.setAlphaComponent(color, alpha.coerceIn(0, 255))
    private fun mix(x: Int, y: Int, t: Float) = ColorUtils.blendARGB(x, y, t)

    private fun fill(color: Int) {
        p.shader = null; p.style = Paint.Style.FILL; p.color = color
    }

    private fun stroke(color: Int, width: Float) {
        p.shader = null; p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = width; p.color = color
    }

    private fun glow(c: Canvas, gr: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, gr, intArrayOf(a(color, 130), a(color, 0)), floatArrayOf(0.45f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, gr, p)
        p.shader = null
    }

    private fun sphere(c: Canvas, c1: Int, c2: Int, rad: Float = R) {
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            cx - rad * 0.35f, cy - rad * 0.40f, rad * 1.5f,
            intArrayOf(mix(c1, WHITE, 0.55f), c1, c2), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, rad, p)
        p.shader = null
    }

    /** dark sphere with subtle shading (space / neon / circuit style) */
    private fun flat(c: Canvas, top: Int, bottom: Int) {
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx - R * 0.3f, cy - R * 0.35f, R * 1.4f, intArrayOf(top, bottom), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R, p)
        p.shader = null
    }

    private fun shine(c: Canvas, alpha: Int = 70) {
        fill(a(WHITE, alpha))
        rect.set(cx - R * 0.62f, cy - R * 0.80f, cx + R * 0.05f, cy - R * 0.38f)
        c.drawOval(rect, p)
    }

    private fun ring(c: Canvas, color: Int, back: Boolean, tilt: Float = -18f, k: Float = 0.93f) {
        c.save()
        c.rotate(tilt, cx, cy)
        stroke(a(mix(color, WHITE, 0.55f), if (back) 90 else 190), r * 0.022f)
        rect.set(cx - r * k, cy - r * k * 0.29f, cx + r * k, cy + r * k * 0.29f)
        c.drawArc(rect, if (back) 180f else 0f, 180f, false, p)
        c.restore()
    }

    private fun clipped(c: Canvas, block: () -> Unit) {
        c.save()
        path.reset()
        path.addCircle(cx, cy, R, Path.Direction.CW)
        c.clipPath(path)
        block()
        c.restore()
    }

    private fun wave(c: Canvas, color: Int, level: Float, amp: Float, freq: Float, shift: Float) {
        path.reset()
        val left = cx - R
        val right = cx + R
        path.moveTo(left, cy + R)
        val step = R / 8f
        var x = left
        while (x <= right) {
            val y = cy + level * R + amp * R * sin((x - left) / R * freq * PI + shift * 2.0 * PI).toFloat()
            path.lineTo(x, y)
            x += step
        }
        path.lineTo(right, cy + R)
        path.close()
        fill(color)
        c.drawPath(path, p)
    }

    private fun tri(c: Canvas, color: Int, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
        path.reset()
        path.moveTo(x1, y1); path.lineTo(x2, y2); path.lineTo(x3, y3); path.close()
        fill(color)
        c.drawPath(path, p)
    }

    private fun sparkle(c: Canvas, x: Float, y: Float, s: Float, alpha: Int) {
        path.reset()
        path.moveTo(x, y - s)
        path.quadTo(x, y, x + s, y)
        path.quadTo(x, y, x, y + s)
        path.quadTo(x, y, x - s, y)
        path.quadTo(x, y, x, y - s)
        path.close()
        fill(a(WHITE, alpha))
        c.drawPath(path, p)
    }

    private fun drawStars(c: Canvas) {
        for (s in stars) {
            val ang = Math.toRadians(s[0].toDouble())
            val d = s[1] * R
            val tw = 0.5f + 0.5f * sin(2.0 * PI * (phase * 2f + s[3])).toFloat()
            fill(a(WHITE, (90 + 165 * tw).toInt()))
            c.drawCircle(cx + d * cos(ang).toFloat(), cy + d * sin(ang).toFloat(), R * s[2] * (0.7f + 0.6f * tw), p)
        }
    }

    private fun facets(c: Canvas, c1: Int, c2: Int, n: Int, rot: Float, spiky: Boolean) {
        val ox = FloatArray(n)
        val oy = FloatArray(n)
        val ix = FloatArray(n)
        val iy = FloatArray(n)
        for (i in 0 until n) {
            val ang = Math.toRadians((rot + i * 360.0 / n)).toFloat()
            val rr = if (spiky && i % 2 == 1) R * 0.80f else R
            ox[i] = cx + rr * cos(ang); oy[i] = cy + rr * sin(ang)
            ix[i] = cx + R * 0.5f * cos(ang); iy[i] = cy + R * 0.5f * sin(ang)
        }
        for (i in 0 until n) {
            val j = (i + 1) % n
            path.reset()
            path.moveTo(cx - R * 0.08f, cy - R * 0.10f)
            path.lineTo(ox[i], oy[i]); path.lineTo(ox[j], oy[j]); path.close()
            fill(mix(mix(c1, c2, (i % 4) / 3f), WHITE, if (i % 2 == 0) 0.25f else 0f))
            c.drawPath(path, p)
        }
        stroke(a(WHITE, 150), R * 0.02f)
        for (i in 0 until n) {
            val j = (i + 1) % n
            c.drawLine(ox[i], oy[i], ox[j], oy[j], p)
            c.drawLine(ox[i], oy[i], ix[i], iy[i], p)
            c.drawLine(ix[i], iy[i], ix[j], iy[j], p)
        }
    }

    private fun face(c: Canvas, y0: Float, ink: Int, mouthInk: Int = ink, mouth: Boolean = true, eyes: Boolean = true) {
        val gap = R * 0.34f
        val ey = y0 - R * 0.06f
        val er = R * 0.15f
        p.shader = null
        p.strokeCap = Paint.Cap.ROUND
        p.color = ink
        if (eyes) {
            when (status) {
                Orb.OFF -> {
                    p.style = Paint.Style.STROKE; p.strokeWidth = R * 0.075f
                    c.drawLine(cx - gap - er, ey, cx - gap + er, ey, p)
                    c.drawLine(cx + gap - er, ey, cx + gap + er, ey, p)
                }
                Orb.LISTENING -> {
                    p.style = Paint.Style.FILL
                    c.drawCircle(cx - gap, ey, er * 0.80f, p)
                    c.drawCircle(cx + gap, ey, er * 0.80f, p)
                }
                Orb.THINKING -> {
                    p.style = Paint.Style.FILL
                    val look = sin(phase * 2f * PI.toFloat()) * R * 0.05f
                    c.drawCircle(cx - gap + look, ey - R * 0.03f, er * 0.70f, p)
                    c.drawCircle(cx + gap + look, ey - R * 0.03f, er * 0.70f, p)
                }
                else -> {
                    p.style = Paint.Style.STROKE; p.strokeWidth = R * 0.085f
                    rect.set(cx - gap - er, ey - er, cx - gap + er, ey + er)
                    c.drawArc(rect, 180f, 180f, false, p)
                    rect.set(cx + gap - er, ey - er, cx + gap + er, ey + er)
                    c.drawArc(rect, 180f, 180f, false, p)
                }
            }
        }
        if (!mouth) { p.style = Paint.Style.FILL; return }
        p.color = mouthInk
        val my = y0 + R * 0.20f
        if (status == Orb.SPEAKING) {
            p.style = Paint.Style.FILL
            val open = R * (0.05f + 0.10f * pulse)
            rect.set(cx - R * 0.13f, my - R * 0.02f, cx + R * 0.13f, my + open + R * 0.04f)
            c.drawOval(rect, p)
        } else if (status == Orb.LISTENING) {
            p.style = Paint.Style.FILL
            c.drawCircle(cx, my + R * 0.03f, R * 0.06f, p)
        } else {
            p.style = Paint.Style.STROKE; p.strokeWidth = R * 0.085f
            val w = if (status == Orb.OFF) R * 0.10f else R * 0.20f
            rect.set(cx - w, my - w * 0.55f, cx + w, my + w * 0.95f)
            c.drawArc(rect, 25f, 130f, false, p)
        }
        p.style = Paint.Style.FILL
    }

    private fun cheeks(c: Canvas, color: Int, alpha: Int) {
        fill(a(color, alpha))
        c.drawCircle(cx - R * 0.62f, cy + R * 0.28f, R * 0.14f, p)
        c.drawCircle(cx + R * 0.62f, cy + R * 0.28f, R * 0.14f, p)
    }

    private fun heart(c: Canvas, x: Float, y: Float, s: Float) {
        path.reset()
        path.moveTo(x, y + s * 0.9f)
        path.cubicTo(x - s * 1.5f, y + s * 0.1f, x - s * 0.9f, y - s * 1.0f, x, y - s * 0.35f)
        path.cubicTo(x + s * 0.9f, y - s * 1.0f, x + s * 1.5f, y + s * 0.1f, x, y + s * 0.9f)
        path.close()
        c.drawPath(path, p)
    }

    // ---------- Creative ----------
    private fun galaxy(c: Canvas) {
        ring(c, g1, true)
        flat(c, mix(g2, BLACK, 0.35f), 0xFF05051A.toInt())
        clipped(c) {
            p.style = Paint.Style.FILL
            p.shader = RadialGradient(cx + R * 0.3f, cy + R * 0.2f, R * 0.9f, intArrayOf(a(g1, 110), a(g1, 0)), null, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, R, p)
            p.shader = null
            drawStars(c)
        }
        ring(c, g1, false)
        shine(c, 40)
    }

    private fun crystal(c: Canvas) {
        facets(c, g1, g2, 8, 22.5f, false)
        sparkle(c, cx - R * 0.35f, cy - R * 0.45f, R * 0.18f * (0.7f + 0.6f * pulse), 230)
    }

    private fun liquid(c: Canvas) {
        sphere(c, g1, g2)
        clipped(c) {
            wave(c, a(g2, 200), 0.05f, 0.12f, 2f, phase)
            wave(c, a(mix(g1, WHITE, 0.4f), 170), 0.25f, 0.10f, 2.5f, -phase)
            wave(c, a(0xFFFF8AD8.toInt(), 140), 0.45f, 0.10f, 1.8f, phase)
        }
        shine(c, 80)
    }

    private fun neon(c: Canvas) {
        fill(0xFF070D26.toInt())
        c.drawCircle(cx, cy, R * 0.92f, p)
        for (k in 4 downTo 1) {
            stroke(a(g1, 26), R * (0.10f + 0.07f * k))
            c.drawCircle(cx, cy, R * 0.80f, p)
        }
        stroke(mix(g1, WHITE, 0.35f), R * 0.11f)
        c.drawCircle(cx, cy, R * 0.80f, p)
        stroke(a(g2, 230), R * 0.05f)
        c.drawCircle(cx - R * 0.30f, cy, R * 0.20f, p)
        stroke(a(g1, 120), R * 0.04f)
        c.drawCircle(cx, cy, R * 0.50f, p)
        stroke(a(WHITE, 230), R * 0.07f)
        rect.set(cx - R * 0.80f, cy - R * 0.80f, cx + R * 0.80f, cy + R * 0.80f)
        c.drawArc(rect, phase * 360f, 70f, false, p)
    }

    private fun auroraFlow(c: Canvas) {
        flat(c, 0xFF0A1040.toInt(), 0xFF060822.toInt())
        clipped(c) {
            wave(c, a(g1, 150), -0.15f, 0.20f, 1.5f, phase)
            wave(c, a(g2, 150), 0.10f, 0.22f, 1.2f, -phase)
            wave(c, a(0xFF58F0B0.toInt(), 110), 0.35f, 0.18f, 1.8f, phase)
        }
        shine(c, 50)
    }

    private fun fire(c: Canvas) {
        for (i in 0..4) {
            val x = cx + (i - 2) * R * 0.30f
            val hgt = R * (0.55f + 0.30f * sin(2.0 * PI * (phase * 2f + i * 0.23f)).toFloat()) * (1f - abs(i - 2) * 0.18f)
            val w = R * 0.24f
            val base = cy - R * 0.45f
            val sway = R * 0.10f * sin(2.0 * PI * (phase + i * 0.31f)).toFloat()
            path.reset()
            path.moveTo(x - w, base)
            path.quadTo(x - w * 0.3f, base - hgt * 0.6f, x + sway, base - hgt)
            path.quadTo(x + w * 0.3f, base - hgt * 0.5f, x + w, base)
            path.close()
            fill(if (i % 2 == 0) 0xFFFF8A1F.toInt() else 0xFFFFC23D.toInt())
            c.drawPath(path, p)
        }
        sphere(c, g1, g2)
        fill(a(0xFFB05CFF.toInt(), 220))
        c.drawCircle(cx, cy, R * 0.28f * (0.9f + 0.2f * pulse), p)
        fill(a(WHITE, 200))
        c.drawCircle(cx - R * 0.06f, cy - R * 0.06f, R * 0.10f, p)
        shine(c)
    }

    private fun ice(c: Canvas) {
        facets(c, g1, g2, 12, 15f, true)
        sparkle(c, cx + R * 0.30f, cy - R * 0.40f, R * 0.16f * (0.7f + 0.6f * pulse), 230)
    }

    private fun leaf(c: Canvas) {
        for (s in floatArrayOf(-1f, 1f)) {
            c.save()
            c.rotate(s * 38f, cx, cy - R * 0.9f)
            fill(0xFF44D45E.toInt())
            rect.set(cx - R * 0.16f, cy - R * 1.55f, cx + R * 0.16f, cy - R * 0.85f)
            c.drawOval(rect, p)
            c.restore()
        }
        sphere(c, g1, g2)
        shine(c)
        stroke(a(WHITE, 140), R * 0.04f)
        rect.set(cx - R * 0.45f, cy - R * 0.25f, cx + R * 0.45f, cy + R * 0.65f)
        c.drawArc(rect, 200f, 140f, false, p)
        sparkle(c, cx + R * 0.95f, cy - R * 0.7f, R * 0.14f, 220)
        sparkle(c, cx - R * 1.0f, cy + R * 0.4f, R * 0.10f, 200)
    }

    private fun ocean(c: Canvas) {
        sphere(c, g1, g2)
        clipped(c) {
            wave(c, a(0xFF1E78E0.toInt(), 190), 0.0f, 0.10f, 2f, phase)
            wave(c, a(0xFF0B4AA8.toInt(), 210), 0.30f, 0.10f, 2f, -phase)
            wave(c, a(WHITE, 60), -0.15f, 0.08f, 2.5f, phase)
        }
        shine(c)
        fill(a(0xFF9ADFFF.toInt(), 200))
        c.drawCircle(cx + R * 0.95f, cy - R * 0.75f, R * 0.07f, p)
        c.drawCircle(cx - R * 0.9f, cy - R * 0.9f, R * 0.05f, p)
    }

    private fun circuit(c: Canvas) {
        flat(c, 0xFF10215E.toInt(), 0xFF060B2A.toInt())
        clipped(c) {
            stroke(a(g1, 130), R * 0.015f)
            c.drawCircle(cx, cy, R * 0.35f, p)
            c.drawCircle(cx, cy, R * 0.65f, p)
            for (i in 0 until 8) {
                val ang = Math.toRadians(i * 45.0 + 22.5).toFloat()
                c.drawLine(cx + cos(ang) * R * 0.35f, cy + sin(ang) * R * 0.35f, cx + cos(ang) * R, cy + sin(ang) * R, p)
            }
            val lit = (phase * 8f).toInt() % 8
            for (i in 0 until 8) {
                val ang = Math.toRadians(i * 45.0 + 22.5).toFloat()
                fill(a(WHITE, if (i == lit) 255 else 120))
                c.drawCircle(cx + cos(ang) * R * 0.65f, cy + sin(ang) * R * 0.65f, R * 0.045f, p)
            }
        }
        fill(a(g1, 230))
        c.drawCircle(cx, cy, R * 0.12f * (0.8f + 0.4f * pulse), p)
        stroke(a(g1, 200), R * 0.025f)
        p.pathEffect = DashPathEffect(floatArrayOf(R * 0.10f, R * 0.07f), phase * R * 0.17f)
        c.drawCircle(cx, cy, R * 1.06f, p)
        p.pathEffect = null
    }

    // ---------- Characters ----------
    private fun robot(c: Canvas) {
        for (s in floatArrayOf(-1f, 1f)) {
            fill(mix(g2, WHITE, 0.2f)); c.drawCircle(cx + s * R * 1.0f, cy, R * 0.18f, p)
            fill(CYAN); c.drawCircle(cx + s * R * 1.0f, cy, R * 0.08f, p)
        }
        stroke(g2, R * 0.05f)
        c.drawLine(cx, cy - R * 0.95f, cx, cy - R * 1.2f, p)
        fill(CYAN); c.drawCircle(cx, cy - R * 1.25f, R * 0.08f, p)
        sphere(c, g1, g2)
        shine(c, 60)
        fill(0xFF0F1B3D.toInt())
        rect.set(cx - R * 0.74f, cy - R * 0.36f, cx + R * 0.74f, cy + R * 0.46f)
        c.drawRoundRect(rect, R * 0.32f, R * 0.32f, p)
        face(c, cy + R * 0.04f, CYAN)
    }

    private fun cat(c: Canvas) {
        for (s in floatArrayOf(-1f, 1f)) {
            tri(c, g2, cx + s * R * 0.88f, cy - R * 0.10f, cx + s * R * 0.78f, cy - R * 1.18f, cx + s * R * 0.12f, cy - R * 0.85f)
            tri(c, 0xFFFFB5DA.toInt(), cx + s * R * 0.72f, cy - R * 0.40f, cx + s * R * 0.68f, cy - R * 0.95f, cx + s * R * 0.30f, cy - R * 0.78f)
        }
        sphere(c, g1, g2)
        shine(c)
        stroke(a(WHITE, 170), R * 0.03f)
        for (s in floatArrayOf(-1f, 1f)) {
            c.drawLine(cx + s * R * 0.55f, cy + R * 0.22f, cx + s * R * 1.0f, cy + R * 0.12f, p)
            c.drawLine(cx + s * R * 0.55f, cy + R * 0.30f, cx + s * R * 1.0f, cy + R * 0.36f, p)
        }
        face(c, cy + R * 0.04f, WHITE)
    }

    private fun bunny(c: Canvas) {
        for (s in floatArrayOf(-1f, 1f)) {
            c.save()
            c.rotate(s * 10f, cx + s * R * 0.35f, cy - R * 0.6f)
            fill(g1)
            rect.set(cx + s * R * 0.35f - R * 0.22f, cy - R * 1.6f, cx + s * R * 0.35f + R * 0.22f, cy - R * 0.55f)
            c.drawOval(rect, p)
            fill(0xFFFFA8CF.toInt())
            rect.set(cx + s * R * 0.35f - R * 0.11f, cy - R * 1.45f, cx + s * R * 0.35f + R * 0.11f, cy - R * 0.70f)
            c.drawOval(rect, p)
            c.restore()
        }
        sphere(c, g1, g2)
        shine(c)
        cheeks(c, 0xFFFF8AC8.toInt(), 160)
        face(c, cy + R * 0.04f, INK)
    }

    private fun alien(c: Canvas) {
        stroke(g2, R * 0.05f)
        for (s in floatArrayOf(-1f, 1f)) {
            c.drawLine(cx + s * R * 0.4f, cy - R * 0.85f, cx + s * R * 0.75f, cy - R * 1.30f, p)
            fill(mix(g1, WHITE, 0.4f)); c.drawCircle(cx + s * R * 0.75f, cy - R * 1.32f, R * 0.11f, p)
            fill(g2); c.drawCircle(cx + s * R * 1.0f, cy + R * 0.05f, R * 0.17f, p)
        }
        sphere(c, g1, g2)
        shine(c)
        if (status != Orb.OFF) {
            for (s in floatArrayOf(-1f, 1f)) {
                fill(0xFF10302B.toInt())
                rect.set(cx + s * R * 0.36f - R * 0.17f, cy - R * 0.28f, cx + s * R * 0.36f + R * 0.17f, cy + R * 0.12f)
                c.drawOval(rect, p)
                fill(a(WHITE, 230)); c.drawCircle(cx + s * R * 0.36f - R * 0.05f, cy - R * 0.17f, R * 0.05f, p)
            }
        }
        face(c, cy + R * 0.04f, 0xFF10302B.toInt(), eyes = status == Orb.OFF)
    }

    private fun fox(c: Canvas) {
        for (s in floatArrayOf(-1f, 1f)) {
            tri(c, g2, cx + s * R * 0.90f, cy - R * 0.05f, cx + s * R * 0.85f, cy - R * 1.20f, cx + s * R * 0.15f, cy - R * 0.85f)
            tri(c, 0xFF5A2A12.toInt(), cx + s * R * 0.84f, cy - R * 0.80f, cx + s * R * 0.85f, cy - R * 1.20f, cx + s * R * 0.45f, cy - R * 1.0f)
        }
        sphere(c, g1, g2)
        shine(c)
        fill(a(WHITE, 235))
        c.drawCircle(cx - R * 0.50f, cy + R * 0.30f, R * 0.36f, p)
        c.drawCircle(cx + R * 0.50f, cy + R * 0.30f, R * 0.36f, p)
        face(c, cy + R * 0.04f, 0xFF4A2410.toInt())
    }

    private fun panda(c: Canvas) {
        fill(0xFF1D1B26.toInt())
        c.drawCircle(cx - R * 0.78f, cy - R * 0.72f, R * 0.30f, p)
        c.drawCircle(cx + R * 0.78f, cy - R * 0.72f, R * 0.30f, p)
        sphere(c, g1, g2)
        shine(c, 60)
        for (s in floatArrayOf(-1f, 1f)) {
            c.save()
            c.rotate(s * -20f, cx + s * R * 0.36f, cy - R * 0.08f)
            fill(0xFF1D1B26.toInt())
            rect.set(cx + s * R * 0.36f - R * 0.26f, cy - R * 0.38f, cx + s * R * 0.36f + R * 0.26f, cy + R * 0.22f)
            c.drawOval(rect, p)
            c.restore()
        }
        fill(0xFF1D1B26.toInt())
        rect.set(cx - R * 0.10f, cy + R * 0.06f, cx + R * 0.10f, cy + R * 0.18f)
        c.drawOval(rect, p)
        face(c, cy + R * 0.04f, WHITE, mouthInk = 0xFF1D1B26.toInt())
    }

    private fun knight(c: Canvas) {
        tri(c, 0xFF39B6FF.toInt(), cx - R * 0.16f, cy - R * 0.80f, cx, cy - R * 1.5f + sin(phase * 2f * PI.toFloat()) * R * 0.03f, cx + R * 0.16f, cy - R * 0.80f)
        sphere(c, g1, g2)
        shine(c, 60)
        fill(mix(g2, BLACK, 0.15f))
        rect.set(cx - R * 0.06f, cy - R * 0.95f, cx + R * 0.06f, cy + R * 0.95f)
        c.drawRect(rect, p)
        fill(0xFF0B1630.toInt())
        rect.set(cx - R * 0.72f, cy - R * 0.30f, cx + R * 0.72f, cy + R * 0.34f)
        c.drawRoundRect(rect, R * 0.18f, R * 0.18f, p)
        face(c, cy + R * 0.02f, CYAN, mouth = false)
    }

    private fun space(c: Canvas) {
        fill(0xFFB9C3E0.toInt())
        c.drawCircle(cx - R * 1.0f, cy, R * 0.20f, p)
        c.drawCircle(cx + R * 1.0f, cy, R * 0.20f, p)
        sphere(c, g1, g2)
        shine(c, 60)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx - R * 0.2f, cy - R * 0.2f, R * 0.9f, intArrayOf(0xFF2A2F78.toInt(), 0xFF0B0D2A.toInt()), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy + R * 0.02f, R * 0.72f, p)
        p.shader = null
        stroke(a(WHITE, 200), R * 0.04f)
        c.drawCircle(cx, cy + R * 0.02f, R * 0.72f, p)
        fill(a(WHITE, 190))
        c.drawCircle(cx + R * 0.45f, cy - R * 0.38f, R * 0.025f, p)
        c.drawCircle(cx - R * 0.5f, cy + R * 0.42f, R * 0.02f, p)
        sparkle(c, cx + R * 0.5f, cy + R * 0.38f, R * 0.08f, 220)
        face(c, cy + R * 0.02f, 0xFFBFE8FF.toInt())
    }

    private fun penguin(c: Canvas) {
        fill(g2)
        for (s in floatArrayOf(-1f, 1f)) {
            c.save()
            c.rotate(s * 15f, cx + s * R, cy)
            rect.set(cx + s * R * 1.0f - R * 0.14f, cy - R * 0.15f, cx + s * R * 1.0f + R * 0.14f, cy + R * 0.55f)
            c.drawOval(rect, p)
            c.restore()
        }
        sphere(c, g1, g2)
        fill(a(WHITE, 245))
        rect.set(cx - R * 0.72f, cy - R * 0.50f, cx + R * 0.72f, cy + R * 0.68f)
        c.drawOval(rect, p)
        shine(c, 40)
        tri(c, 0xFFFF9E2C.toInt(), cx - R * 0.13f, cy + R * 0.12f, cx + R * 0.13f, cy + R * 0.12f, cx, cy + R * 0.32f)
        face(c, cy + R * 0.04f, INK, mouth = false)
    }

    private fun angel(c: Canvas) {
        val flap = if (status == Orb.SPEAKING || status == Orb.LISTENING) 10f * sin(2.0 * PI * phase * 3).toFloat() else 0f
        for (s in floatArrayOf(-1f, 1f)) {
            c.save()
            c.rotate(s * (-25f + flap), cx + s * R * 1.0f, cy - R * 0.2f)
            fill(a(WHITE, 235))
            rect.set(cx + s * R * 1.0f - R * 0.32f, cy - R * 0.55f, cx + s * R * 1.0f + R * 0.32f, cy + R * 0.10f)
            c.drawOval(rect, p)
            c.restore()
        }
        sphere(c, g1, g2)
        shine(c, 80)
        cheeks(c, 0xFFFFA0C8.toInt(), 150)
        face(c, cy + R * 0.04f, INK)
        stroke(a(0xFFFFD84D.toInt(), 90), R * 0.16f)
        rect.set(cx - R * 0.45f, cy - R * 1.28f, cx + R * 0.45f, cy - R * 0.98f)
        c.drawOval(rect, p)
        stroke(0xFFFFD84D.toInt(), R * 0.08f)
        c.drawOval(rect, p)
    }

    private fun dragon(c: Canvas) {
        for (s in floatArrayOf(-1f, 1f)) {
            tri(c, 0xFF8E52E8.toInt(), cx + s * R * 0.9f, cy, cx + s * R * 1.45f, cy - R * 0.55f, cx + s * R * 1.0f, cy + R * 0.55f)
            tri(c, 0xFFFFD36B.toInt(), cx + s * R * 0.62f, cy - R * 0.72f, cx + s * R * 0.95f, cy - R * 1.22f, cx + s * R * 0.2f, cy - R * 0.9f)
        }
        sphere(c, g1, g2)
        shine(c)
        cheeks(c, 0xFFFF8AC8.toInt(), 170)
        face(c, cy + R * 0.04f, WHITE)
    }

    // ---------- Premium ----------
    private fun glass(c: Canvas) {
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, R, intArrayOf(a(g1, 15), a(g1, 70), a(g2, 190)), floatArrayOf(0.5f, 0.85f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R, p)
        p.shader = null
        stroke(a(WHITE, 150), R * 0.035f)
        c.drawCircle(cx, cy, R, p)
        stroke(a(WHITE, 90), R * 0.05f)
        rect.set(cx - R * 0.7f, cy - R * 0.7f, cx + R * 0.7f, cy + R * 0.7f)
        c.drawArc(rect, 40f, 100f, false, p)
        shine(c, 120)
    }

    private fun metallic(c: Canvas) {
        val metal = 0xFFB8BECB.toInt()
        ring(c, metal, true)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            cx - R, cy - R, cx + R, cy + R,
            intArrayOf(0xFFF7F8FB.toInt(), 0xFF9AA2B3.toInt(), 0xFFE9ECF2.toInt(), 0xFF5B6272.toInt(), 0xFFB9BFCC.toInt()),
            floatArrayOf(0f, 0.28f, 0.5f, 0.78f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, R, p)
        p.shader = null
        shine(c, 110)
        ring(c, metal, false)
    }

    private fun hologram(c: Canvas) {
        c.save()
        c.rotate(phase * 360f, cx, cy)
        p.style = Paint.Style.FILL
        p.shader = SweepGradient(
            cx, cy,
            intArrayOf(0xFFFF7AD9.toInt(), 0xFF7AF0FF.toInt(), 0xFF8CFFB0.toInt(), 0xFFFFE98A.toInt(), 0xFFFF7AD9.toInt()), null
        )
        c.drawCircle(cx, cy, R, p)
        p.shader = null
        c.restore()
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx - R * 0.3f, cy - R * 0.35f, R * 1.4f, intArrayOf(a(WHITE, 170), a(WHITE, 40), a(WHITE, 0)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R, p)
        p.shader = null
        stroke(a(WHITE, 150), R * 0.03f)
        c.drawCircle(cx, cy, R, p)
        shine(c, 80)
    }

    private fun diamond(c: Canvas) {
        facets(c, g1, g2, 8, 22.5f, false)
        sparkle(c, cx - R * 0.4f, cy - R * 0.5f, R * 0.2f * (0.7f + 0.6f * pulse), 240)
        sparkle(c, cx + R * 0.5f, cy + R * 0.3f, R * 0.12f, 200)
    }

    private fun flame(c: Canvas) {
        flat(c, 0xFF3A1070.toInt(), 0xFF12082E.toInt())
        clipped(c) {
            c.save()
            c.rotate(phase * 360f, cx, cy)
            stroke(g1, R * 0.28f)
            rect.set(cx - R * 0.55f, cy - R * 0.55f, cx + R * 0.55f, cy + R * 0.55f)
            c.drawArc(rect, 20f, 200f, false, p)
            stroke(a(g2, 230), R * 0.22f)
            rect.set(cx - R * 0.78f, cy - R * 0.78f, cx + R * 0.78f, cy + R * 0.78f)
            c.drawArc(rect, 220f, 150f, false, p)
            stroke(0xFFFFA24D.toInt(), R * 0.12f)
            rect.set(cx - R * 0.28f, cy - R * 0.28f, cx + R * 0.28f, cy + R * 0.28f)
            c.drawArc(rect, 100f, 160f, false, p)
            c.restore()
        }
        shine(c, 50)
    }

    private fun nebula(c: Canvas) {
        flat(c, 0xFF1A1050.toInt(), 0xFF05051A.toInt())
        clipped(c) {
            val blobs = arrayOf(
                floatArrayOf(-0.3f, -0.2f), floatArrayOf(0.35f, 0.25f), floatArrayOf(0f, -0.4f)
            )
            val cols = intArrayOf(0xFF8A4DFF.toInt(), 0xFFFF5FB8.toInt(), 0xFF3D8BFF.toInt())
            for (i in 0..2) {
                p.style = Paint.Style.FILL
                p.shader = RadialGradient(cx + blobs[i][0] * R, cy + blobs[i][1] * R, R * 0.8f, intArrayOf(a(cols[i], 200), a(cols[i], 0)), null, Shader.TileMode.CLAMP)
                c.drawCircle(cx, cy, R, p)
            }
            p.shader = null
            drawStars(c)
            p.style = Paint.Style.FILL
            p.shader = RadialGradient(cx, cy, R * 0.3f * (0.8f + 0.4f * pulse), intArrayOf(a(WHITE, 210), a(WHITE, 0)), null, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, R, p)
            p.shader = null
        }
        stroke(a(0xFF8A9CFF.toInt(), 160), R * 0.03f)
        c.drawCircle(cx, cy, R, p)
        shine(c, 40)
    }

    private fun crown(c: Canvas) {
        sphere(c, g1, g2)
        shine(c, 60)
        path.reset()
        path.moveTo(cx - R * 0.62f, cy - R * 0.42f)
        path.lineTo(cx - R * 0.66f, cy - R * 1.05f)
        path.lineTo(cx - R * 0.30f, cy - R * 0.78f)
        path.lineTo(cx, cy - R * 1.25f)
        path.lineTo(cx + R * 0.30f, cy - R * 0.78f)
        path.lineTo(cx + R * 0.66f, cy - R * 1.05f)
        path.lineTo(cx + R * 0.62f, cy - R * 0.42f)
        path.close()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(cx, cy - R * 1.25f, cx, cy - R * 0.42f, 0xFFFFE07A.toInt(), 0xFFE0A020.toInt(), Shader.TileMode.CLAMP)
        c.drawPath(path, p)
        p.shader = null
        stroke(0xFFB87510.toInt(), R * 0.03f)
        c.drawPath(path, p)
        fill(0xFFFF5A7A.toInt()); c.drawCircle(cx, cy - R * 1.28f, R * 0.07f, p)
        fill(WHITE); c.drawCircle(cx - R * 0.66f, cy - R * 1.08f, R * 0.06f, p)
        c.drawCircle(cx + R * 0.66f, cy - R * 1.08f, R * 0.06f, p)
        fill(0xFF5FE8FF.toInt()); c.drawCircle(cx, cy - R * 0.62f, R * 0.08f, p)
        sparkle(c, cx + R * 0.8f, cy - R * 0.2f, R * 0.12f * (0.7f + 0.6f * pulse), 230)
    }

    private fun heartOrb(c: Canvas) {
        sphere(c, g1, g2)
        shine(c, 80)
        val s = R * 0.55f * (1f + 0.08f * pulse)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(cx, cy - s, cx, cy + s, 0xFFFFFFFF.toInt(), 0xFFFF7FC0.toInt(), Shader.TileMode.CLAMP)
        heart(c, cx, cy + R * 0.05f, s)
        p.shader = null
        fill(a(WHITE, 230))
        heart(c, cx + R * 0.95f, cy - R * 0.8f, R * 0.12f * (0.8f + 0.4f * pulse))
        fill(a(WHITE, 200))
        heart(c, cx - R * 0.95f, cy - R * 0.55f, R * 0.09f)
    }

    private fun dualRing(c: Canvas) {
        ring(c, g1, true, -22f, 0.95f)
        ring(c, g2, true, 28f, 0.85f)
        sphere(c, g1, g2)
        shine(c)
        ring(c, g1, false, -22f, 0.95f)
        ring(c, g2, false, 28f, 0.85f)
    }

    private fun pulseOrb(c: Canvas) {
        sphere(c, g1, g2)
        clipped(c) {
            for (k in 0..2) {
                val t = (phase + k / 3f) % 1f
                stroke(a(WHITE, ((1f - t) * 170).toInt()), R * 0.05f)
                c.drawCircle(cx, cy, R * (0.3f + 0.7f * t), p)
            }
        }
        stroke(a(WHITE, 235), R * 0.13f)
        c.drawCircle(cx, cy, R * 0.42f, p)
        fill(mix(g2, BLACK, 0.4f))
        c.drawCircle(cx, cy, R * 0.24f * (0.9f + 0.2f * pulse), p)
        shine(c, 60)
    }
}
