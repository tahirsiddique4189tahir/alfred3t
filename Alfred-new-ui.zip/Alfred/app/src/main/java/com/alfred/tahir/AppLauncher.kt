package com.alfred.tahir

import android.content.Context
import android.content.Intent

object AppLauncher {
    data class App(val label: String, val pkg: String)

    fun list(ctx: Context): List<App> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { App(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    /** Returns a launch intent, or null when the app is not installed. */
    fun resolve(ctx: Context, name: String, pkg: String): Intent? {
        val pm = ctx.packageManager
        if (pkg.isNotBlank()) pm.getLaunchIntentForPackage(pkg)?.let { return it }
        val n = norm(name)
        if (n.isEmpty()) return null
        val apps = list(ctx)
        val hit = apps.firstOrNull { norm(it.label) == n }
            ?: apps.firstOrNull { norm(it.label).contains(n) }
            ?: apps.firstOrNull { val l = norm(it.label); l.length > 3 && n.contains(l) }
        return hit?.let { pm.getLaunchIntentForPackage(it.pkg) }
    }
}
