package com.alfred.tahir

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.LinearInterpolator
import androidx.core.graphics.ColorUtils
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

enum class Orb { OFF, IDLE, LISTENING, THINKING, SPEAKING }

object OrbPalette {
    val pairs: List<Pair<Int, Int>> = listOf(
        0xFF9DF6FF.toInt() to 0xFF00A8FF.toInt(), // 0 Arc cyan (Jarvis, default)
        0xFFC4A6FF.toInt() to 0xFF8B5CF6.toInt(), // 1 Violet
        0xFFA9BDFF.toInt() to 0xFF5B6CF0.toInt(), // 2 Periwinkle
        0xFF7CC4FF.toInt() to 0xFF2F7CF6.toInt(), // 3 Blue
        0xFFA8EAFF.toInt() to 0xFF3FB7E8.toInt(), // 4 Sky
        0xFFB5F2D0.toInt() to 0xFF3DBE8B.toInt(), // 5 Mint
        0xFFFFC9A3.toInt() to 0xFFFF7E57.toInt(), // 6 Orange
        0xFFFFB5DA.toInt() to 0xFFE85BB0.toInt(), // 7 Pink
        0xFF9FE6D8.toInt() to 0xFF2BA79A.toInt(), // 8 Teal
        0xFFFFE8A0.toInt() to 0xFFF5B431.toInt(), // 9 Yellow
        0xFFFFB0A8.toInt() to 0xFFEF4B4B.toInt()  // 10 Red
    )

    fun pair(i: Int): Pair<Int, Int> = pairs[i.coerceIn(0, pairs.size - 1)]

    /** hue < 0 -> palette colour, otherwise a custom colour made from the hue (0..360) */
    fun resolve(i: Int, hue: Float): Pair<Int, Int> {
        if (hue < 0f) return pair(i)
        val h = hue.coerceIn(0f, 360f)
        return Color.HSVToColor(floatArrayOf(h, 0.45f, 1.0f)) to Color.HSVToColor(floatArrayOf(h, 0.80f, 0.78f))
    }
}

/** Soft animated orb. Used both as the floating overlay and inside the app. */
class OrbView(context: Context) : View(context) {

    var status: Orb = Orb.IDLE
        set(v) { field = v; invalidate() }
    var paletteIndex: Int = 0
        set(v) { field = v; invalidate() }
    /** 0 = classic orb, 1.. = cute characters */
    var style: Int = 0
        set(v) { field = v; invalidate() }
    /** -1 = use palette, 0..360 = custom hue */
    var hue: Float = -1f
        set(v) { field = v; invalidate() }
    private val avatar = AvatarPainter()
    private val stylePainter = StylePainter()

    var onTap: (() -> Unit)? = null
    var onLongPress: (() -> Unit)? = null
    var onDrag: ((Float, Float) -> Unit)? = null
    var onDragEnd: (() -> Unit)? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val arcRect = RectF()
    private val hudPath = Path()
    private var phase = 0f

    /** true = old glass orb, false (default) = Jarvis style arc-reactor HUD */
    var classicLook: Boolean = false
    private var spin = 0f
    private var lastNs = 0L

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f
        val (c1, c2) = if (status == Orb.OFF) (0xFFC9CCD6.toInt() to 0xFF8E93A6.toInt()) else OrbPalette.resolve(paletteIndex, hue)

        if (style >= 100) {
            stylePainter.draw(canvas, style, width.toFloat(), height.toFloat(), status, phase, c1, c2)
            return
        }
        if (style != 0) {
            avatar.draw(canvas, style, width.toFloat(), height.toFloat(), status, phase, c1, c2)
            return
        }

        if (!classicLook) {
            drawHud(canvas, cx, cy, r, c1, c2)
            return
        }

        val mult = when (status) {
            Orb.OFF -> 1
            Orb.IDLE -> 1
            Orb.LISTENING -> 2
            Orb.THINKING -> 3
            Orb.SPEAKING -> 3
        }
        val amp = when (status) {
            Orb.OFF -> 0.015f
            Orb.IDLE -> 0.05f
            Orb.LISTENING -> 0.10f
            Orb.THINKING -> 0.04f
            Orb.SPEAKING -> 0.12f
        }
        val pulse = 0.5f + 0.5f * sin(2.0 * PI * mult * phase).toFloat()

        // soft outer glow
        val glowR = r * (0.80f + 0.20f * pulse)
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx, cy, glowR,
            intArrayOf(ColorUtils.setAlphaComponent(c2, 130), ColorUtils.setAlphaComponent(c2, 0)),
            floatArrayOf(0.45f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, glowR, paint)

        // ripple ring while listening / speaking
        if (status == Orb.LISTENING || status == Orb.SPEAKING) {
            paint.shader = null
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = r * 0.035f
            paint.color = ColorUtils.setAlphaComponent(c1, ((1f - phase) * 170).toInt())
            canvas.drawCircle(cx, cy, r * (0.50f + 0.45f * phase), paint)
        }

        val coreR = r * (0.46f + amp * pulse)
        if (status != Orb.OFF) drawRing(canvas, cx, cy, r, c1, back = true)

        // glassy core
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx - coreR * 0.35f, cy - coreR * 0.40f, coreR * 1.5f,
            intArrayOf(ColorUtils.blendARGB(c1, Color.WHITE, 0.55f), c1, c2),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, coreR, paint)

        // soft highlight on the glass
        paint.shader = null
        paint.style = Paint.Style.FILL
        paint.color = ColorUtils.setAlphaComponent(Color.WHITE, 70)
        arcRect.set(cx - coreR * 0.62f, cy - coreR * 0.80f, cx + coreR * 0.05f, cy - coreR * 0.38f)
        canvas.drawOval(arcRect, paint)

        if (status != Orb.OFF) drawRing(canvas, cx, cy, r, c1, back = false)
        drawFace(canvas, cx, cy + coreR * 0.04f, coreR, pulse)

        // spinner while thinking
        if (status == Orb.THINKING) {
            paint.shader = null
            paint.style = Paint.Style.STROKE
            paint.strokeCap = Paint.Cap.ROUND
            paint.strokeWidth = r * 0.06f
            paint.color = ColorUtils.setAlphaComponent(Color.WHITE, 220)
            val a = r * 0.64f
            arcRect.set(cx - a, cy - a, cx + a, cy + a)
            canvas.drawArc(arcRect, phase * 360f, 110f, false, paint)
        }
        paint.shader = null
    }

    /**
     * Jarvis / Friday style HUD: tick ring, rotating arc segments, arc-reactor core and a
     * circular voice waveform that grows while Alfred listens and speaks.
     */
    private fun drawHud(canvas: Canvas, cx: Float, cy: Float, r: Float, c1: Int, c2: Int) {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0f else ((now - lastNs) / 1_000_000_000f).coerceIn(0f, 0.1f)
        lastNs = now
        val degPerSec = when (status) {
            Orb.OFF -> 0f
            Orb.IDLE -> 18f
            Orb.LISTENING -> 45f
            Orb.THINKING -> 210f
            Orb.SPEAKING -> 80f
        }
        spin = (spin + dt * degPerSec) % 3600f
        val energy = when (status) {
            Orb.OFF -> 0f
            Orb.IDLE -> 0.12f
            Orb.LISTENING -> 0.50f
            Orb.THINKING -> 0.22f
            Orb.SPEAKING -> 0.95f
        }
        val pulse = 0.5f + 0.5f * sin(2.0 * PI * (if (status == Orb.SPEAKING) 3 else 1) * phase).toFloat()
        val bright = ColorUtils.blendARGB(c1, Color.WHITE, 0.45f)

        // outer glow
        val glowR = r * (0.86f + 0.12f * pulse * (0.4f + energy))
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx, cy, glowR,
            intArrayOf(ColorUtils.setAlphaComponent(c2, 120), ColorUtils.setAlphaComponent(c2, 0)),
            floatArrayOf(0.40f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, glowR, paint)
        paint.shader = null

        // outer tick ring
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = r * 0.014f
        paint.color = ColorUtils.setAlphaComponent(c1, 110)
        canvas.drawCircle(cx, cy, r * 0.97f, paint)
        for (i in 0 until 60) {
            val a = Math.toRadians((i * 6f + spin).toDouble())
            val long = i % 5 == 0
            val r1 = r * (if (long) 0.86f else 0.90f)
            val r2 = r * 0.95f
            paint.strokeWidth = r * (if (long) 0.026f else 0.014f)
            paint.color = ColorUtils.setAlphaComponent(bright, if (long) 230 else 120)
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            canvas.drawLine(cx + ca * r1, cy + sa * r1, cx + ca * r2, cy + sa * r2, paint)
        }

        // rotating arc segments (counter clockwise)
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = r * 0.04f
        paint.color = ColorUtils.setAlphaComponent(c1, 220)
        val a2 = r * 0.77f
        arcRect.set(cx - a2, cy - a2, cx + a2, cy + a2)
        for (k in 0 until 3) {
            canvas.drawArc(arcRect, -spin * 1.6f + k * 120f, 78f, false, paint)
        }

        // inner thin ring + two bright fast arcs
        paint.strokeWidth = r * 0.012f
        paint.color = ColorUtils.setAlphaComponent(c1, 90)
        canvas.drawCircle(cx, cy, r * 0.62f, paint)
        paint.strokeWidth = r * 0.034f
        paint.color = ColorUtils.setAlphaComponent(bright, 240)
        val a3 = r * 0.62f
        arcRect.set(cx - a3, cy - a3, cx + a3, cy + a3)
        canvas.drawArc(arcRect, spin * 2.4f, 52f, false, paint)
        canvas.drawArc(arcRect, spin * 2.4f + 180f, 52f, false, paint)

        // circular voice waveform
        val bars = 44
        paint.strokeWidth = r * 0.032f
        for (i in 0 until bars) {
            val a = Math.toRadians((i * 360.0 / bars) - 90.0)
            val wob = abs(sin(i * 0.55 + spin * 0.12) * cos(i * 0.23 - spin * 0.07)).toFloat()
            val len = r * (0.025f + 0.15f * energy * (0.30f + 0.70f * wob) * (0.75f + 0.25f * pulse))
            val rin = r * 0.43f
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            paint.color = ColorUtils.setAlphaComponent(c1, if (status == Orb.OFF) 90 else 215)
            canvas.drawLine(cx + ca * rin, cy + sa * rin, cx + ca * (rin + len), cy + sa * (rin + len), paint)
        }

        // arc-reactor core
        val coreR = r * (0.30f + 0.035f * energy * pulse)
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx, cy, coreR,
            intArrayOf(Color.WHITE, bright, ColorUtils.setAlphaComponent(c2, 230)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, coreR, paint)
        paint.shader = null

        // triangle emblem inside the core
        hudPath.reset()
        val tr = coreR * 0.58f
        for (i in 0 until 3) {
            val a = Math.toRadians((i * 120.0) - 90.0 - spin * 0.5)
            val px = cx + cos(a).toFloat() * tr
            val py = cy + sin(a).toFloat() * tr
            if (i == 0) hudPath.moveTo(px, py) else hudPath.lineTo(px, py)
        }
        hudPath.close()
        paint.style = Paint.Style.STROKE
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeWidth = r * 0.022f
        paint.color = ColorUtils.setAlphaComponent(c2, 230)
        canvas.drawPath(hudPath, paint)
        paint.strokeJoin = Paint.Join.MITER
        paint.shader = null
    }

    /** thin tilted planet ring; back half is drawn behind the core, front half in front of it */
    private fun drawRing(canvas: Canvas, cx: Float, cy: Float, r: Float, c1: Int, back: Boolean) {
        canvas.save()
        canvas.rotate(-18f, cx, cy)
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = r * 0.022f
        paint.color = ColorUtils.setAlphaComponent(ColorUtils.blendARGB(c1, Color.WHITE, 0.55f), if (back) 90 else 190)
        arcRect.set(cx - r * 0.93f, cy - r * 0.27f, cx + r * 0.93f, cy + r * 0.27f)
        canvas.drawArc(arcRect, if (back) 180f else 0f, 180f, false, paint)
        canvas.restore()
    }

    /** cute face: happy closed eyes + smile (round eyes while listening, open mouth while speaking) */
    private fun drawFace(canvas: Canvas, cx: Float, cy: Float, R: Float, pulse: Float) {
        val white = ColorUtils.setAlphaComponent(Color.WHITE, 245)
        val gap = R * 0.34f
        val ey = cy - R * 0.06f
        val er = R * 0.15f
        paint.shader = null
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = white
        when (status) {
            Orb.OFF -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = R * 0.075f
                canvas.drawLine(cx - gap - er, ey, cx - gap + er, ey, paint)
                canvas.drawLine(cx + gap - er, ey, cx + gap + er, ey, paint)
            }
            Orb.LISTENING -> {
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx - gap, ey, er * 0.80f, paint)
                canvas.drawCircle(cx + gap, ey, er * 0.80f, paint)
            }
            Orb.THINKING -> {
                paint.style = Paint.Style.FILL
                val look = (phase * 2f * PI.toFloat()).let { sin(it) } * R * 0.05f
                canvas.drawCircle(cx - gap + look, ey - R * 0.03f, er * 0.70f, paint)
                canvas.drawCircle(cx + gap + look, ey - R * 0.03f, er * 0.70f, paint)
            }
            else -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = R * 0.085f
                arcRect.set(cx - gap - er, ey - er, cx - gap + er, ey + er)
                canvas.drawArc(arcRect, 180f, 180f, false, paint)
                arcRect.set(cx + gap - er, ey - er, cx + gap + er, ey + er)
                canvas.drawArc(arcRect, 180f, 180f, false, paint)
            }
        }
        val my = cy + R * 0.20f
        if (status == Orb.SPEAKING) {
            paint.style = Paint.Style.FILL
            val open = R * (0.05f + 0.10f * pulse)
            arcRect.set(cx - R * 0.13f, my - R * 0.02f, cx + R * 0.13f, my + open + R * 0.04f)
            canvas.drawOval(arcRect, paint)
        } else if (status == Orb.LISTENING) {
            paint.style = Paint.Style.FILL
            canvas.drawCircle(cx, my + R * 0.03f, R * 0.06f, paint)
        } else {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = R * 0.085f
            val w = if (status == Orb.OFF) R * 0.10f else R * 0.20f
            arcRect.set(cx - w, my - w * 0.55f, cx + w, my + w * 0.95f)
            canvas.drawArc(arcRect, 25f, 130f, false, paint)
        }
        paint.style = Paint.Style.FILL
    }

    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var downTime = 0L
    private var dragging = false
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY
                lastX = downX; lastY = downY
                dragging = false
                downTime = e.eventTime
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && (abs(e.rawX - downX) > slop || abs(e.rawY - downY) > slop)) dragging = true
                if (dragging) {
                    onDrag?.invoke(e.rawX - lastX, e.rawY - lastY)
                    lastX = e.rawX; lastY = e.rawY
                }
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) onDragEnd?.invoke()
                else if (e.eventTime - downTime > 600) onLongPress?.invoke()
                else onTap?.invoke()
            }
        }
        return true
    }
}
