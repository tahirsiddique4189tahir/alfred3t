package com.alfred.tahir

import kotlinx.coroutines.flow.MutableStateFlow

data class ChatMsg(val fromUser: Boolean, val text: String, val time: Long = System.currentTimeMillis())

/** Shared live state between services and UI. */
object AlfredState {
    val orb = MutableStateFlow(Orb.OFF)
    val running = MutableStateFlow(false)
    /** -1 = idle, 0..100 = download progress */
    val modelProgress = MutableStateFlow(-1)
    val lastSaid = MutableStateFlow("")
    val error = MutableStateFlow("")
    /** Text shown in the little bubble next to the orb. */
    val bubble = MutableStateFlow("")

    /** owner voice guard: is a voice enrolled, and the last match distance (-1 = none yet) */
    val voiceEnrolled = MutableStateFlow(false)
    val voiceScore = MutableStateFlow(-1f)

    /** Live chat (voice + typed). Newest last. */
    val chat = MutableStateFlow<List<ChatMsg>>(emptyList())
    val chatBusy = MutableStateFlow(false)

    /** Telemetry: Battery & System */
    val batteryPct = MutableStateFlow(100)
    val batteryCharging = MutableStateFlow(false)
    val batteryTemp = MutableStateFlow(28f)

    /** Telemetry: Weather & Environment */
    val weatherTemp = MutableStateFlow("--°C")
    val weatherDesc = MutableStateFlow("Clear")
    val weatherIcon = MutableStateFlow("🌤️")
    val weatherCity = MutableStateFlow("Local")
    val weatherHumidity = MutableStateFlow("55%")
    val weatherWind = MutableStateFlow("10 km/h")

    /** Dynamic UI Theme State */
    val uiTheme = MutableStateFlow(0)

    fun addChat(fromUser: Boolean, text: String) {
        if (text.isBlank()) return
        chat.value = (chat.value + ChatMsg(fromUser, text.trim())).takeLast(80)
    }

    /** Counts spoken user turns. Used so risky actions need a NEW user turn to be confirmed. */
    @Volatile
    var turn = 0
}
