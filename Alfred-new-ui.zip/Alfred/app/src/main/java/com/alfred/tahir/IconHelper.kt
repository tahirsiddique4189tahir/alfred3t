package com.alfred.tahir

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

object IconHelper {

    /** Manifest er activity-alias gulor list. */
    private val allAliases = listOf(
        "MainActivityAliasDefault",
        "MainActivityAliasGalaxy",
        "MainActivityAliasCrystal",
        "MainActivityAliasLiquid",
        "MainActivityAliasNeon",
        "MainActivityAliasAurora",
        "MainActivityAliasFire",
        "MainActivityAliasIce",
        "MainActivityAliasLeaf",
        "MainActivityAliasOcean",
        "MainActivityAliasCircuit"
    )

    data class IconItem(val style: Int, val name: String, val alias: String)

    val availableIcons = listOf(
        IconItem(0, "Alfred Classic", "MainActivityAliasDefault"),
        IconItem(100, "Galaxy Orb", "MainActivityAliasGalaxy"),
        IconItem(101, "Crystal Orb", "MainActivityAliasCrystal"),
        IconItem(102, "Liquid Orb", "MainActivityAliasLiquid"),
        IconItem(103, "Neon Orb", "MainActivityAliasNeon"),
        IconItem(104, "Aurora Flow", "MainActivityAliasAurora"),
        IconItem(105, "Fire Orb", "MainActivityAliasFire"),
        IconItem(106, "Ice Orb", "MainActivityAliasIce"),
        IconItem(107, "Leaf Orb", "MainActivityAliasLeaf"),
        IconItem(108, "Ocean Orb", "MainActivityAliasOcean"),
        IconItem(109, "Circuit Orb", "MainActivityAliasCircuit")
    )

    /** orb style id -> icon alias */
    fun aliasForStyle(style: Int): String = when (style) {
        100 -> "MainActivityAliasGalaxy"
        101 -> "MainActivityAliasCrystal"
        102 -> "MainActivityAliasLiquid"
        103 -> "MainActivityAliasNeon"
        104 -> "MainActivityAliasAurora"
        105 -> "MainActivityAliasFire"
        106 -> "MainActivityAliasIce"
        107 -> "MainActivityAliasLeaf"
        108 -> "MainActivityAliasOcean"
        109 -> "MainActivityAliasCircuit"
        else -> "MainActivityAliasDefault"
    }

    fun changeAppIcon(context: Context, activeAliasName: String) {
        val pm = context.packageManager
        val pkg = context.packageName

        val targetAlias = if (activeAliasName in allAliases) activeAliasName else "MainActivityAliasDefault"
        val targetCn = ComponentName(pkg, "$pkg.$targetAlias")

        try {
            // STEP 1: Enable target alias FIRST so launcher always sees an active launcher component
            if (pm.getComponentEnabledSetting(targetCn) != PackageManager.COMPONENT_ENABLED_STATE_ENABLED) {
                pm.setComponentEnabledSetting(
                    targetCn,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    PackageManager.DONT_KILL_APP
                )
            }

            // STEP 2: Disable all other aliases safely
            allAliases.filter { it != targetAlias }.forEach { alias ->
                val cn = ComponentName(pkg, "$pkg.$alias")
                if (pm.getComponentEnabledSetting(cn) != PackageManager.COMPONENT_ENABLED_STATE_DISABLED) {
                    pm.setComponentEnabledSetting(
                        cn,
                        PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        PackageManager.DONT_KILL_APP
                    )
                }
            }
        } catch (_: Exception) {
            // Prevent crashes on restricted launchers
        }
    }

    /** বর্তমানে কোন আইকনটি অ্যাক্টিভ আছে তা চেক করার ফাংশন */
    fun getCurrentIconAlias(context: Context): String {
        val pm = context.packageManager
        val pkg = context.packageName

        for (alias in allAliases) {
            try {
                val cn = ComponentName(pkg, "$pkg.$alias")
                val state = pm.getComponentEnabledSetting(cn)
                if (state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED) {
                    return alias
                }
            } catch (_: Exception) {}
        }
        return "MainActivityAliasDefault"
    }
}
