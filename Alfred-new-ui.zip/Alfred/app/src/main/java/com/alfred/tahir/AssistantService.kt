package com.alfred.tahir

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.KeyguardManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.IBinder
import android.os.PowerManager
import android.telecom.TelecomManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import com.alfred.tahir.call.CallBridge
import com.alfred.tahir.call.CallSession
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.io.ByteArrayOutputStream
import java.util.Calendar
import kotlin.random.Random
import kotlin.math.max

/**
 * Foreground service (microphone). Listens offline with Vosk for the wake word,
 * then records the command, hands it to the Agent (Gemini) and speaks the answer.
 * Turning the service OFF stops the mic completely.
 */
class AssistantService : Service() {

    companion object {
        private const val ACTION_STOP = "com.alfred.tahir.STOP"
        private const val CHANNEL = "alfred_mic"
        private const val RATE = 16000
        private val WAKE_PHRASES = listOf("alfred", "hi alfred", "hey alfred", "wake up alfred", "[unk]")

        @Volatile
        var instance: AssistantService? = null

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, AssistantService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, AssistantService::class.java))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var speaker: Speaker
    private lateinit var agent: Agent
    private lateinit var callSession: CallSession
    private var loop: Job? = null

    @Volatile private var manual = false
    @Volatile private var busy = false
    @Volatile var micMutedForChat = false
    @Volatile private var enrollRequested = false
    @Volatile private var voskModel: Model? = null
    private var lastRejectAt = 0L
    private var work: Job? = null
    private var nextProactiveAt = 0L

    private fun scheduleNext(): Long {
        val base = Prefs.proactiveMins.coerceIn(15, 480) * 60_000L
        return System.currentTimeMillis() + (base * (0.7 + Random.nextDouble() * 0.6)).toLong()
    }

    /** Alfred only speaks first when it is polite: screen on and unlocked, no call, no music, no Do Not Disturb. */
    private fun proactiveAllowed(): Boolean {
        if (Prefs.apiKey.isBlank()) return false
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (h < Prefs.proactiveFrom || h >= Prefs.proactiveTo) return false
        if (!getSystemService(PowerManager::class.java).isInteractive) return false
        if (getSystemService(KeyguardManager::class.java).isKeyguardLocked) return false
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL) return false
        val am = getSystemService(AudioManager::class.java)
        if (am.isMusicActive || am.mode != AudioManager.MODE_NORMAL) return false
        try {
            if (getSystemService(TelecomManager::class.java).isInCall) return false
        } catch (_: SecurityException) {
        }
        return true
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        speaker = Speaker(this)
        agent = Agent(this, speaker)
        callSession = CallSession(this, speaker)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            ServiceCompat.startForeground(
                this, 1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } catch (e: Exception) {
            AlfredState.error.value = "Cannot start microphone service: ${e.message}"
            stopSelf()
            return START_NOT_STICKY
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ||
            !ModelManager.isReady(this)
        ) {
            AlfredState.error.value = "Microphone permission or wake-word model missing"
            stopSelf()
            return START_NOT_STICKY
        }
        if (loop == null) {
            AlfredState.running.value = true
            AlfredState.error.value = ""
            loop = scope.launch(Dispatchers.IO) { runLoop() }
        }
        return START_NOT_STICKY
    }

    /** Called when the user taps the orb: skip the wake word. */
    fun manualTrigger() {
        if (!busy) manual = true
    }

    fun isBusy(): Boolean = busy

    /** Typed chat message from the Chat screen. Alfred answers in text (tap the speaker icon to hear it). */
    fun sendText(text: String): Boolean {
        if (text.isBlank() || busy) return false
        busy = true
        AlfredState.chatBusy.value = true
        work = scope.launch {
            try {
                agent.handle(null, typed = text.trim(), speak = false)
            } catch (e: Exception) {
                AlfredState.addChat(false, "⚠ " + (e.message ?: "error"))
            } finally {
                busy = false
                AlfredState.chatBusy.value = false
                AlfredState.orb.value = Orb.IDLE
            }
        }
        return true
    }

    /** Starts the owner-voice training (3 short phrases). Runs as soon as Alfred is idle. */
    fun requestEnroll() {
        enrollRequested = true
    }

    /** Stops whatever Alfred is doing right now (thinking, acting or speaking). */
    fun interrupt() {
        work?.cancel()
        AlfredState.orb.value = Orb.IDLE
    }

    /** Speaks a text on its own (used for reading new notifications aloud). */
    fun announce(text: String) {
        if (busy) return
        busy = true
        work = scope.launch {
            try {
                speaker.say(text, "en-US")
            } finally {
                busy = false
                AlfredState.orb.value = Orb.IDLE
            }
        }
    }

    override fun onDestroy() {
        loop?.cancel()
        scope.cancel()
        speaker.shutdown()
        AlfredState.running.value = false
        AlfredState.orb.value = Orb.OFF
        instance = null
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Alfred", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AssistantService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Alfred")
            .setContentText("Say “Alfred”…")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
    }

    // ------------------------------------------------------------------ audio loop

    private suspend fun CoroutineScope.runLoop() {
        LibVosk.setLogLevel(LogLevel.WARNINGS)
        val model = try {
            Model(ModelManager.dir(this@AssistantService).absolutePath)
        } catch (e: Exception) {
            AlfredState.error.value = "Cannot load wake-word model: ${e.message}"
            stopSelf()
            return
        }
        voskModel = model
        val rec = Recognizer(model, RATE.toFloat(), JSONArray(WAKE_PHRASES).toString())
        val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val ar = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, RATE * 2)
        )
        if (ar.state != AudioRecord.STATE_INITIALIZED) {
            AlfredState.error.value = "Microphone is busy or unavailable"
            ar.release(); rec.close(); model.close()
            stopSelf()
            return
        }
        ar.startRecording()
        AlfredState.orb.value = Orb.IDLE

        val frame = ShortArray(1600) // 100 ms
        val ring = ArrayDeque<ShortArray>()
        try {
            while (isActive) {
                // an unknown call that Alfred should answer (experimental)
                val callNumber = CallBridge.takePending()
                if (callNumber != null) {
                    busy = true
                    val cj = launch { callSession.run(ar, callNumber) }
                    work = cj
                    cj.join()
                    work = null
                    busy = false
                    rec.reset()
                    ring.clear()
                    AlfredState.orb.value = Orb.IDLE
                    continue
                }
                if (enrollRequested) {
                    enrollRequested = false
                    busy = true
                    val ej = launch { enrollVoice(ar) }
                    work = ej
                    ej.join()
                    work = null
                    busy = false
                    rec.reset()
                    ring.clear()
                    AlfredState.orb.value = Orb.IDLE
                    continue
                }
                val n = ar.read(frame, 0, frame.size)
                if (n <= 0) { delay(20); continue }
                if (busy || micMutedForChat) { ring.clear(); continue } // Alfred is speaking or user is chatting via text
                if (Prefs.proactive) {
                    if (nextProactiveAt == 0L) nextProactiveAt = scheduleNext()
                } else nextProactiveAt = 0L
                val copy = frame.copyOf(n)
                ring.addLast(copy)
                if (ring.size > 12) ring.removeFirst() // keep ~1.2 s pre-roll

                var triggered = false
                var withPreRoll = true
                if (manual) {
                    manual = false
                    triggered = true
                    withPreRoll = false
                } else if (rec.acceptWaveForm(copy, n)) {
                    if (JSONObject(rec.result).optString("text").contains("alfred")) triggered = true
                } else if (JSONObject(rec.partialResult).optString("partial").contains("alfred")) {
                    triggered = true
                }

                if (triggered) {
                    val pre = if (withPreRoll) ring.toList() else emptyList()
                    ring.clear()
                    rec.reset()
                    val job = launch { session(ar, pre) }
                    work = job
                    job.join()
                    work = null
                    rec.reset()
                    ring.clear()
                    AlfredState.orb.value = Orb.IDLE
                } else if (nextProactiveAt != 0L && System.currentTimeMillis() >= nextProactiveAt) {
                    if (proactiveAllowed()) {
                        ring.clear()
                        rec.reset()
                        val job = launch { session(ar, emptyList(), proactive = true) }
                        work = job
                        job.join()
                        work = null
                        rec.reset()
                        ring.clear()
                        AlfredState.orb.value = Orb.IDLE
                        nextProactiveAt = scheduleNext()
                    } else {
                        nextProactiveAt = System.currentTimeMillis() + 5 * 60_000L // try again in 5 minutes
                    }
                }
            }
        } finally {
            try { ar.stop() } catch (_: Exception) {}
            ar.release()
            rec.close()
            voskModel = null
            SpeakerGuard.close()
            model.close()
        }
    }

    private suspend fun CoroutineScope.session(ar: AudioRecord, pre: List<ShortArray>, proactive: Boolean = false) {
        busy = true
        try {
            var preroll = pre
            var follow = 0
            var openingTurn = proactive
            var waitMs = 6000
            var verified = false
            while (isActive) {
                if (openingTurn) {
                    // Alfred speaks first (no wake word); then he listens for the user's answer
                    openingTurn = false
                    AlfredState.orb.value = Orb.THINKING
                    val again = try {
                        withContext(Dispatchers.Main) { agent.handle(null, Agent.randomTopic()) }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        false // stay silent if a check-in fails (offline, quota ...)
                    }
                    try { ar.stop(); ar.startRecording() } catch (_: Exception) {}
                    if (!again) break
                    preroll = emptyList()
                    waitMs = 10000
                    continue
                }
                AlfredState.orb.value = Orb.LISTENING
                val pcm = recordCommand(ar, preroll, waitMs) ?: break
                waitMs = 6000
                if (!verified) {
                    AlfredState.orb.value = Orb.THINKING
                    if (Prefs.voiceGuard && !isOwner(pcm)) {
                        rejectStranger(ar)
                        break
                    }
                    verified = true
                }
                AlfredState.orb.value = Orb.THINKING
                val again = try {
                    withContext(Dispatchers.Main) { agent.handle(AudioUtil.pcmToWav(pcm)) }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    AlfredState.error.value = e.message ?: "error"
                    withContext(Dispatchers.Main) {
                        speaker.say("Sorry, something went wrong. " + (e.message ?: "").take(120), "en-US", true)
                    }
                    false
                }
                // drop whatever the mic heard while Alfred was talking
                try { ar.stop(); ar.startRecording() } catch (_: Exception) {}
                if (again && follow < 3) {
                    follow++
                    preroll = emptyList()
                } else break
            }
        } finally {
            agent.reset()
            busy = false
        }
    }

    // ------------------------------------------------------------------ owner voice guard

    private fun isOwner(pcm: ByteArray): Boolean {
        val owner = Prefs.ownerVector() ?: return true // guard is only active once a voice is enrolled
        val m = voskModel ?: return true
        if (!ModelManager.spkReady(this)) return true
        val v = SpeakerGuard.embed(this, m, pcm) ?: return false
        val d = SpeakerGuard.distance(owner, v)
        AlfredState.voiceScore.value = d
        return d <= Prefs.voiceThreshold
    }

    private suspend fun sayLang(ar: AudioRecord, en: String, bn: String, hi: String) {
        val (text, tag) = when (Prefs.replyLang) {
            "bn" -> bn to "bn-IN"
            "hi" -> hi to "hi-IN"
            else -> en to "en-US"
        }
        withContext(Dispatchers.Main) { speaker.say(text, tag, true) }
        try { ar.stop(); ar.startRecording() } catch (_: Exception) {}
    }

    private suspend fun rejectStranger(ar: AudioRecord) {
        val now = System.currentTimeMillis()
        if (now - lastRejectAt < 15000) return
        lastRejectAt = now
        sayLang(
            ar,
            "Sorry, I only take orders from my owner.",
            "দুঃখিত, আমি শুধু আমার মালিকের কণ্ঠের কথা শুনি।",
            "माफ़ कीजिए, मैं केवल अपने मालिक की आवाज़ सुनता हूँ।"
        )
    }

    /** Learns the owner's voice from 3 spoken answers. */
    private suspend fun CoroutineScope.enrollVoice(ar: AudioRecord) {
        val m = voskModel ?: return
        if (!ModelManager.spkReady(this@AssistantService)) {
            AlfredState.error.value = "Download the voice model first (Settings > Owner voice)"
            return
        }
        sayLang(
            ar,
            "Let us learn your voice. After each question, talk naturally for a few seconds.",
            "চলুন আপনার কণ্ঠ শিখে নিই। প্রতিটি প্রশ্নের পর কয়েক সেকেন্ড স্বাভাবিকভাবে কথা বলুন।",
            "चलिए आपकी आवाज़ सीखते हैं। हर सवाल के बाद कुछ सेकंड सामान्य रूप से बोलिए।"
        )
        val prompts = listOf(
            Triple("Please tell me your name and where you live.", "আপনার নাম আর কোথায় থাকেন বলুন।", "अपना नाम और आप कहाँ रहते हैं बताइए।"),
            Triple("Now tell me what you did today.", "এবার বলুন আজ আপনি কী কী করেছেন।", "अब बताइए आज आपने क्या किया।"),
            Triple("Finally, say anything you like.", "শেষে, আপনার যা ইচ্ছা বলুন।", "आख़िर में, जो मन चाहे बोलिए।")
        )
        val vecs = ArrayList<FloatArray>()
        var tries = 0
        var i = 0
        while (isActive && i < prompts.size && tries < 7) {
            tries++
            val (en, bn, hi) = prompts[i]
            sayLang(ar, en, bn, hi)
            AlfredState.orb.value = Orb.LISTENING
            val pcm = recordCommand(ar, emptyList(), 8000)
            val v = if (pcm != null && pcm.size >= RATE * 2 * 2) SpeakerGuard.embed(this@AssistantService, m, pcm) else null
            if (v == null) {
                sayLang(ar, "I could not hear enough. Please try again.", "ঠিকমতো শুনতে পাইনি। আবার বলুন।", "ठीक से सुनाई नहीं दिया। फिर से बोलिए।")
                continue
            }
            vecs.add(v)
            i++
        }
        if (vecs.size == prompts.size) {
            Prefs.ownerVec = SpeakerGuard.average(vecs).joinToString(",")
            Prefs.voiceGuard = true
            AlfredState.voiceEnrolled.value = true
            sayLang(
                ar,
                "Done. From now on I will obey only your voice.",
                "হয়ে গেছে। এখন থেকে আমি শুধু আপনার কণ্ঠের কথা শুনব।",
                "हो गया। अब से मैं सिर्फ़ आपकी आवाज़ सुनूँगा।"
            )
        } else {
            sayLang(
                ar,
                "Sorry, voice training failed. Please try again in a quieter place.",
                "দুঃখিত, কণ্ঠ শেখা হয়নি। শান্ত জায়গায় আবার চেষ্টা করুন।",
                "माफ़ कीजिए, आवाज़ सीखना नहीं हो पाया। शांत जगह पर फिर कोशिश कीजिए।"
            )
        }
    }

    /** Records until the user stops talking. Returns null if nobody spoke. */
    private suspend fun CoroutineScope.recordCommand(ar: AudioRecord, pre: List<ShortArray>, startWaitMs: Int = 6000): ByteArray? {
        val out = ByteArrayOutputStream()
        var speech = false
        var silenceMs = 0
        var totalMs = 0
        var noise = 300.0
        for (b in pre) {
            out.write(AudioUtil.shortsToBytes(b, b.size))
            if (AudioUtil.rms(b, b.size) > 1200) speech = true
        }
        val maxMs = 45000 // long messages are fine: Alfred waits until you really finish
        var speechMs = 0
        val buf = ShortArray(1600)
        while (isActive) {
            val n = ar.read(buf, 0, buf.size)
            if (n <= 0) { delay(10); continue }
            out.write(AudioUtil.shortsToBytes(buf, n))
            totalMs += 100
            val r = AudioUtil.rms(buf, n)
            noise = if (r < noise) r else noise * 0.98 + r * 0.02
            val isSpeech = r > max(500.0, noise * 2.5)
            if (isSpeech) { speech = true; silenceMs = 0; speechMs += 100 } else if (speech) silenceMs += 100
            // short command: end quickly. Long message: allow thinking pauses.
            val patienceMs = if (speechMs < 2500) 800 else 1300
            if (speech && silenceMs >= patienceMs) break
            if (!speech && totalMs >= startWaitMs) return null
            if (totalMs >= maxMs) break
        }
        return if (speech) out.toByteArray() else null
    }
}
