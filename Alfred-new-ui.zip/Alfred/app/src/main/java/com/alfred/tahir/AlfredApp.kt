package com.alfred.tahir

import android.app.Application

class AlfredApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        L.load()
    }
}
