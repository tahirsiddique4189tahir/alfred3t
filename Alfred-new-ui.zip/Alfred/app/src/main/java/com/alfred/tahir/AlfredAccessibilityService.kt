package com.alfred.tahir

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.PowerManager
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.drawable.GradientDrawable
import android.graphics.PixelFormat
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.View
import android.widget.TextView
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume
import kotlin.math.max

/**
 * Hands and eyes of Alfred: reads the screen, taps, scrolls, types, opens apps,
 * and also hosts the floating orb overlay (no extra "draw over apps" permission needed).
 */
class AlfredAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AlfredAccessibilityService? = null
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wm: WindowManager? = null
    private var orbView: OrbView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var bubbleView: TextView? = null
    private var bubbleJob: Job? = null

    private val nodes = ArrayList<AccessibilityNodeInfo>()
    private val rects = ArrayList<Rect>()

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key != null && key.startsWith("orb_")) applyOrb()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        Prefs.sp.registerOnSharedPreferenceChangeListener(prefListener)
        scope.launch { AlfredState.orb.collect { orbView?.status = it } }
        scope.launch { AlfredState.bubble.collect { showBubble(it) } }
        applyOrb()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        instance = null
        try { Prefs.sp.unregisterOnSharedPreferenceChangeListener(prefListener) } catch (_: Exception) {}
        removeBubble()
        removeOrb()
        scope.cancel()
    }

    // ---------------------------------------------------------------- orb overlay

    private fun applyOrb() {
        if (!Prefs.orbEnabled) { removeOrb(); return }
        val dm = resources.displayMetrics
        val density = dm.density
        val size = (Prefs.orbSize * density).toInt()
        if (orbView == null) {
            val v = OrbView(this)
            v.onTap = { onOrbTap() }
            v.onLongPress = { openAlfredUi() }
            v.onDrag = { dx, dy ->
                if (bubbleView != null) removeBubble()
                lp?.let {
                    it.x += dx.toInt()
                    it.y += dy.toInt()
                    try { wm?.updateViewLayout(orbView, it) } catch (_: Exception) {}
                }
            }
            v.onDragEnd = { snapToEdge() }
            val p = WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            p.gravity = Gravity.TOP or Gravity.START
            p.x = if (Prefs.orbX >= 0) Prefs.orbX else dm.widthPixels - size - (8 * density).toInt()
            p.y = if (Prefs.orbY >= 0) Prefs.orbY else (dm.heightPixels * 0.62f).toInt()
            try {
                wm?.addView(v, p)
                orbView = v
                lp = p
            } catch (_: Exception) {
                return
            }
        } else {
            lp?.let {
                it.width = size
                it.height = size
                try { wm?.updateViewLayout(orbView, it) } catch (_: Exception) {}
            }
        }
        orbView?.paletteIndex = Prefs.orbColor
        orbView?.hue = Prefs.orbHue
        orbView?.style = Prefs.orbStyle
        orbView?.alpha = Prefs.orbOpacity
        orbView?.status = AlfredState.orb.value
    }

    private fun removeOrb() {
        try { orbView?.let { wm?.removeView(it) } } catch (_: Exception) {}
        orbView = null
        lp = null
    }

    private fun snapToEdge() {
        val p = lp ?: return
        val dm = resources.displayMetrics
        val mid = p.x + p.width / 2
        p.x = if (mid < dm.widthPixels / 2) 0 else dm.widthPixels - p.width
        p.y = p.y.coerceIn(0, dm.heightPixels - p.height)
        try { wm?.updateViewLayout(orbView, p) } catch (_: Exception) {}
        Prefs.orbX = p.x
        Prefs.orbY = p.y
    }

    private fun onOrbTap() {
        val svc = AssistantService.instance
        when {
            svc == null -> openAlfredUi()          // assistant is OFF
            svc.isBusy() -> svc.interrupt()        // tap while Alfred works/speaks = stop
            else -> svc.manualTrigger()            // tap = talk now
        }
    }

    // ---------------------------------------------------------------- speech bubble next to the orb

    private fun showBubble(text: String) {
        bubbleJob?.cancel()
        val o = lp
        if (text.isBlank() || o == null || orbView == null || !Prefs.bubbleEnabled) {
            removeBubble()
            return
        }
        val dm = resources.displayMetrics
        val d = dm.density
        val pad = (12 * d).toInt()
        val margin = (8 * d).toInt()
        val tv = bubbleView ?: TextView(this).also { v ->
            v.setTextColor(0xFFE4F7FF.toInt())
            v.textSize = 14f
            v.setPadding(pad, pad, pad, pad)
            v.maxWidth = (dm.widthPixels * 0.72f).toInt()
            v.background = GradientDrawable().apply {
                setColor(0xEB08192B.toInt())
                setStroke((1 * d).toInt().coerceAtLeast(1), 0xAA22D3EE.toInt())
                cornerRadius = 14 * d
            }
        }
        tv.text = text.take(220)
        tv.measure(
            View.MeasureSpec.makeMeasureSpec(dm.widthPixels, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(dm.heightPixels, View.MeasureSpec.AT_MOST)
        )
        val w = tv.measuredWidth
        val h = tv.measuredHeight
        val y = if (o.y - h - margin >= 0) o.y - h - margin else o.y + o.height + margin
        val rawX = if (o.x + o.width / 2 > dm.widthPixels / 2) o.x + o.width - w else o.x
        val x = rawX.coerceIn(margin, max(margin, dm.widthPixels - w - margin))
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = x
        p.y = y
        try {
            if (bubbleView == null) {
                wm?.addView(tv, p)
                bubbleView = tv
            } else {
                wm?.updateViewLayout(tv, p)
            }
        } catch (_: Exception) {
            return
        }
        bubbleJob = scope.launch {
            delay(7000)
            removeBubble()
        }
    }

    private fun removeBubble() {
        bubbleJob?.cancel()
        try { bubbleView?.let { wm?.removeView(it) } } catch (_: Exception) {}
        bubbleView = null
        if (AlfredState.bubble.value.isNotEmpty()) AlfredState.bubble.value = ""
    }

    private fun openAlfredUi() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------------------------------------------------------------- reading the screen

    fun dumpScreen(): String {
        val root = rootInActiveWindow ?: return "(screen not readable)"
        nodes.clear()
        rects.clear()
        val sb = StringBuilder()
        val dm = resources.displayMetrics
        sb.append("foreground_app=").append(root.packageName)
            .append(" screen=").append(dm.widthPixels).append('x').append(dm.heightPixels).append('\n')

        fun walk(n: AccessibilityNodeInfo) {
            if (nodes.size >= 140 || sb.length > 9000) return
            if (!n.isVisibleToUser) return
            val text = (n.text?.toString() ?: "").replace('\n', ' ').take(80)
            val desc = (n.contentDescription?.toString() ?: "").replace('\n', ' ').take(80)
            if (text.isNotBlank() || desc.isNotBlank() || n.isClickable || n.isEditable || n.isScrollable) {
                val r = Rect()
                n.getBoundsInScreen(r)
                if (r.width() > 0 && r.height() > 0) {
                    val idx = nodes.size
                    nodes.add(n)
                    rects.add(r)
                    val cls = n.className?.toString()?.substringAfterLast('.') ?: ""
                    sb.append('[').append(idx).append("] ").append(cls)
                    if (text.isNotBlank()) sb.append(" \"").append(text).append('"')
                    if (desc.isNotBlank() && desc != text) sb.append(" desc=\"").append(desc).append('"')
                    if (n.isClickable) sb.append(" click")
                    if (n.isEditable) sb.append(" edit")
                    if (n.isScrollable) sb.append(" scroll")
                    if (n.isFocused) sb.append(" focused")
                    if (n.isChecked) sb.append(" checked")
                    sb.append(" @").append(r.left).append(',').append(r.top).append(',')
                        .append(r.right).append(',').append(r.bottom).append('\n')
                }
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        return sb.toString()
    }

    // ---------------------------------------------------------------- gestures

    private suspend fun gesture(path: Path, duration: Long): Boolean = suspendCancellableCoroutine { c ->
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration.coerceAtLeast(1)))
            .build()
        val ok = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { if (c.isActive) c.resume(true) }
            override fun onCancelled(gestureDescription: GestureDescription?) { if (c.isActive) c.resume(false) }
        }, null)
        if (!ok && c.isActive) c.resume(false)
    }

    suspend fun tapXY(x: Int, y: Int, ms: Long): String {
        val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        return if (gesture(p, ms)) "OK ($x,$y)" else "ERROR: gesture failed"
    }

    suspend fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, ms: Long): String {
        val p = Path().apply {
            moveTo(x1.toFloat(), y1.toFloat())
            lineTo(x2.toFloat(), y2.toFloat())
        }
        return if (gesture(p, ms.coerceIn(80, 3000))) "OK swiped" else "ERROR: swipe failed"
    }

    suspend fun scroll(direction: String): String {
        val dm = resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        return when (direction.lowercase()) {
            "down" -> swipe(w / 2, (h * 0.75).toInt(), w / 2, (h * 0.30).toInt(), 350)
            "up" -> swipe(w / 2, (h * 0.30).toInt(), w / 2, (h * 0.75).toInt(), 350)
            "right" -> swipe((w * 0.80).toInt(), h / 2, (w * 0.20).toInt(), h / 2, 350)
            "left" -> swipe((w * 0.20).toInt(), h / 2, (w * 0.80).toInt(), h / 2, 350)
            else -> "ERROR: bad direction"
        }
    }

    // ---------------------------------------------------------------- taps on elements

    private fun clickableAncestor(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var c: AccessibilityNodeInfo? = n
        var d = 0
        while (c != null && d < 6) {
            if (c.isClickable) return c
            c = c.parent
            d++
        }
        return null
    }

    suspend fun tapIndex(i: Int): String {
        val n = nodes.getOrNull(i)
        val r = rects.getOrNull(i)
        if (n == null || r == null) return "ERROR: no element [$i]"
        if (!n.isEditable && n.refresh()) {
            val c = clickableAncestor(n)
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "OK tapped [$i]"
        }
        return tapXY(r.centerX(), r.centerY(), 60)
    }

    suspend fun longPressIndex(i: Int): String {
        val r = rects.getOrNull(i) ?: return "ERROR: no element [$i]"
        return tapXY(r.centerX(), r.centerY(), 900)
    }

    suspend fun tapText(text: String): String {
        val root = rootInActiveWindow ?: return "ERROR: no window"
        val n = root.findAccessibilityNodeInfosByText(text).firstOrNull { it.isVisibleToUser }
            ?: return "ERROR: no visible element with text '$text'"
        val c = clickableAncestor(n)
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "OK tapped '$text'"
        val r = Rect()
        n.getBoundsInScreen(r)
        return tapXY(r.centerX(), r.centerY(), 60)
    }

    // ---------------------------------------------------------------- screenshot (for "look")

    /** JPEG of the current screen (max 1024px), or null. Needs Android 11+. */
    suspend fun screenshotJpeg(): ByteArray? {
        if (Build.VERSION.SDK_INT < 30) return null
        return suspendCancellableCoroutine { c ->
            takeScreenshot(
                Display.DEFAULT_DISPLAY, mainExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                        var out: ByteArray? = null
                        try {
                            val hb = result.hardwareBuffer
                            val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                            val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                            hb.close()
                            if (soft != null) {
                                val k = 1024f / max(soft.width, soft.height)
                                val scaled = if (k < 1f) {
                                    Bitmap.createScaledBitmap(soft, (soft.width * k).toInt(), (soft.height * k).toInt(), true)
                                } else soft
                                val bos = ByteArrayOutputStream()
                                scaled.compress(Bitmap.CompressFormat.JPEG, 70, bos)
                                out = bos.toByteArray()
                            }
                        } catch (_: Exception) {
                        }
                        if (c.isActive) c.resume(out)
                    }

                    override fun onFailure(errorCode: Int) {
                        if (c.isActive) c.resume(null)
                    }
                }
            )
        }
    }

    // ---------------------------------------------------------------- typing

    private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (!n.isVisibleToUser) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            findEditable(c)?.let { return it }
        }
        return null
    }

    private fun inputNode(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        return root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root)
    }

    fun typeText(text: String, append: Boolean): String {
        val node = inputNode() ?: return "ERROR: no text field on screen. Tap a field first."
        val current = if (append && !node.isShowingHintText) node.text?.toString() ?: "" else ""
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, current + text)
        }
        return if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "OK typed" else "ERROR: could not type"
    }

    fun enter(): String {
        val node = inputNode() ?: return "ERROR: no text field focused"
        if (Build.VERSION.SDK_INT >= 30) {
            return if (node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) "OK enter"
            else "ERROR: enter failed - tap the search/send button instead"
        }
        return "ERROR: enter not supported on this Android version - tap the search/send button instead"
    }

    // ---------------------------------------------------------------- system actions

    fun global(name: String): String {
        val act = when (name) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            "lock" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else -1
            "screenshot" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_TAKE_SCREENSHOT else -1
            else -> -1
        }
        if (act < 0) return "ERROR: unsupported"
        return if (performGlobalAction(act)) "OK" else "ERROR: $name failed"
    }

    fun openApp(name: String, pkg: String): String {
        val intent = AppLauncher.resolve(this, name, pkg)
            ?: return "APP_NOT_FOUND: '$name' is not installed on this phone"
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try {
            startActivity(intent)
            "OK opened $name"
        } catch (e: Exception) {
            "ERROR: cannot open $name (${e.message})"
        }
    }

    fun openUrl(url: String): String {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return "ERROR: only http/https links"
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "OK opened link"
        } catch (e: Exception) {
            "ERROR: ${e.message}"
        }
    }

    fun openSettings(page: String): String {
        val action = when (page) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "OK opened settings"
        } catch (e: Exception) {
            "ERROR: ${e.message}"
        }
    }

    fun copy(text: String): String {
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("alfred", text))
        return "OK copied to clipboard"
    }

    /** Auto-clicks WhatsApp Send button after opening chat */
    fun autoClickWhatsAppSend() {
        scope.launch {
            delay(850)
            for (attempt in 0..6) {
                val root = rootInActiveWindow
                if (root != null && root.packageName?.contains("whatsapp", ignoreCase = true) == true) {
                    val sendById = root.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send").firstOrNull { it.isVisibleToUser }
                    if (sendById != null) {
                        sendById.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        return@launch
                    }
                    val sendByDesc = root.findAccessibilityNodeInfosByText("Send").firstOrNull { it.isVisibleToUser }
                        ?: root.findAccessibilityNodeInfosByText("পাঠান").firstOrNull { it.isVisibleToUser }
                    if (sendByDesc != null) {
                        val c = clickableAncestor(sendByDesc) ?: sendByDesc
                        c.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        return@launch
                    }
                }
                delay(350)
            }
        }
    }

    /** Fast chained search and send inside WhatsApp if contact number wasn't found in phonebook */
    fun fastWhatsAppSearchAndSend(contactName: String, message: String) {
        scope.launch {
            openApp("WhatsApp", "com.whatsapp")
            delay(750)
            var root = rootInActiveWindow ?: return@launch
            val searchBtn = root.findAccessibilityNodeInfosByViewId("com.whatsapp:id/menuitem_search").firstOrNull()
                ?: root.findAccessibilityNodeInfosByText("Search").firstOrNull()
            if (searchBtn != null) {
                (clickableAncestor(searchBtn) ?: searchBtn).performAction(AccessibilityNodeInfo.ACTION_CLICK)
                delay(350)
            }
            typeText(contactName, false)
            delay(500)
            root = rootInActiveWindow ?: return@launch
            val contactNode = root.findAccessibilityNodeInfosByText(contactName).firstOrNull { it.isVisibleToUser }
            if (contactNode != null) {
                (clickableAncestor(contactNode) ?: contactNode).performAction(AccessibilityNodeInfo.ACTION_CLICK)
                delay(400)
                typeText(message, false)
                delay(250)
                autoClickWhatsAppSend()
            }
        }
    }

    /** Locks the device screen immediately via Accessibility Global Action */
    fun lockDevice(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            return performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        }
        return false
    }

    /** Wakes phone and executes user-configured unlock: Face/Swipe, PIN, Password, or 3x3 Pattern */
    fun unlockDevice() {
        scope.launch {
            try {
                // 1. Wake the display
                val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
                val wl = pm?.newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                    PowerManager.ACQUIRE_CAUSES_WAKEUP or
                    PowerManager.ON_AFTER_RELEASE,
                    "alfred:voice_unlock"
                )
                wl?.acquire(3000)

                delay(400)

                // 2. Swipe up to dismiss lockscreen / trigger face unlock or reveal PIN/Pattern/Password
                val dm = resources.displayMetrics
                val w = dm.widthPixels.toFloat()
                val h = dm.heightPixels.toFloat()

                val swipePath = Path().apply {
                    moveTo(w / 2f, h * 0.82f)
                    lineTo(w / 2f, h * 0.22f)
                }
                val stroke = GestureDescription.StrokeDescription(swipePath, 0, 240)
                dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)

                // 3. Handle configured lock type
                when (Prefs.lockType) {
                    0 -> {
                        // Face Unlock or Simple Swipe: swiping up is all that is needed to scan face or unlock
                    }
                    1 -> {
                        // PIN unlock
                        delay(650)
                        val pin = Prefs.lockPin
                        if (pin.isNotBlank()) {
                            for (ch in pin) {
                                val digit = ch.toString()
                                val root = rootInActiveWindow
                                val node = root?.findAccessibilityNodeInfosByText(digit)?.firstOrNull { it.isVisibleToUser }
                                if (node != null) {
                                    val target = clickableAncestor(node) ?: node
                                    target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                                } else {
                                    tapPinKeypad(digit, w, h)
                                }
                                delay(140)
                            }
                            delay(200)
                            val root = rootInActiveWindow
                            val enterNode = root?.findAccessibilityNodeInfosByText("Enter")?.firstOrNull()
                                ?: root?.findAccessibilityNodeInfosByText("OK")?.firstOrNull()
                                ?: root?.findAccessibilityNodeInfosByText("Done")?.firstOrNull()
                            enterNode?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        }
                    }
                    2 -> {
                        // Password unlock
                        delay(700)
                        val pwd = Prefs.lockPassword
                        if (pwd.isNotBlank()) {
                            val root = rootInActiveWindow
                            val input = findPasswordInput(root)
                            if (input != null) {
                                val args = Bundle().apply {
                                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, pwd)
                                }
                                input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                                delay(220)
                                val enterNode = root?.findAccessibilityNodeInfosByText("Enter")?.firstOrNull()
                                    ?: root?.findAccessibilityNodeInfosByText("Done")?.firstOrNull()
                                    ?: root?.findAccessibilityNodeInfosByText("OK")?.firstOrNull()
                                enterNode?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                            }
                        }
                    }
                    3 -> {
                        // 3x3 Dot Pattern unlock
                        delay(650)
                        val dotIndices = Prefs.lockPattern.split(",")
                            .mapNotNull { it.trim().toIntOrNull() }
                            .filter { it in 1..9 }
                        if (dotIndices.size >= 2) {
                            val gridSize = Math.min(w, h) * 0.72f
                            val startX = (w - gridSize) / 2f + (gridSize / 6f)
                            val stepX = gridSize / 3f
                            val startY = h * 0.52f
                            val stepY = stepX

                            fun dotCoordinate(num: Int): Pair<Float, Float> {
                                val idx = num - 1
                                val r = idx / 3
                                val c = idx % 3
                                return Pair(startX + c * stepX, startY + r * stepY)
                            }

                            val patternPath = Path()
                            val (x0, y0) = dotCoordinate(dotIndices[0])
                            patternPath.moveTo(x0, y0)
                            for (i in 1 until dotIndices.size) {
                                val (xi, yi) = dotCoordinate(dotIndices[i])
                                patternPath.lineTo(xi, yi)
                            }
                            val duration = (dotIndices.size * 100).toLong().coerceIn(350L, 850L)
                            val patternStroke = GestureDescription.StrokeDescription(patternPath, 0, duration)
                            dispatchGesture(GestureDescription.Builder().addStroke(patternStroke).build(), null, null)
                        }
                    }
                }
            } catch (_: Exception) {}
        }
    }

    private fun tapPinKeypad(digit: String, w: Float, h: Float) {
        val num = digit.toIntOrNull() ?: return
        val padW = w * 0.75f
        val startX = (w - padW) / 2f + (padW / 6f)
        val stepX = padW / 3f
        val startY = h * 0.54f
        val stepY = h * 0.09f
        val (col, row) = when (num) {
            1 -> 0 to 0
            2 -> 1 to 0
            3 -> 2 to 0
            4 -> 0 to 1
            5 -> 1 to 1
            6 -> 2 to 1
            7 -> 0 to 2
            8 -> 1 to 2
            9 -> 2 to 2
            0 -> 1 to 3
            else -> return
        }
        val tapX = startX + col * stepX
        val tapY = startY + row * stepY
        val path = Path().apply {
            moveTo(tapX, tapY)
            lineTo(tapX, tapY)
        }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 50)).build(), null, null)
    }

    private fun findPasswordInput(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isPassword || node.className?.contains("EditText") == true) return node
        for (i in 0 until node.childCount) {
            val res = findPasswordInput(node.getChild(i))
            if (res != null) return res
        }
        return null
    }
}
