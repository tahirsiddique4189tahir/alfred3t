package com.alfred.tahir

import org.json.JSONArray
import org.json.JSONObject

data class HistoryItem(val time: Long, val heard: String, val said: String, val actions: String)

/** Memory (facts + routines) and conversation history, stored on the phone only. */
object Store {
    // ---------------------------------------------------------------- memory
    fun memory(): List<String> {
        val a = try { JSONArray(Prefs.sp.getString("memory", "[]")) } catch (e: Exception) { JSONArray() }
        return (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() }
    }

    private fun saveMemory(list: List<String>) {
        Prefs.sp.edit().putString("memory", JSONArray(list.takeLast(60)).toString()).apply()
    }

    fun addMemory(fact: String) {
        val f = fact.trim().take(300)
        if (f.isEmpty()) return
        val l = memory().toMutableList()
        if (l.none { it.equals(f, true) }) l.add(f)
        saveMemory(l)
    }

    fun forgetMemory(query: String): Int {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return 0
        val l = memory().toMutableList()
        val before = l.size
        l.removeAll { it.lowercase().contains(q) }
        saveMemory(l)
        return before - l.size
    }

    fun removeMemoryAt(i: Int) {
        val l = memory().toMutableList()
        if (i in l.indices) { l.removeAt(i); saveMemory(l) }
    }

    fun clearMemory() = saveMemory(emptyList())

    // ---------------------------------------------------------------- history
    fun history(): List<HistoryItem> {
        val a = try { JSONArray(Prefs.sp.getString("history", "[]")) } catch (e: Exception) { JSONArray() }
        val out = ArrayList<HistoryItem>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            out.add(HistoryItem(o.optLong("t"), o.optString("h"), o.optString("s"), o.optString("a")))
        }
        return out
    }

    fun addHistory(heard: String, said: String, actions: String) {
        if (heard.isBlank() && said.isBlank()) return
        val l = JSONArray()
        l.put(JSONObject().put("t", System.currentTimeMillis()).put("h", heard.take(300)).put("s", said.take(400)).put("a", actions.take(200)))
        val old = try { JSONArray(Prefs.sp.getString("history", "[]")) } catch (e: Exception) { JSONArray() }
        for (i in 0 until minOf(old.length(), 79)) l.put(old.get(i))
        Prefs.sp.edit().putString("history", l.toString()).apply()
    }

    fun clearHistory() { Prefs.sp.edit().putString("history", "[]").apply() }
}
