package com.alfred.tahir.call

import android.content.Context
import android.media.AudioManager
import android.media.AudioRecord
import android.telecom.TelecomManager
import android.util.Base64
import com.alfred.tahir.AlfredState
import com.alfred.tahir.AudioUtil
import com.alfred.tahir.Gemini
import com.alfred.tahir.L
import com.alfred.tahir.Orb
import com.alfred.tahir.Prefs
import com.alfred.tahir.Speaker
import com.alfred.tahir.Store
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.math.max

/**
 * EXPERIMENTAL. Alfred talks to an unknown caller through the loudspeaker and listens with the
 * microphone (Android does not give apps the call audio directly). It works only if your phone's
 * microphone can hear the caller. Runs on the assistant's already-open microphone.
 */
class CallSession(private val ctx: Context, private val speaker: Speaker) {

    suspend fun run(ar: AudioRecord, number: String) {
        val am = ctx.getSystemService(AudioManager::class.java)
        CallOverlay.show(number, true)
        delay(900)
        val spk = speakerOn(am)
        CallOverlay.addLine("•", if (spk) "speaker on" else "speaker could not be switched on - press the speaker button yourself")

        val history = JSONArray()
        var summary = ""
        var silent = 0
        var turns = 0
        var hangUp = false
        try {
            val greeting = greeting()
            CallOverlay.addLine("Alfred", greeting)
            speaker.say(greeting, "en-US")

            while (currentCoroutineContext().isActive && turns < 12 && inCall()) {
                try { ar.stop(); ar.startRecording() } catch (_: Exception) {}
                AlfredState.orb.value = Orb.LISTENING
                val pcm = record(ar)
                if (pcm == null) {
                    silent++
                    if (silent == 2) CallOverlay.addLine("•", L.s("call_nomic"))
                    if (silent >= 4) { hangUp = true; break }
                    continue
                }
                silent = 0
                turns++
                AlfredState.orb.value = Orb.THINKING

                val parts = JSONArray()
                parts.put(
                    JSONObject().put(
                        "inlineData",
                        JSONObject().put("mimeType", "audio/wav")
                            .put("data", Base64.encodeToString(AudioUtil.pcmToWav(pcm), Base64.NO_WRAP))
                    )
                )
                parts.put(JSONObject().put("text", "Caller audio. Answer with the JSON object only."))
                history.put(JSONObject().put("role", "user").put("parts", parts))

                val raw = Gemini.generate(Prefs.effectiveModel(), prompt(), history)
                history.put(
                    JSONObject().put("role", "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", raw)))
                )
                while (history.length() > 16) { history.remove(0); history.remove(0) }

                val j = try {
                    JSONObject(raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim())
                } catch (e: Exception) {
                    JSONObject().put("reply", raw.take(200))
                }
                val orig = j.optString("caller_original")
                val tr = j.optString("caller_translated")
                val reply = j.optString("reply")
                if (j.optString("summary").isNotBlank()) summary = j.optString("summary")
                if (orig.isNotBlank()) {
                    CallOverlay.addLine("Caller", if (tr.isNotBlank() && tr != orig) "$orig\n   \u2192 $tr" else orig)
                }
                if (reply.isNotBlank()) {
                    CallOverlay.addLine("Alfred", reply)
                    speaker.say(reply, j.optString("lang", "en-US"))
                }
                if (j.optBoolean("end_call", false)) { hangUp = true; break }
            }
            if (turns >= 12) hangUp = true
            // really end the call (only on a normal finish; if the owner took over, the coroutine was cancelled)
            if (hangUp && inCall()) {
                delay(600)
                CallBridge.reject(ctx)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            CallOverlay.addLine("•", "error: " + (e.message ?: ""))
        } finally {
            Store.addHistory("Call: " + number.ifBlank { "?" }, summary, "call")
            if (summary.isNotBlank()) CallOverlay.addLine("•", summary)
            CallOverlay.addLine("•", L.s("call_done"))
            speakerOff(am)
            CallOverlay.hideAfter(10000)
        }
    }

    @Suppress("DEPRECATION")
    private fun speakerOff(am: AudioManager) {
        try { am.isSpeakerphoneOn = false } catch (_: Exception) {}
    }

    @Suppress("DEPRECATION")
    private fun speakerOn(am: AudioManager): Boolean {
        am.isSpeakerphoneOn = true
        return am.isSpeakerphoneOn
    }

    private fun greeting(): String {
        val owner = Prefs.ownerName.trim()
        val who = if (owner.isBlank()) "the person you called" else owner
        // the caller's language is not known yet, so the greeting is in English + Bangla + Hindi
        return "Hello, নমস্কার, नमस्ते. This is Alfred, an automated assistant of $who. " +
            "Who is calling, and what is it about? " +
            "আপনি কে, আর কী জন্য ফোন করেছেন? " +
            "आप कौन हैं, और किसलिए फोन किया है?"
    }

    private fun langName(): String = when (Prefs.callLang) {
        "en" -> "English"
        "hi" -> "Hindi (Devanagari script)"
        else -> "Bangla (Bengali script)"
    }

    private fun prompt(): String {
        val owner = Prefs.ownerName.trim().ifBlank { "the phone's owner" }
        return """
You are Alfred, the AI phone assistant of $owner. You are on a live phone call with an UNKNOWN caller. The owner is NOT on the line.
You hear the caller's audio. You already greeted them (in English, Bangla and Hindi) as an automated assistant and asked who is calling and why.
Goals: find out politely who is calling and why. Be brief: one or two short sentences per turn.
Rules: never give personal data, addresses, passwords, OTP/PIN or bank details. Never agree to payments or promises. The owner lives in India: be extra careful with common Indian scams (fake bank/KYC/credit-card calls, UPI or payment requests, 'digital arrest' or police/CBI/customs threats, courier or parcel scams, lottery or job offers, electricity/SIM disconnection threats) and end such calls politely. If it is a sales / spam / scam call, or the caller refuses to explain, politely end the call (end_call=true). If the matter is urgent, say you will pass the message on.
LANGUAGE: the caller may speak ANY language in the world (Hindi, Bangla, English, Urdu, Tamil, Telugu, Marathi, Gujarati, Punjabi, Kannada, Malayalam, Odia, Assamese, Nepali, ...). Callers in India often mix languages (Hinglish, Banglish): answer in the language they mostly use. Detect the language from their voice on EVERY turn and reply in exactly that language and its natural script. If they switch language, switch with them. Keep the caller's dialect and politeness level. If you cannot tell the language or the audio is unclear, ask politely in English, Bangla and Hindi together: which language do they prefer.
The "lang" field must be the accurate BCP-47 code of YOUR reply (examples: hi-IN, bn-IN, en-IN, ta-IN, te-IN, mr-IN, gu-IN, pa-IN, kn-IN, ml-IN, or-IN, ur-IN), because it selects the voice language.
Also write a transcript for the owner: caller_original = the caller's exact words in their original language and script; caller_translated = the same in ${langName()} (copy the original if it is already in that language).
If the audio is silent or unintelligible, politely ask them to repeat.
Output ONE JSON object only, no markdown:
{"caller_original":"","caller_translated":"","reply":"","lang":"BCP-47 code of the reply","end_call":false,"summary":"one sentence in ${langName()}: who called and what they want so far"}
""".trimIndent()
    }

    private fun inCall(): Boolean = try {
        ctx.getSystemService(TelecomManager::class.java).isInCall
    } catch (e: SecurityException) {
        true // without phone-state permission we cannot tell; the turn/silence limits still end the session
    }

    /** Records one utterance; null when nobody spoke for 8 seconds. */
    private suspend fun record(ar: AudioRecord): ByteArray? {
        val out = ByteArrayOutputStream()
        val buf = ShortArray(1600)
        var speech = false
        var silenceMs = 0
        var totalMs = 0
        var noise = 300.0
        while (currentCoroutineContext().isActive) {
            val n = ar.read(buf, 0, buf.size)
            if (n <= 0) { delay(10); continue }
            out.write(AudioUtil.shortsToBytes(buf, n))
            totalMs += 100
            val r = AudioUtil.rms(buf, n)
            noise = if (r < noise) r else noise * 0.98 + r * 0.02
            val isSpeech = r > max(450.0, noise * 2.5)
            if (isSpeech) { speech = true; silenceMs = 0 } else if (speech) silenceMs += 100
            if (speech && silenceMs >= 1300) break
            if (!speech && totalMs >= 8000) return null
            if (totalMs >= 20000) break
        }
        return if (speech) out.toByteArray() else null
    }
}
