@file:OptIn(ExperimentalMaterial3Api::class)

package com.alfred.tahir

import android.app.role.RoleManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ------------------------------------------------------------------ AI & Gemini

@Composable
fun AiSettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(Prefs.apiKey) }
    var showKey by remember { mutableStateOf(false) }
    var model by remember { mutableStateOf(Prefs.model) }

    DetailScaffold(L.s("row_ai"), onBack, L.s("row_ai_s")) {
        GlassCard(L.s("sec_gemini")) {
            OutlinedTextField(
                value = key,
                onValueChange = { key = it; Prefs.apiKey = it },
                label = { Text(L.s("api_key")) },
                singleLine = true,
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    TextButton(onClick = { showKey = !showKey }) {
                        Text(if (showKey) L.s("hide") else L.s("show"), color = UI.Blue)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
            TextButton(onClick = {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
            }) { Text(L.s("get_key"), color = UI.Blue) }
            Spacer(Modifier.height(8.dp))
            Label(L.s("model"))
            Spacer(Modifier.height(6.dp))
            ChipRow(Prefs.MODELS.map { it to it }, model) { model = it; Prefs.model = it }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = model,
                onValueChange = { model = it; Prefs.model = it },
                label = { Text(L.s("custom_model")) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Text(L.s("privacy"), color = UI.Sub, fontSize = 12.sp)
        }
    }
}

// ------------------------------------------------------------------ Voice & Language

@Composable
fun VoiceSettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var replyLang by remember { mutableStateOf(Prefs.replyLang) }
    var voiceMode by remember { mutableStateOf(Prefs.voiceMode) }
    var voiceName by remember { mutableStateOf(Prefs.voiceName) }
    var speed by remember { mutableStateOf(Prefs.voiceSpeed) }

    DetailScaffold(L.s("row_voice"), onBack, L.s("row_voice_s")) {
        GlassCard(L.s("sec_lang")) {
            Label(L.s("reply_lang"))
            Spacer(Modifier.height(6.dp))
            ChipRow(
                listOf("auto" to L.s("auto_match"), "bn" to "বাংলা", "en" to "English", "hi" to "हिन्दी"),
                replyLang
            ) { replyLang = it; Prefs.replyLang = it }
            Spacer(Modifier.height(14.dp))
            Label(L.s("ui_lang"))
            Spacer(Modifier.height(6.dp))
            ChipRow(
                listOf("auto" to L.s("auto"), "en" to "English", "bn" to "বাংলা", "hi" to "हिन्दी"),
                L.ui
            ) { L.set(it) }
        }

        GlassCard(L.s("sec_voice")) {
            ChipRow(
                listOf("gemini" to L.s("voice_gemini"), "phone" to L.s("voice_phone")),
                voiceMode
            ) { voiceMode = it; Prefs.voiceMode = it }
            if (voiceMode == "gemini") {
                Spacer(Modifier.height(10.dp))
                ChipRow(Prefs.VOICES.map { it to it }, voiceName) { voiceName = it; Prefs.voiceName = it }
            }
            Spacer(Modifier.height(12.dp))
            Label("Speaking speed")
            Spacer(Modifier.height(6.dp))
            ChipRow(
                listOf("1.0" to "Normal", "1.15" to "Fast", "1.3" to "Faster", "1.5" to "Turbo"),
                listOf(1.0f, 1.15f, 1.3f, 1.5f).minByOrNull { kotlin.math.abs(it - speed) }.toString()
            ) { speed = it.toFloat(); Prefs.voiceSpeed = speed }
        }

        GlassCard(L.s("voice_guard")) {
            val vScope = rememberCoroutineScope()
            val enrolled by AlfredState.voiceEnrolled.collectAsState()
            val score by AlfredState.voiceScore.collectAsState()
            val vRunning by AlfredState.running.collectAsState()
            val vProgress by AlfredState.modelProgress.collectAsState()
            LaunchedEffect(Unit) { AlfredState.voiceEnrolled.value = Prefs.ownerVec.isNotBlank() }
            var spkReady by remember { mutableStateOf(ModelManager.spkReady(ctx)) }
            LaunchedEffect(vProgress) { spkReady = ModelManager.spkReady(ctx) }
            var guardOn by remember { mutableStateOf(Prefs.voiceGuard) }
            var strict by remember { mutableStateOf(Prefs.voiceThreshold) }

            Text(
                if (enrolled) "✓ " + L.s("voice_enrolled") else L.s("voice_not_enrolled"),
                color = if (enrolled) UI.Good else UI.Sub
            )
            Spacer(Modifier.height(8.dp))
            if (!spkReady) {
                SoftButton(L.s("voice_model"), {
                    vScope.launch {
                        ModelManager.downloadSpk(ctx.applicationContext)
                        spkReady = ModelManager.spkReady(ctx)
                    }
                })
                if (vProgress in 0..99) {
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = vProgress / 100f, modifier = Modifier.fillMaxWidth())
                }
            } else {
                SoftButton(L.s("voice_train"), { AssistantService.instance?.requestEnroll() }, enabled = vRunning)
                if (!vRunning) Text(L.s("voice_need_on"), color = UI.Sub, fontSize = 12.sp)
                if (enrolled) {
                    TextButton(onClick = {
                        Prefs.ownerVec = ""
                        Prefs.voiceGuard = false
                        guardOn = false
                        AlfredState.voiceEnrolled.value = false
                    }) { Text(L.s("voice_clear"), color = UI.Bad) }
                }
            }
            Spacer(Modifier.height(6.dp))
            SwitchRow(L.s("voice_guard"), guardOn && enrolled, enabled = enrolled) { guardOn = it; Prefs.voiceGuard = it }
            Label(L.s("voice_strict"))
            Slider(
                value = strict,
                onValueChange = { strict = it; Prefs.voiceThreshold = it },
                valueRange = 0.30f..0.80f,
                colors = sliderColors()
            )
            if (score >= 0f) {
                Label(L.s("voice_score") + ": " + String.format("%.2f", score))
            }
        }
    }
}

// ------------------------------------------------------------------ Accessibility

@Composable
fun AccessibilitySettingsScreen(tick: Int, onBack: () -> Unit) {
    val ctx = LocalContext.current
    DetailScaffold(L.s("row_acc"), onBack, L.s("row_acc_s")) {
        GlassCard(L.s("sec_acc")) {
            val on = remember(tick) { isAccessibilityEnabled(ctx) }
            Text(
                if (on) "✓ " + L.s("acc_on") else L.s("acc_off"),
                color = if (on) UI.Good else UI.Bad, fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(10.dp))
            Text(L.s("gate_hint"), color = UI.Sub, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            SoftButton(L.s("open_acc"), { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        }
    }
}

// ------------------------------------------------------------------ Memory

@Composable
fun MemorySettingsScreen(onBack: () -> Unit) {
    var mem by remember { mutableStateOf(Store.memory()) }
    DetailScaffold(L.s("row_mem"), onBack, L.s("row_mem_s")) {
        GlassCard(L.s("sec_memory")) {
            Text(L.s("mem_hint"), color = UI.Sub, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            if (mem.isEmpty()) Text(L.s("mem_empty"), color = UI.Ink)
            mem.forEachIndexed { i, m ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(m, Modifier.weight(1f), color = UI.Ink, fontSize = 14.sp)
                    TextButton(onClick = { Store.removeMemoryAt(i); mem = Store.memory() }) { Text("✕", color = UI.Bad) }
                }
            }
            if (mem.isNotEmpty()) {
                TextButton(onClick = { Store.clearMemory(); mem = emptyList() }) { Text(L.s("clear_all"), color = UI.Bad) }
            }
        }
    }
}

// ------------------------------------------------------------------ Notifications

@Composable
fun NotificationSettingsScreen(tick: Int, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var readNotif by remember { mutableStateOf(Prefs.readNotifications) }
    DetailScaffold(L.s("row_notif"), onBack, L.s("row_notif_s")) {
        GlassCard(L.s("sec_notif")) {
            val nOn = remember(tick) { AlfredNotificationListener.isEnabled(ctx) }
            Text(
                if (nOn) "✓ " + L.s("acc_on") else L.s("acc_off"),
                color = if (nOn) UI.Good else UI.Bad, fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(6.dp))
            Text(L.s("notif_hint"), color = UI.Sub, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            SoftButton(L.s("notif_open"), { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
            Spacer(Modifier.height(10.dp))
            SwitchRow(L.s("notif_auto"), readNotif) { readNotif = it; Prefs.readNotifications = it }
        }
    }
}

// ------------------------------------------------------------------ General

@Composable
fun GeneralSettingsScreen(tick: Int, requestRole: () -> Unit, onHistory: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var orbOn by remember { mutableStateOf(Prefs.orbEnabled) }
    var bubbleOn by remember { mutableStateOf(Prefs.bubbleEnabled) }
    var callAssist by remember { mutableStateOf(Prefs.callAssist) }
    var callLang by remember { mutableStateOf(Prefs.callLang) }
    var ownerName by remember { mutableStateOf(Prefs.ownerName) }
    var proactiveOn by remember { mutableStateOf(Prefs.proactive) }
    var proactiveMins by remember { mutableStateOf(Prefs.proactiveMins) }
    var proactiveFrom by remember { mutableStateOf(Prefs.proactiveFrom) }
    var proactiveTo by remember { mutableStateOf(Prefs.proactiveTo) }
    var jarvisGreeting by remember { mutableStateOf(Prefs.jarvisGreeting) }
    var uiTheme by remember { mutableStateOf(Prefs.uiTheme) }

    DetailScaffold(L.s("row_gen"), onBack, L.s("row_gen_s")) {
        GlassCard(L.s("orb_toggle_hint")) {
            SwitchRow(L.s("orb_show"), orbOn) { orbOn = it; Prefs.orbEnabled = it }
            SwitchRow(L.s("bubble_show"), bubbleOn) { bubbleOn = it; Prefs.bubbleEnabled = it }
            SwitchRow("Jarvis Voice Greeting on Start", jarvisGreeting) { jarvisGreeting = it; Prefs.jarvisGreeting = it }
            Spacer(Modifier.height(8.dp))
            Label("UI Theme Color")
            Spacer(Modifier.height(6.dp))
            ChipRow(
                UiThemeManager.themes.map { it.id.toString() to it.name },
                uiTheme.toString()
            ) { uiTheme = it.toInt(); Prefs.uiTheme = uiTheme }
        }

        GlassCard(L.s("sec_proactive")) {
            SwitchRow(L.s("proactive_on"), proactiveOn) { proactiveOn = it; Prefs.proactive = it }
            if (proactiveOn) {
                Spacer(Modifier.height(8.dp))
                Label(L.s("proactive_every"))
                Spacer(Modifier.height(6.dp))
                ChipRow(
                    listOf("30" to "30 min", "60" to "1 h", "90" to "1.5 h", "180" to "3 h"),
                    proactiveMins.toString()
                ) { proactiveMins = it.toInt(); Prefs.proactiveMins = it.toInt() }
                Spacer(Modifier.height(8.dp))
                Label(L.s("proactive_from"))
                Spacer(Modifier.height(6.dp))
                ChipRow(
                    listOf("7", "8", "9", "10", "11").map { it to "$it:00" },
                    proactiveFrom.toString()
                ) { proactiveFrom = it.toInt(); Prefs.proactiveFrom = it.toInt() }
                Spacer(Modifier.height(8.dp))
                Label(L.s("proactive_to"))
                Spacer(Modifier.height(6.dp))
                ChipRow(
                    listOf("20", "21", "22", "23").map { it to "$it:00" },
                    proactiveTo.toString()
                ) { proactiveTo = it.toInt(); Prefs.proactiveTo = it.toInt() }
                Spacer(Modifier.height(8.dp))
                Text(L.s("proactive_hint"), color = UI.Sub, fontSize = 12.sp)
            }
        }

        GlassCard(L.s("sec_call")) {
            val roleHeld = remember(tick) {
                Build.VERSION.SDK_INT >= 29 &&
                    ctx.getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
            }
            Text(
                if (roleHeld) "✓ " + L.s("call_role_on") else L.s("acc_off"),
                color = if (roleHeld) UI.Good else UI.Bad, fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(8.dp))
            SoftButton(L.s("call_role"), requestRole)
            Spacer(Modifier.height(10.dp))
            SwitchRow(L.s("call_auto"), callAssist) { callAssist = it; Prefs.callAssist = it }
            Spacer(Modifier.height(10.dp))
            Label(L.s("call_lang"))
            Spacer(Modifier.height(6.dp))
            ChipRow(
                listOf("bn" to "বাংলা", "en" to "English", "hi" to "हिन्दी"),
                callLang
            ) { callLang = it; Prefs.callLang = it }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = ownerName,
                onValueChange = { ownerName = it; Prefs.ownerName = it },
                label = { Text(L.s("owner_name")) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Text(L.s("call_hint"), color = UI.Sub, fontSize = 12.sp)
        }

        GlassCard {
            SoftButton(L.s("open_history"), onHistory)
        }
    }
}

// ------------------------------------------------------------------ History

@Composable
fun HistoryScreen(onBack: () -> Unit) {
    var items by remember { mutableStateOf(Store.history()) }
    val fmt = remember { SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()) }
    DetailScaffold(L.s("history"), onBack) {
        if (items.isNotEmpty()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { Store.clearHistory(); items = emptyList() }) {
                    Text(L.s("clear_all"), color = UI.Bad)
                }
            }
        }
        if (items.isEmpty()) Text(L.s("hist_empty"), color = UI.Sub)
        items.forEach { h ->
            GlassCard {
                Text(fmt.format(Date(h.time)), color = UI.Sub, fontSize = 12.sp)
                if (h.heard.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text("\u201C" + h.heard + "\u201D", fontWeight = FontWeight.Medium, color = UI.Ink)
                }
                if (h.said.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(h.said, color = UI.Ink)
                }
                if (h.actions.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(h.actions, color = UI.Blue, fontSize = 12.sp)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Security & Voice Lock

@Composable
fun SecurityLockScreen(onBack: () -> Unit) {
    var lockType by remember { mutableStateOf(Prefs.lockType) }
    var pin by remember { mutableStateOf(Prefs.lockPin) }
    var password by remember { mutableStateOf(Prefs.lockPassword) }
    var pattern by remember { mutableStateOf(Prefs.lockPattern) }
    var testStatus by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    DetailScaffold("Voice Lock & Security", onBack, "ভয়েস কমান্ড দিয়ে ফোন লক ও আনলক সেটিংস") {
        GlassCard("লক মেথড নির্বাচন করুন (Select Lock Type)") {
            Text(
                "আপনার ফোনে বর্তমানে যে লকটি চালু আছে, এখানে সেটি বেছে নিন:",
                color = UI.Sub, fontSize = 13.sp
            )
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Face / Swipe", lockType == 0) {
                    lockType = 0
                    Prefs.lockType = 0
                }
                Chip("PIN (পিন)", lockType == 1) {
                    lockType = 1
                    Prefs.lockType = 1
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Password (পাসওয়ার্ড)", lockType == 2) {
                    lockType = 2
                    Prefs.lockType = 2
                }
                Chip("3x3 Pattern (প্যাটার্ন)", lockType == 3) {
                    lockType = 3
                    Prefs.lockType = 3
                }
            }
        }

        when (lockType) {
            0 -> {
                GlassCard("Face Unlock / Swipe Settings") {
                    Text(
                        "আপনার ফোনে ফেস আনলক (Face Unlock) অথবা সোয়াইপ আনলক থাকলে এটি সক্রিয় রাখুন।",
                        color = UI.Ink, fontSize = 14.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "ভয়েসে 'ফোন আনলক করো' বললে আলফ্রেড স্ক্রিন জ্বালিয়ে ওপরে সোয়াইপ করবে—যাতে ফোনের ফ্রন্ট ক্যামেরা আপনার মুখ স্ক্যান করে সঙ্গে সঙ্গে ফোন আনলক করে দেয়।",
                        color = UI.Sub, fontSize = 12.sp
                    )
                }
            }
            1 -> {
                GlassCard("PIN লক কনফিগারেশন") {
                    Text(
                        "আপনার ফোনের আনলক পিন কোডটি এখানে লিখুন:",
                        color = UI.Sub, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = pin,
                        onValueChange = {
                            pin = it
                            Prefs.lockPin = it
                        },
                        label = { Text("Phone PIN (e.g. 1234)") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "ভয়েসে আনলক কমান্ড দিলে আলফ্রেড স্ক্রিন জ্বালিয়ে ডায়াল প্যাডে নির্ভুলভাবে এই পিন টাইপ করে এন্টার দেবে।",
                        color = UI.Sub, fontSize = 12.sp
                    )
                }
            }
            2 -> {
                GlassCard("পাসওয়ার্ড লক কনফিগারেশন") {
                    Text(
                        "আপনার ফোনের টেক্সট পাসওয়ার্ডটি এখানে লিখুন:",
                        color = UI.Sub, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = password,
                        onValueChange = {
                            password = it
                            Prefs.lockPassword = it
                        },
                        label = { Text("Phone Password") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "ভয়েসে 'আনলক করো' বললে আলফ্রেড স্ক্রিন জ্বালিয়ে এই পাসওয়ার্ড ইনপুট বক্সে পেস্ট করে ফোন আনলক করবে।",
                        color = UI.Sub, fontSize = 12.sp
                    )
                }
            }
            3 -> {
                GlassCard("3x3 Dot Pattern কনফিগারেশন") {
                    val dotList = pattern.split(",").mapNotNull { it.trim().toIntOrNull() }.filter { it in 1..9 }
                    Text(
                        "নিচের ৩x৩ গ্রিডে ট্যাপ করে আপনার প্যাটার্নের ডটগুলো ক্রমানুসারে সিলেক্ট করুন:",
                        color = UI.Sub, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(10.dp))

                    Text(
                        text = if (dotList.isEmpty()) "কোনো ডট সিলেক্ট করা হয়নি (ট্যাপ করে সিলেক্ট করুন)" else "নির্বাচিত প্যাটার্ন: " + dotList.joinToString(" ➔ "),
                        color = UI.Blue, fontWeight = FontWeight.SemiBold, fontSize = 14.sp
                    )
                    Spacer(Modifier.height(12.dp))

                    // 3x3 interactive dot grid
                    Column(
                        Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        for (row in 0..2) {
                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                for (col in 0..2) {
                                    val dotNum = row * 3 + col + 1
                                    val isSelected = dotList.contains(dotNum)
                                    val order = dotList.indexOf(dotNum) + 1
                                    Box(
                                        modifier = Modifier
                                            .size(54.dp)
                                            .clip(CircleShape)
                                            .background(if (isSelected) UI.Blue else UI.Tile)
                                            .border(1.5.dp, if (isSelected) UI.Ink else UI.Blue.copy(alpha = 0.4f), CircleShape)
                                            .clickable {
                                                val newDots = if (dotList.contains(dotNum)) {
                                                    dotList.filter { it != dotNum }
                                                } else {
                                                    dotList + dotNum
                                                }
                                                pattern = newDots.joinToString(",")
                                                Prefs.lockPattern = pattern
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (isSelected) "$order" else "$dotNum",
                                            color = if (isSelected) UI.OnAccent else UI.Ink,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 18.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = {
                            pattern = ""
                            Prefs.lockPattern = ""
                        }) {
                            Text("Reset Pattern", color = UI.Bad)
                        }
                    }
                }
            }
        }

        GlassCard("লক ও আনলক টেস্ট করুন (Test Controls)") {
            if (testStatus.isNotBlank()) {
                Text(testStatus, color = UI.Good, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SoftButton("লক টেস্ট (Lock Now)", {
                    val ok = AlfredAccessibilityService.instance?.lockDevice() ?: false
                    testStatus = if (ok) "স্ক্রিন সফলভাবে লক করা হয়েছে!" else "Accessibility সার্ভিস চালু করুন।"
                }, modifier = Modifier.weight(1f))

                SoftButton("আনলক টেস্ট (Wait 4s)", {
                    scope.launch {
                        testStatus = "ফোন লক হচ্ছে... ৪ সেকেন্ড পর স্বয়ংক্রিয়ভাবে আনলক শুরু হবে।"
                        delay(600)
                        AlfredAccessibilityService.instance?.lockDevice()
                        delay(3500)
                        AlfredAccessibilityService.instance?.unlockDevice()
                        testStatus = "আনলক কমান্ড পাঠানো হয়েছে!"
                    }
                }, modifier = Modifier.weight(1f))
            }
        }
    }
}
