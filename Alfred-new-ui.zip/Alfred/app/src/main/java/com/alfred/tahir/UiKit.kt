@file:OptIn(ExperimentalMaterial3Api::class)

package com.alfred.tahir

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

data class ThemePalette(
    val id: Int,
    val name: String,
    val primary: Color,
    val light: Color,
    val tile: Color,
    val btnStart: Color,
    val btnEnd: Color,
    val micStart: Color,
    val micEnd: Color
)

object UiThemeManager {
    val themes = listOf(
        ThemePalette(0, "Arc Cyan", Color(0xFF22D3EE), Color(0xFFB8F3FF), Color(0x3322D3EE), Color(0xFF0E7490), Color(0xFF0891B2), Color(0xFF06B6D4), Color(0xFF0E7490)),
        ThemePalette(1, "Emerald Matrix", Color(0xFF10B981), Color(0xFFA7F3D0), Color(0x3310B981), Color(0xFF047857), Color(0xFF059669), Color(0xFF34D399), Color(0xFF047857)),
        ThemePalette(2, "Stark Crimson", Color(0xFFEF4444), Color(0xFFFECACA), Color(0x33EF4444), Color(0xFFB91C1C), Color(0xFFDC2626), Color(0xFFF87171), Color(0xFFB91C1C)),
        ThemePalette(3, "Cyber Violet", Color(0xFFA855F7), Color(0xFFE9D5FF), Color(0x33A855F7), Color(0xFF7E22CE), Color(0xFF9333EA), Color(0xFFC084FC), Color(0xFF7E22CE)),
        ThemePalette(4, "Royal Sapphire", Color(0xFF3B82F6), Color(0xFFBFDBFE), Color(0x333B82F6), Color(0xFF1D4ED8), Color(0xFF2563EB), Color(0xFF60A5FA), Color(0xFF1D4ED8)),
        ThemePalette(5, "Solar Amber", Color(0xFFF59E0B), Color(0xFFFDE68A), Color(0x33F59E0B), Color(0xFFB45309), Color(0xFFD97706), Color(0xFFFBBF24), Color(0xFFB45309))
    )

    fun current(): ThemePalette {
        val idx = Prefs.uiTheme.coerceIn(0, themes.size - 1)
        return themes[idx]
    }
}

/** Design tokens of the Alfred look: Jarvis / Friday style dark HUD (cyan on deep navy). */
object UI {
    val currentTheme: ThemePalette get() = UiThemeManager.current()

    val Bg = Color(0xFF020A14)
    val Panel = Color(0xFF08192B)
    val Tile: Color get() = currentTheme.tile
    val Navy: Color get() = currentTheme.light      // titles
    val Ink = Color(0xFFE4F7FF)                     // main text
    val Sub = Color(0xFF7FA6BC)                     // secondary text
    val Blue: Color get() = currentTheme.primary    // main accent
    val Peri = Color(0xFF38BDF8)
    val Violet = Color(0xFF7DD3FC)
    val Good = Color(0xFF34F5A0)
    val Bad = Color(0xFFFF5C6C)
    val Warn = Color(0xFFFF9F43)
    val OnAccent = Color(0xFF021018)  // text on a bright accent background
    val BtnBrush: Brush get() = Brush.horizontalGradient(listOf(currentTheme.btnStart, currentTheme.btnEnd))
    val MicBrush: Brush get() = Brush.linearGradient(listOf(currentTheme.micStart, currentTheme.micEnd))
    val SendBrush: Brush get() = Brush.linearGradient(listOf(currentTheme.btnEnd, currentTheme.btnStart))
    val OffBrush = Brush.horizontalGradient(listOf(Color(0xFF16303F), Color(0xFF16303F)))
}

// ------------------------------------------------------------------ background + glass

@Composable
fun AlfredBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF031322), Color(0xFF020A14), Color(0xFF01060D))))
            .drawBehind {
                val w = size.width
                val h = size.height
                // faint HUD grid
                val step = w / 10f
                val gridColor = UI.Blue.copy(alpha = 0.08f)
                var x = 0f
                while (x <= w) {
                    drawLine(gridColor, Offset(x, 0f), Offset(x, h), strokeWidth = 1f)
                    x += step
                }
                var y = 0f
                while (y <= h) {
                    drawLine(gridColor, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
                    y += step
                }
                val c1 = Offset(w * 0.50f, h * 0.30f)
                drawCircle(
                    brush = Brush.radialGradient(listOf(UI.Blue.copy(alpha = 0.32f), Color.Transparent), center = c1, radius = w * 0.85f),
                    radius = w * 0.85f, center = c1
                )
                val c2 = Offset(w * 0.95f, h * 0.85f)
                drawCircle(
                    brush = Brush.radialGradient(listOf(UI.Blue.copy(alpha = 0.20f), Color.Transparent), center = c2, radius = w * 0.80f),
                    radius = w * 0.80f, center = c2
                )
            },
        content = content
    )
}

fun Modifier.glass(radius: Dp = 22.dp, alpha: Float = 0.70f): Modifier {
    val shape = RoundedCornerShape(radius)
    return this
        .shadow(10.dp, shape, ambientColor = UI.Blue.copy(alpha = 0.25f), spotColor = UI.Blue.copy(alpha = 0.35f))
        .clip(shape)
        .background(UI.Panel.copy(alpha = alpha.coerceAtLeast(0.72f)))
        .border(1.dp, UI.Blue.copy(alpha = 0.45f), shape)
}

@Composable
fun GlassCard(title: String? = null, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().glass(24.dp, 0.74f).padding(18.dp)) {
        if (title != null) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = UI.Ink)
            Spacer(Modifier.height(12.dp))
        }
        content()
    }
}

@Composable
fun Label(text: String) {
    Text(text, color = UI.Sub, fontSize = 13.sp)
}

// ------------------------------------------------------------------ buttons, chips, switches

@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    brush: Brush = UI.BtnBrush,
    height: Dp = 52.dp,
    trailing: (@Composable () -> Unit)? = null
) {
    val shape = RoundedCornerShape(height / 2)
    Row(
        modifier
            .height(height)
            .clip(shape)
            .background(if (enabled) brush else UI.OffBrush)
            .clickable(enabled = enabled, onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = if (enabled) Color.White else UI.Sub, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        if (trailing != null) {
            Spacer(Modifier.width(10.dp))
            trailing()
        }
    }
}

@Composable
fun SoftButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .clip(shape)
            .background(UI.Panel.copy(alpha = if (enabled) 0.90f else 0.5f))
            .border(1.dp, UI.Blue.copy(alpha = if (enabled) 0.65f else 0.20f), shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (enabled) UI.Blue else UI.Sub, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .clip(shape)
            .background(if (selected) UI.Blue else UI.Panel.copy(alpha = 0.85f))
            .border(1.dp, if (selected) UI.Blue else UI.Blue.copy(alpha = 0.35f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            label,
            color = if (selected) UI.OnAccent else UI.Ink,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun ChipRow(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (value, label) -> Chip(label, value == selected) { onSelect(value) } }
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = UI.Ink, fontSize = 15.sp)
        Switch(
            checked = checked,
            enabled = enabled,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = UI.Blue, checkedThumbColor = UI.OnAccent, uncheckedTrackColor = UI.Panel, uncheckedThumbColor = UI.Sub)
        )
    }
}

@Composable
fun sliderColors() = SliderDefaults.colors(
    thumbColor = UI.Blue,
    activeTrackColor = UI.Blue,
    inactiveTrackColor = UI.Blue.copy(alpha = 0.18f)
)

// ------------------------------------------------------------------ orbs

/** The real animated orb (same view that floats over other apps). */
@Composable
fun OrbPreview(
    status: Orb,
    color: Int,
    size: Dp,
    style: Int = Prefs.orbStyle,
    hue: Float = Prefs.orbHue,
    modifier: Modifier = Modifier
) {
    AndroidView(
        factory = { OrbView(it) },
        update = {
            it.status = status
            it.paletteIndex = color
            it.style = style
            it.hue = hue
        },
        modifier = modifier.size(size)
    )
}

/** Cheap static little arc-reactor: used in headers and chat bubbles. */
@Composable
fun MiniOrb(size: Dp) {
    val pair = OrbPalette.resolve(Prefs.orbColor, Prefs.orbHue)
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension
        val c = Offset(s / 2f, s / 2f)
        val r = s / 2f
        drawCircle(
            brush = Brush.radialGradient(listOf(Color(pair.second).copy(alpha = 0.55f), Color.Transparent), center = c, radius = r),
            radius = r, center = c
        )
        drawCircle(
            color = Color(pair.first).copy(alpha = 0.85f), radius = r * 0.90f, center = c,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = s * 0.05f)
        )
        drawCircle(
            color = Color(pair.first).copy(alpha = 0.55f), radius = r * 0.64f, center = c,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = s * 0.035f)
        )
        drawCircle(
            brush = Brush.radialGradient(listOf(Color.White, Color(pair.first), Color(pair.second)), center = c, radius = r * 0.42f),
            radius = r * 0.42f, center = c
        )
    }
}

// ------------------------------------------------------------------ scaffolds + dialogs

@Composable
fun DetailScaffold(
    title: String,
    onBack: () -> Unit,
    subtitle: String? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = L.s("back"), tint = UI.Ink)
            }
            Column {
                Text(title, fontSize = 21.sp, fontWeight = FontWeight.SemiBold, color = UI.Ink)
                if (subtitle != null) Text(subtitle, fontSize = 13.sp, color = UI.Sub)
            }
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            content()
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
fun OptionDialog(title: String, options: List<Pair<String, () -> Unit>>, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = UI.Ink) },
        text = {
            Column {
                options.forEach { (label, act) ->
                    TextButton(onClick = { onDismiss(); act() }, modifier = Modifier.fillMaxWidth()) {
                        Text(label, modifier = Modifier.fillMaxWidth(), color = UI.Blue)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(L.s("close")) } },
        containerColor = UI.Panel
    )
}

@Composable
fun IconTile(bg: Color, size: Dp = 44.dp, content: @Composable () -> Unit) {
    Box(Modifier.size(size).clip(CircleShape).background(bg), contentAlignment = Alignment.Center) { content() }
}
