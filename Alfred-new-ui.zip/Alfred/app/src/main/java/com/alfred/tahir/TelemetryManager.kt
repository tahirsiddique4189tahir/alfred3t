package com.alfred.tahir

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.TimeZone

/**
 * Real-time Telemetry Manager for Alfred:
 * Monitors device battery, charging state, battery temperature, and live weather conditions.
 */
object TelemetryManager {

    private var scope: CoroutineScope? = null
    private var pollJob: Job? = null
    private var batteryReceiver: BroadcastReceiver? = null
    private var lastWeatherFetch = 0L

    fun init(ctx: Context, appScope: CoroutineScope) {
        scope = appScope
        registerBattery(ctx)
        startWeatherPolling()
    }

    private fun registerBattery(ctx: Context) {
        try {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    if (intent == null) return
                    val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                    val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                    val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                    val temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)

                    val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else 100
                    val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                            status == BatteryManager.BATTERY_STATUS_FULL
                    val celsius = temp / 10f

                    AlfredState.batteryPct.value = pct
                    AlfredState.batteryCharging.value = isCharging
                    AlfredState.batteryTemp.value = celsius
                }
            }
            batteryReceiver = receiver
            ctx.registerReceiver(receiver, filter)
        } catch (_: Exception) {}
    }

    private fun startWeatherPolling() {
        pollJob?.cancel()
        pollJob = scope?.launch(Dispatchers.IO) {
            while (isActive) {
                try {
                    fetchWeather()
                } catch (_: Exception) {}
                delay(20 * 60 * 1000L) // Refresh every 20 minutes
            }
        }
    }

    suspend fun refresh() = withContext(Dispatchers.IO) {
        try {
            fetchWeather(force = true)
        } catch (_: Exception) {}
    }

    private fun fetchWeather(force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!force && (now - lastWeatherFetch < 10 * 60 * 1000L)) return
        lastWeatherFetch = now

        try {
            // First attempt: IP-based geo coordinates, fallback to timezone estimation
            var lat = 23.8103
            var lon = 90.4125
            var city = "Local City"

            try {
                val ipUrl = URL("https://ipapi.co/json/")
                val conn = ipUrl.openConnection() as HttpURLConnection
                conn.connectTimeout = 4000
                conn.readTimeout = 4000
                if (conn.responseCode in 200..299) {
                    val raw = conn.inputStream.bufferedReader().use { it.readText() }
                    val obj = JSONObject(raw)
                    if (obj.has("latitude") && obj.has("longitude")) {
                        lat = obj.optDouble("latitude", lat)
                        lon = obj.optDouble("longitude", lon)
                        city = obj.optString("city", city)
                    }
                }
            } catch (_: Exception) {
                // If ip lookup fails, estimate from device timezone
                val tz = TimeZone.getDefault().id
                if (tz.contains("Calcutta") || tz.contains("Kolkata")) {
                    lat = 22.5726; lon = 88.3639; city = "Kolkata"
                } else if (tz.contains("Dhaka")) {
                    lat = 23.8103; lon = 90.4125; city = "Dhaka"
                } else if (tz.contains("London")) {
                    lat = 51.5074; lon = -0.1278; city = "London"
                } else if (tz.contains("New_York")) {
                    lat = 40.7128; lon = -74.0060; city = "New York"
                }
            }

            // Open-Meteo free API (No API key needed, high reliability)
            val weatherUrl = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m"
            val conn = URL(weatherUrl).openConnection() as HttpURLConnection
            conn.connectTimeout = 6000
            conn.readTimeout = 6000
            if (conn.responseCode in 200..299) {
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                val root = JSONObject(text)
                val cur = root.optJSONObject("current")
                if (cur != null) {
                    val temp = cur.optDouble("temperature_2m", 25.0).toInt()
                    val hum = cur.optInt("relative_humidity_2m", 50)
                    val wind = cur.optDouble("wind_speed_10m", 8.0).toInt()
                    val code = cur.optInt("weather_code", 0)

                    val (icon, desc) = weatherCodeToInfo(code)

                    AlfredState.weatherTemp.value = "$temp°C"
                    AlfredState.weatherDesc.value = desc
                    AlfredState.weatherIcon.value = icon
                    AlfredState.weatherCity.value = city
                    AlfredState.weatherHumidity.value = "$hum%"
                    AlfredState.weatherWind.value = "$wind km/h"
                }
            }
        } catch (_: Exception) {}
    }

    private fun weatherCodeToInfo(code: Int): Pair<String, String> = when (code) {
        0 -> "☀️" to "Clear Sky"
        1 -> "🌤️" to "Mainly Clear"
        2 -> "⛅" to "Partly Cloudy"
        3 -> "☁️" to "Overcast"
        45, 48 -> "🌫️" to "Foggy"
        51, 53, 55 -> "🌦️" to "Drizzle"
        61, 63, 65 -> "🌧️" to "Rain"
        71, 73, 75 -> "❄️" to "Snow"
        80, 81, 82 -> "🌧️" to "Rain Showers"
        95, 96, 99 -> "⛈️" to "Thunderstorm"
        else -> "🌤️" to "Fair Weather"
    }

    fun getBatterySummary(): String {
        val pct = AlfredState.batteryPct.value
        val charging = if (AlfredState.batteryCharging.value) "charging" else "discharging"
        val temp = AlfredState.batteryTemp.value
        return "Battery is at $pct%, currently $charging. Battery temperature is ${String.format(Locale.US, "%.1f", temp)}°C."
    }

    fun getWeatherSummary(): String {
        val temp = AlfredState.weatherTemp.value
        val desc = AlfredState.weatherDesc.value
        val city = AlfredState.weatherCity.value
        val hum = AlfredState.weatherHumidity.value
        val wind = AlfredState.weatherWind.value
        return "Current weather in $city is $desc at $temp. Humidity is $hum with wind speed of $wind."
    }
}
