package com.alfred.tahir

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Small flat icons drawn with Canvas (no icon library needed). */
enum class G {
    MIC, KEYBOARD, GRID, FLOWER, WAVE, SPEAKER, SPARK, ORB, CHAT, SHOT,
    UPDOWN, TEXTA, POWER, CHEVRON, PLANE, OPENAPP, ARROW, HEAD, CLIP, ACCESS
}

@Composable
fun Glyph(kind: G, tint: Color, sz: Dp = 22.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        val sw = s * 0.09f
        val st = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)

        fun line(x1: Float, y1: Float, x2: Float, y2: Float) {
            drawLine(tint, Offset(s * x1, s * y1), Offset(s * x2, s * y2), strokeWidth = sw, cap = StrokeCap.Round)
        }

        fun poly(vararg pts: Float, fill: Boolean) {
            val p = Path()
            p.moveTo(s * pts[0], s * pts[1])
            var i = 2
            while (i < pts.size) {
                p.lineTo(s * pts[i], s * pts[i + 1])
                i += 2
            }
            if (fill) {
                p.close()
                drawPath(p, tint)
            } else {
                drawPath(p, tint, style = st)
            }
        }

        when (kind) {
            G.MIC -> {
                drawRoundRect(
                    tint, topLeft = Offset(s * 0.36f, s * 0.08f), size = Size(s * 0.28f, s * 0.50f),
                    cornerRadius = CornerRadius(s * 0.14f)
                )
                drawArc(
                    tint, startAngle = 0f, sweepAngle = 180f, useCenter = false,
                    topLeft = Offset(s * 0.24f, s * 0.30f), size = Size(s * 0.52f, s * 0.44f), style = st
                )
                line(0.5f, 0.74f, 0.5f, 0.90f)
                line(0.36f, 0.90f, 0.64f, 0.90f)
            }
            G.KEYBOARD -> {
                drawRoundRect(
                    tint, topLeft = Offset(s * 0.06f, s * 0.22f), size = Size(s * 0.88f, s * 0.56f),
                    cornerRadius = CornerRadius(s * 0.10f), style = st
                )
                for (i in 0..3) drawCircle(tint, s * 0.035f, Offset(s * (0.24f + i * 0.17f), s * 0.40f))
                line(0.30f, 0.62f, 0.70f, 0.62f)
            }
            G.GRID -> {
                val a = s * 0.30f
                for (r in 0..1) for (c in 0..1) {
                    drawRoundRect(
                        tint, topLeft = Offset(s * (0.14f + c * 0.40f), s * (0.14f + r * 0.40f)),
                        size = Size(a, a), cornerRadius = CornerRadius(s * 0.08f), style = st
                    )
                }
            }
            G.FLOWER -> {
                val rr = s * 0.13f
                drawCircle(tint, rr, Offset(s * 0.5f, s * 0.24f))
                drawCircle(tint, rr, Offset(s * 0.5f, s * 0.76f))
                drawCircle(tint, rr, Offset(s * 0.24f, s * 0.5f))
                drawCircle(tint, rr, Offset(s * 0.76f, s * 0.5f))
                drawCircle(tint, s * 0.08f, Offset(s * 0.5f, s * 0.5f))
            }
            G.WAVE -> {
                val hs = floatArrayOf(0.25f, 0.55f, 0.90f, 0.55f, 0.35f, 0.70f)
                for (i in hs.indices) {
                    val x = 0.12f + i * 0.152f
                    line(x, 0.5f - hs[i] / 2f, x, 0.5f + hs[i] / 2f)
                }
            }
            G.SPEAKER -> {
                poly(0.12f, 0.40f, 0.30f, 0.40f, 0.50f, 0.22f, 0.50f, 0.78f, 0.30f, 0.60f, 0.12f, 0.60f, fill = true)
                drawArc(
                    tint, startAngle = -45f, sweepAngle = 90f, useCenter = false,
                    topLeft = Offset(s * 0.38f, s * 0.34f), size = Size(s * 0.32f, s * 0.32f), style = st
                )
                drawArc(
                    tint, startAngle = -50f, sweepAngle = 100f, useCenter = false,
                    topLeft = Offset(s * 0.36f, s * 0.20f), size = Size(s * 0.56f, s * 0.60f), style = st
                )
            }
            G.SPARK -> {
                val p = Path()
                p.moveTo(s * 0.5f, s * 0.04f)
                p.quadraticBezierTo(s * 0.5f, s * 0.5f, s * 0.96f, s * 0.5f)
                p.quadraticBezierTo(s * 0.5f, s * 0.5f, s * 0.5f, s * 0.96f)
                p.quadraticBezierTo(s * 0.5f, s * 0.5f, s * 0.04f, s * 0.5f)
                p.quadraticBezierTo(s * 0.5f, s * 0.5f, s * 0.5f, s * 0.04f)
                p.close()
                drawPath(p, tint)
            }
            G.ORB -> {
                drawCircle(tint, s * 0.34f, Offset(s * 0.5f, s * 0.5f), style = st)
                drawCircle(tint, s * 0.15f, Offset(s * 0.5f, s * 0.5f))
            }
            G.CHAT -> {
                drawRoundRect(
                    tint, topLeft = Offset(s * 0.10f, s * 0.14f), size = Size(s * 0.80f, s * 0.58f),
                    cornerRadius = CornerRadius(s * 0.16f), style = st
                )
                poly(0.30f, 0.72f, 0.26f, 0.90f, 0.48f, 0.72f, fill = false)
            }
            G.SHOT -> {
                drawRoundRect(
                    tint, topLeft = Offset(s * 0.14f, s * 0.14f), size = Size(s * 0.72f, s * 0.72f),
                    cornerRadius = CornerRadius(s * 0.14f), style = st
                )
                drawCircle(tint, s * 0.12f, Offset(s * 0.5f, s * 0.5f))
            }
            G.UPDOWN -> {
                line(0.5f, 0.14f, 0.5f, 0.86f)
                poly(0.34f, 0.30f, 0.5f, 0.14f, 0.66f, 0.30f, fill = false)
                poly(0.34f, 0.70f, 0.5f, 0.86f, 0.66f, 0.70f, fill = false)
            }
            G.TEXTA -> {
                poly(0.14f, 0.82f, 0.36f, 0.20f, 0.58f, 0.82f, fill = false)
                line(0.22f, 0.60f, 0.50f, 0.60f)
                line(0.80f, 0.22f, 0.80f, 0.82f)
            }
            G.POWER -> {
                drawArc(
                    tint, startAngle = -55f, sweepAngle = 290f, useCenter = false,
                    topLeft = Offset(s * 0.18f, s * 0.20f), size = Size(s * 0.64f, s * 0.64f), style = st
                )
                line(0.5f, 0.08f, 0.5f, 0.48f)
            }
            G.CHEVRON -> poly(0.38f, 0.22f, 0.64f, 0.50f, 0.38f, 0.78f, fill = false)
            G.PLANE -> poly(0.92f, 0.50f, 0.12f, 0.14f, 0.30f, 0.50f, 0.12f, 0.86f, fill = true)
            G.OPENAPP -> {
                drawRoundRect(
                    tint, topLeft = Offset(s * 0.12f, s * 0.18f), size = Size(s * 0.76f, s * 0.64f),
                    cornerRadius = CornerRadius(s * 0.12f), style = st
                )
                line(0.12f, 0.38f, 0.88f, 0.38f)
                drawCircle(tint, s * 0.035f, Offset(s * 0.24f, s * 0.28f))
            }
            G.ARROW -> {
                line(0.14f, 0.5f, 0.86f, 0.5f)
                poly(0.60f, 0.24f, 0.86f, 0.5f, 0.60f, 0.76f, fill = false)
            }
            G.HEAD -> {
                drawCircle(tint, s * 0.18f, Offset(s * 0.5f, s * 0.30f), style = st)
                drawArc(
                    tint, startAngle = 180f, sweepAngle = 180f, useCenter = false,
                    topLeft = Offset(s * 0.18f, s * 0.54f), size = Size(s * 0.64f, s * 0.56f), style = st
                )
            }
            G.CLIP -> {
                drawRoundRect(
                    tint, topLeft = Offset(s * 0.20f, s * 0.14f), size = Size(s * 0.60f, s * 0.72f),
                    cornerRadius = CornerRadius(s * 0.10f), style = st
                )
                poly(0.36f, 0.50f, 0.46f, 0.60f, 0.66f, 0.40f, fill = false)
            }
            G.ACCESS -> {
                drawCircle(tint, s * 0.09f, Offset(s * 0.5f, s * 0.18f))
                line(0.16f, 0.36f, 0.84f, 0.36f)
                line(0.5f, 0.36f, 0.5f, 0.60f)
                line(0.5f, 0.60f, 0.34f, 0.88f)
                line(0.5f, 0.60f, 0.66f, 0.88f)
            }
        }
    }
}
